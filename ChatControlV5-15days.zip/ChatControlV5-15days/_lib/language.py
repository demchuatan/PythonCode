# -*- coding: utf-8 -*-


MainHelpEn_ = """
                                          PLUGIN DESCRIPTION
This plugin is built to control characters through chat commands.
Character control commands are only in the Move and Set categories.
-For example, you can order all characters to return to town with the chat: [Move h]
-Or you just want the person giving the order to return to town: [Move h 1]
-Or you just want chars to return except the commanding char: [Move h -1]
-Or you just want two characters named Tom and Jerry to return: [Move h Tom Jerry]
You can use commas to separate commands instead of spaces: [Move,h,1]
The remaining categories only support and install the corresponding commands.
There will be a corresponding guide section for each menu for your reference.
You can personalize the commands in the corresponding edit section.
You can refer to more instructions at: www.youtube.com/@Silkroad-phBot
-------------------------------------------------- ---------------------------------
Thank you for using this plugin!
"""

MainHelpVi_ = """
                                          MÔ TẢ PLUGIN
Plugin này được xây dựng để điều khiển các nhân vật thông qua câu lệnh chat.
Các lệnh điều khiển nhân vật chỉ nằm trong danh mục Move và Set.
- Ví dụ, bạn có thể ra lệnh cho tất cả nhân vật về thị trấn bằng lời chat: [Move h]
- Hoặc bạn chỉ muốn duy nhất người ra lệnh trở về thị trấn: [Move h 1]
- Hoặc bạn chỉ muốn tất cả trở về, ngoại trừ người ra lệnh: [Move h -1]
- Hoặc bạn chỉ muốn hai nhân vật có tên Tom và Jerry trở về: [Move h Tom Jerry] 
Bạn có thể dùng dấu phẩy để phân cách lệnh thay vì khoảng trắng: [Move,h,1]
Các danh mục còn lại chỉ hỗ trợ và cài đặt cho những câu lệnh tương ứng.
Sẽ có một mục hướng dẫn tương ứng với mỗi menu phải để bạn tham khảo.
Bạn có thể cá nhân hoá các câu lệnh trong phần sửa đổi tương ứng.
Bạn có thể tham khảo thêm hướng dẫn tại: www.youtube.com/@Silkroad-phBot
-----------------------------------------------------------------------------------
Cảm ơn bạn đã sử dụng plugin này!
"""

GuildHelpEn_ = """
-Only characters with a guild or name in this can issue orders and execute them.
-If your characters are in a guild, simply adding the guild name is enough.
-When equipped job and ordering others to do it, you need to add the job name.
-You need to click reload button for characters after each change to this menu.
-If abc character's name or abc character's guild is added to the menu
for the first time,
You need to open the phbot of abc and press the reload button. 
This is the only menu required you press each character's reload button
to receive the new value.
"""
GuildHelpVi_ = """
-Chỉ những nhân vật có guild hoặc tên trong này mới có thể ra lệnh và thực hiện.
-Nếu các nhân vật của bạn trong một guild, chỉ cần thêm tên guild là đủ.
-Khi mặc job và ra lệnh cho người khác thực hiện, cần thêm tên job vào danh mục.
-Nếu tên nhân vật abc hoặc guild của nhân vật abc lần đầu được thêm vào menu,
bạn cần mở phbot của nhân vật abc và bấm nút reload. Đây là menu duy nhất bắt buộc
...bạn bấm từng nút reload của mỗi nhân vật để nhận giá trị mới.
"""

MoveHelpEn_ = """
**: Only valid in parties and DCN scrolls need to support party reverse.
-Code Name: Is the type of command, entered first, next command and suffix.
-Justme: Only the commanding character will execute if you add this suffix.
-Notme: All characters that don't give command will execute if you add this.
-Home: Command of reverse to town, designated place to revive
-Dead: Command of reverse to the nearest dead location
-Last: Command of reverse to the last position
-Party: Chars who don't give command will reverse to position of commanding char.
-FixMap: Reverse to fixed locations on the map, see more FixMap menu.
-ExMap: Reverse to extended locations on the map, see more ExMap menu.
-Tele: Teleport through NPC, see more Tele menu
-Item: Unequip to store in GuildStorage; or vice versa, see more Item menu
-XY: Move to the given xy position, for example [Move xy -2356 1538]
-Me: Reverse to your own position, only valid for the commanding char.
-Script: Buy/sell/store goods in town according to the given scenario.
"""

MoveHelpVi_ = """
**: Chỉ hiệu lực trong party và cuộn DCN cần hỗ trợ dịch chuyển tới party.
-Code Name: Là loại lệnh, được nhập đầu tiên, kế tiếp là lệnh và hậu tố.
-Justme: Chỉ nhân vật ra lệnh sẽ thực hiện lệnh nếu bạn thêm hậu tố này.
-Notme: Tất cả nhân vật không ra lệnh sẽ thực hiện nếu bạn thêm hậu tố này.
-Home: Lệnh dịch chuyển về thị trấn, nơi chỉ định hồi sinh
-Dead: Lệnh dịch chuyển về vị trí chết gần nhất
-Last: Lệnh dịch chuyển về vị trí cuối cùng khi dùng cuộn dịch chuyển ngược.
-Party: Các nhân vật không ra lệnh sẽ dịch chuyển tới vị trí người ra lệnh.
-FixMap: Dịch chuyển tới các vị trí cố định trên map, xem thêm menu FixMap.
-ExMap: Dịch chuyển tới các vị trí mở rộng trên map, xem thêm menu ExMap.
-Tele: Dịch chuyển(Teleport) thông qua NPC, xem thêm menu Tele
-Item: Tháo trang bị để lưu trữ vào guild; hoặc ngược lại, xem thêm menu Item
-XY: Di chuyển tới vị trí xy cho trước, ví dụ [Move XY -2356 1538]
-Me: Dịch chuyển tới chính vị trí của bạn, chỉ có hiệu lực với người ra lệnh.
-Script: Mua/bán/lưu trữ hàng hoá trong thị trấn theo kịch bản cho trước.
"""

SetHelpEn_ = """
*: Only the character giving the command can execute these commands.
-Code Name, Justme, Notme: Similar to the Move menu
-Start bot: Set the training position at the standing position, then start bot.
-Radius: Change the training area radius, for example [Set r 30]
-ReCall: Specify the respawn location for the characters
-Training: Change to another training area previously created in the list.
-Weapon: Auto change weapons/shield if using another skill, see more Weapon menu.
-Profile: Change to another profile
-LeavePt: Leave the party
-Python: Control characters through python functions, see more Python menu
-Manashield: Activate manashield for the character, see more Manashield menu
-Ghost: Auto ghost (activate exchange with enemy), see more Ghost menu
-Cure: Automatically target yourself to force cure, see more Cure menu
Note: To stop commands that have a long execution time, You need to input...
...the command twice consecutively, example start bot [Set s] and stop bot [Set ss]
"""

SetHelpVi_ = """
*: Chỉ người ra lệnh mới thực hiện được những lệnh này.
-Code Name, Just me, Not me: Tương tự như menu Move
-Start bot: Thiết lập vị trí training tại vị trí đang đứng, sau đó bắt đầu bot.
-Radius: Thay đổi bán kính vùng training, ví dụ [Set r 30]
-ReCall: Chỉ định vị trí hồi sinh cho các nhân vật
-Training: Thay đổi sang vùng training khác đã tạo trước đó trong danh sách.
-Weapon: Tự động thay đổi vũ khí, shield nếu dùng skill khác, xem menu Weapon.
-Profile: Thay đổi sang profile khác
-LeavePt: Rời khỏi party
-Python: Điều khiển nhân vật thông qua các hàm python, xem thêm menu Python
-Manashield: Kích hoạt manashield cho nhân vật, xem thêm menu Manashield
-Ghost: Tự động ghost(kích hoạt giao dịch với đối thủ), xem thêm menu Ghost
-Cure: Tự động target tới bản thân để hoá giải dị trạng, xem thêm menu Cure
Lưu ý: Để stop các lệnh có thời gian thực thi lâu, bạn cần nối hai lần lệnh...
...lệnh start tương ứng với nó, ví dụ lệnh start bot [Set s] và stop bot [Set ss]
"""

ExMapHelpEn_ = """
ExMap(Expanded Map) is command to move characters to a given expanded location.
To create an extension point right where the character is standing, you just
...need to enter a name and description for that extension point.
Extension points will be saved and reused many times.

Example: Create an ExMap point at the position where char is standing as follows:
- Name: da
- Note : Death alley
Then execute the command as follows:
- [Move e da] if you want all party members reverse to [da]
- [Move e da 1] if you only want the commanding char to location [da]
- [Move e da -1] if you want whole party(except commanding char) reverse to [da]
- [Move e htt abc xyz] if you only want 2 chars abc and xyz to position [da]

To delete an ExMap, you just need to select ExMap point from the list and delete it.
"""

ExMapHelpVi_ = """
ExMap(Expanded Map) là lệnh dịch chuyển nhân vật tới một vị trí mở rộng cho trước.
Để tạo một điểm mở rộng ngay tại vị trí nhân vật đang đứng, bạn chỉ cần...
...nhập tên và mô tả cho điểm mở rộng đó.
Các điểm mở rộng sẽ được lưu và tái sử dụng nhiều lần.

Ví dụ: Tạo một điểm mở rộng tại vị trí nhân vật đang đứng như sau:
- Đặt tên: htt
- Mô tả: Đầu hẻm tử thần
Sau đó thực hiên lệnh như sau:
- [Move e htt] nếu bạn muốn tất cả thành viên party tới vị trí [htt]
- [Move e htt 1] nếu bạn chỉ muốn nhân vật ra lệnh tới vị trí [htt]
- [Move e htt -1] nếu bạn muốn cả party(ngoại trừ người ra lệnh) tới vị trí [htt]
- [Move e htt abc xyz] nếu bạn chỉ muốn 2 nhân vật abc và xyz tới vị trí [htt]

Để xoá điểm mở rộng(ExMap), bạn chỉ cần chọn điểm mở rộng từ danh sách và xoá.
"""

FixMapHelpEn_ = """
FixMap are fixed moving points on the map that Joymax previously created...
For example: Constantinople, Tomb of Qin-Shi Emperor lv.2, Hyungno Homeland...

For convenience when entering the names of these locations, FixMap creates...
...shortcuts that allow you to replace the names of these locations
...with corresponding shortcuts.

For example, you create a shortcut for the Tomb of Qin-Shi Emperor lv.2 location:
- Select Tomb of Qin-Shi Emperor lv.2 in the list
- Name the shortcut: b2
- Click the add shortcut button
At this point, you just need to input the command [Move m b2] instead of...
...entering a rather long command as follows [Move m Tomb of Qin-Shi Emperor lv.2]

To delete FixMap, you just need to select the shortcut from the list and delete.
"""

FixMapHelpVi_ = """
FixMap là các điểm dịch chuyển cố định trên map mà Joymax đã tạo trước đó...
Ví dụ: Constantinople, Tomb of Qin-Shi Emperor lv.2, Hyungno Homeland...

Để thuận tiện khi nhập tên các vị trí này, FixMap tạo ra những shortcut...
...cho phép bạn thay tên của những vị trí này bằng những shortcut tương ứng.

Ví dụ bạn tạo shortcut(lối tắt) cho vị trí Tomb of Qin-Shi Emperor lv.2:
- Chọn Tomb of Qin-Shi Emperor lv.2 trong danh sách
- Đặt tên shortcut: b2
- Nhấn nút thêm shortcut
Lúc này, bạn chỉ cần nhập lệnh [Move m b2] thay vì nhập một lệnh khá dài...
...như sau [Move m Tomb of Qin-Shi Emperor lv.2]

Ở phiên bản tiếng Việt, tác giả đã tạo sẵn những shortcut ứng với tên tiếng Việt.
Để xoá FixMap(shortcut), bạn chỉ cần chọn shortcut từ danh sách và xoá.
"""

ConvertItemHelpEn_ = """
Convert Weapon/Shield is to auto convert a weapon to another weapon(or shield)...
...when you use the corresponding skills installed in this section.

To setup, first, you need to add the character who wants to use this feature.
-Next, you input the weapons and shield you want to equip during battle.
-Next, you add the corresponding skills for each type of weapon and shield...
...that you want to auto switch when you use those skills.
walk: it will auto equip the shield even if you dodge enemy or run.
To del skills, you need to select the skill in the corresponding list and del it

You should use python menu to check weapon, shield, and skills names before input.
This command is only valid for the commanding character
To delete a character, simply select the character's name from the list and delete.
Like other stop commands, you need to write this command twice in a row to stop it.
This function is not supported while the character is botting
"""

ConvertItemHelpVi_ = """
Convert Weapon/Shield là tự động chuyển đổi vũ khí sang vũ khí khác(hoặc khiên)...
...khi bạn sử dụng các skill tương ứng đã được cài đặt trong phần này.

Để cài đặt, đầu tiên, bạn cần thêm nhân vật muốn sử dụng tính năng này.
-Kế tiếp, bạn nhập các loại vũ khí, khiên mà bạn muốn trang bị trong lúc chiến đấu.
-Kế tiếp, bạn thêm các skills tương ứng cho từng loại vũ khí, khiên mà bạn...
...bạn muốn nó sẽ tự động chuyển đổi khi bạn dùng đến những skills đó.
walk: nó sẽ tự động trang bị khiên ngay cả khi bạn né tránh đối thủ hoặc chạy bộ.
Để xoá các skill, bạn cần chọn skill trong danh sách tương ứng và xoá

Bạn nên sử dụng menu python để kiểm tra tên vũ khí, khiên, skills trước khi nhập.
Lệnh này chỉ có hiệu lực cho người ra lệnh.
Để xoá nhân vật, bạn chỉ cần chọn tên nhân vật từ danh sách và xoá.
Giống như stop các lệnh khác, bạn cần viết nối 2 lần liên tiếp lệnh này để stop nó.
Chức năng này không hỗ trợ trong khi nhân vật đang botting
"""

PythonHelpEn_ = """
The python menu helps you find information to support other menus, or execute...
...a phbot python function for this character.
You can visit [https://plugins.phbot.org/phbot-api] to refer to more python functions.
You do not need to enter parentheses "()" in the function name
If there is more than one argument, you separate them with a space or comma.
To search for skill name and Tele NPC information in the bottom list, you need...
...to scan and save game path before using...
Note: The Python in the interface is different from the python command in the chat...
-In the interface: python allows arguments and is valid for only this character
-In chat command: no arguments are allowed, valid for multiple characters
-[Set py reload] is the most important command in the chat command to execute the...
...reload function. Chars will not receive new data until you execute this command
There is a shortcut for this command, you just need to enter [Set py] instead of...
...[Set py reload], it will reload for all characters who hear this command.
"""

PythonHelpVi_ = """
Menu python giúp bạn tìm kiếm thông tin để hỗ trợ cho những menu khác, hoặc...
...hoặc thực thi một hàm python của phbot cho nhân vật này.
Bạn truy cập [https://plugins.phbot.org/phbot-api] để tham khảo thêm hàm python.
Bạn không cần nhập dấu ngoặc "()" vào tên hàm
Nếu có nhiều hơn một đối số, bạn phân tách bằng khoảng trắng hoặc dấu phẩy.
Để tìm kiếm thông tin tên skills và Tele NPC trong danh sách dưới cùng, bạn cần...
...cần scan và lưu trữ đường dẫn của game trước khi sử dụng...
Lưu ý: Python trong giao diện khác với lệnh điều khiển python trong câu chat...
-Trong giao diện: python cho phép có đối số và chỉ có hiệu lực cho một nhân vật
-Trong câu lệnh chat: không cho phép có đối số, có hiệu lực cho nhiều nhân vật
-[Set py reload] là câu lệnh quan trọng nhất trong lệnh chat để thực thi hàm reload...
...các nhân vật sẽ không nhận được dữ liệu mới cho đến khi bạn thực hiện lệnh này...
...có shortcut cho lệnh này, bạn chỉ cần nhập [Set py] thay vì [Set py reload]...
...nó sẽ reload cho toàn bộ những nhân vật nghe được lệnh này.
"""

StoreItemHelpEn_ = """
Storage/Take Items will unequip chars =>store it to guild storage; or vice versa.
This menu supports servers with limited green hours where you want to change...
...shifts to train and don't need to invest a lot of equipment for all the noob chars.

To setup, first you need to add characters to the list,
-Next, you update the items you want to equip/unequip for that character
-You should use python menu to support exact names for these items.

If you want to unequip => store guid storage, input the command [Move i u]
If you want to take from the guild storage =>equip, input the command [Move i e]
(u stands for unequip, e stands for equip)
If you want to stop, just input [Move ii]
"""

StoreItemHelpVi_ = """
Storage/Take Items sẽ tháo trang bị đang mặc => gửi vào pet hoặc kho guild; hoặc ngược lại.
Menu này hỗ trợ những server giới hạn giờ xanh mà bạn muốn thay ca để farm và...
...và không cần đầu tư nhiều trang bị cho tất cả các nhân vật phụ.

Để cài đặt, đầu tiên bạn cần thêm nhân vật vào danh sách,
-Kế tiếp, bạn cập nhật các items mà bạn muốn equip/unequip cho nhân vật đó
-Bạn nên sử dụng menu python để hỗ trợ tên chính xác cho các items này.

Nếu bạn muốn tháo trang bị => lưu kho guid, cần nhập lệnh [Move i u]
Nếu bạn muốn lấy trang bị từ kho guild => mặc, cần nhập lệnh [Move i e]
(u là viết tắt từ unequip, e viết tắt từ equip)
Nếu muốn stop, bạn chỉ cần nhập [Move ii]
"""

TeleHelpEn_ = """
Teleport is a teleport feature through NPCs. In the game, there are many NPCs...
...that allow you to teleport (Pharaoh entrance, Temple, Towns,...)
The Teleport menu allows you to create shortcuts for this type of teleport.

For example, when there is no shortcut, if you want to teleport from...
...Donwhang to Hotan, you need to input [Move t Donwhang Hotan]
But if you already have a shortcut, you can just input [Move t DtoH], where:
- Shortcut: DtoH
- Source: Donwhang
- Destination: Hotan

Note:
-You should use the python menu to find (source, destination) for teleport NPCs.
-Characters need to stand near NPCs to teleport.
"""

TeleHelpVi_ = """
Teleport là chức năng dịch chuyển thông qua NPC, trong game có nhiều...
...nhiều NPC cho phép bạn dịch chuyển(cửa vào Pharaoh, Temple, các Town,...)
Menu Teleport cho phép bạn tạo shortcut cho kiểu dịch chuyển này.

Ví dụ, khi chưa có shortcut, nếu bạn muốn teleport từ Đôn Hoàng tới Hoà Điền,...
...bạn cần nhập [Move t Donwhang Hotan]
Nhưng nếu bạn đã có shortcut, bạn chỉ cần nhập [Move t DtoH], trong đó:
- Nhập tên Shortcut: DtoH
- Nhập Source: Donwhang
- Nhập Destination: Hotan

Lưu ý:
-Bạn nên sử dụng menu python để tìm(source, destination) cho các NPC teleport.
-Các nhân vật cần đứng gần NPC mới có thể teleport.
"""

MNSHelpEn_ = """
ManaShield allows you to activate ManaShield (if available)
Every time the character comes back to life, you have to go out of the game =>...
...choose phbot =>click Start bot => click stop bot, to activate the ManaShield bug
ManaShield menu makes it much simpler, just enter the command [Set m]
The [Set m] command only activates once, if you want to activate continuously...
...like when you are botting, you need to input [Set m on]
[Set mm] to turn off command [Set m on] status if you do not want to use it.
To setup, you need to add character,
-Next, select the Manashield skill from the list and click Save

Note:
-The command to activate Manashield is only valid for commanding character
-If you change to another profile to use, you need to reconfigure here.
"""

MNSHelpVi_ = """
ManaShield cho phép bạn kích hoạt ManaShield(nếu có)
Mỗi lần nhân vật sống lại, bạn phải ra ngoài game => lựa chọn phbot =>...
...=>click Start bot => click stop bot, để kích hoạt bug ManaShield
Menu ManaShield khiến điều đó đơn giản hơn nhiều, chỉ cần nhập lệnh [Set m]
Lệnh [Set m] chỉ kích hoạt một lần, nếu bạn muốn kích hoạt liên tục...
...giống như khi bạn đang bật bot, bạn cần nhập [Set m on]
Bạn cần nhập [Set mm] để tắt trạng thái [Set m on] nếu không muốn sử dụng.
Để cài đặt, bạn cần thêm nhân vật,
-Kế tiếp, chọn skill Manashield từ danh sách và click Save

Lưu ý: 
-Lệnh kích hoạt Manashield chỉ có hiệu lực với người ra lệnh
-Nếu bạn đổi sang profile khác để sử dụng, bạn cần cấu hình lại trong này.
"""

ScriptHelpEn_ = """
If you do not want your character to auto buy/sell items after each...
...return to the town, you can use the Script feature of this plugin.
This is a feature that allows characters to auto buy/sell items in the town,...
...when you activate it with the [Set s] command.
First of all, you need to setup in the Script menu as follows:
-Select the town you want to buy/sell/store items
-Wait: is the waiting time between entering the guild storage for each character
Next, go to phbot and setup:
-Menu Town: you setup the items you need to buy.
-Menu pick filter: you setup the items you need to sell/store
-Menu Training: Select Script tab => (Enable) Skip town script entirely
Note:
-You can go path /Config/ChatControl/ to edit the script file if needed.
-DoGuildStorage: has the function of calculating waiting time for characters
-NotifyFinishScript: has the function to notify when the script is completed
"""

ScriptHelpVi_ = """
Nếu bạn không muốn nhân vật tự động mua/bán item sau mỗi lần về thành...
...bạn có thể sử dụng chức năng Script của plugin này.
Đây là một chức năng cho phép nhân vật tự động mua/bán item trong thành...
...khi bạn kích hoạt bằng lệnh [Set s]
Trước hết, bạn cần cài đặt trong menu Script như sau:
-Lựa chọn thị trấn bạn muốn mua/bán/lưu trữ item
-Wait: là thời gian chờ giữa các lần vào kho guild cho mỗi nhân vật
Sau đó, bạn vào phbot và chỉnh sửa các mục sau:
-Menu Town: bạn cài đặt những item mà bạn cần mua.
-Menu pick filter: bạn cài đặt những item mà bạn cần bán/lưu trữ
-Menu Training: Chọn tab Script => (Enable) Skip town script entirely
Lưu ý:
-Bạn có thể vào trong /Config/ChatControl/ để chỉnh sửa file script nếu cần.
-DoGuildStorage: có chức năng tính thời gian chờ cho các nhân vật
-NotifyFinishScript: có chức năng thông báo khi hoàn thành script
"""

CureHelpEn_ = """
The Cure menu simply targets your own character every time you use...
...the Force Cure skill to cure abnormalities during combat.

To setup, select the skill from the list and enter the key to call the skill.
To activate you need to enter [Set c], to disable you need to enter [Set cc]
Enter sword/sword and shield at the same time if you want to equip before solving.
Auto resolves Hemorrhage and Disintegration if you choose Auto pill or Auto skill.
All level: Scan all currently abnormalities to find Hemorrhage and Disintegration.
Finally, right-click on the smiling icon to activate the neutralization effect.
Note:
- Enter the game, press the a key, select the smiling icon at position 2.
- Now, pressing the smiling icon will replace the force cure skill icon.
"""

CureHelpVi_ = """
Menu Cure chỉ đơn làm nhiệm vụ target vào chính nhân vật của bạn mỗi khi bạn...
... sử dụng skill Force Cure để hoá giải dị trạng trong khi chiến đấu.
Để cài đặt, bạn chọn skill từ danh sách và nhập phím cần gọi skill.
Cần nhập đồng thời kiếm/đao/pháp bổng và khiên nếu muốn tự trang bị trước khi giải.
Tự động giải dị trạng Xuất huyết và Tan dã nếu chọn thuốc(pill) hoặc skill.
All level: Quét hết các dị trạng đang đang bị nhiễm để tìm ra Xuất huyết và Tan dã.
Để kích hoạt, bạn cần nhập [Set c], để tắt bạn cần nhập [Set cc]
Cuối cùng, click chuột phải vào biểu tượng mỉm cười để kích hoạt hoá giải dị trạng.
Lưu ý:
- Vào trong game, bấm phím a, chọn biểu tượng mỉm cười ở vị trí số 2.
- Bây giờ, bấm biểu tượng mỉm cười sẽ thay thế cho biểu tượng skill hoá giải.

"""

GhostHelpEn_ = """
Auto Ghost is a feature that auto activates exchange with enemy when fighting.
To setup, first, you need to add a character =>Add Char =>Edit Char,
-Next, add the skills that you want to activate ghost every time you use the skill.
-Cut(ms): is the delay from the moment you start the skill(start dancing)
-Auto Key: select the next key to automatically press if the skill is activated.
-Exchange slot: is where you place the exchange icon.

Note:
-You should use the python menu to get the exact skill name for the list.
-This feature is only valid for the commanding character.
-To activate you need to enter [Set g], to disable you need to enter [Set gg]
-You should turn off this feature immediately after not using it.
"""

GhostHelpVi_ = """
Auto Ghost là chức năng tự động kích hoạt giao dịch với đối thủ khi chiến đấu.
Để cài đặt, đầu tiên, bạn cần thêm nhân vật =>Add Char =>Edit Char,
-Kế tiếp, thêm các skill mà bạn muốn kích hoạt ghost mỗi khi sử dụng skill.
-Cut(ms): là thời gian ngắt skill tính từ lúc bạn bắt đầu skill(bắt đầu múa)
-Next Key: chọn một phím kế tiếp để tự động bấm nếu skill được kích hoạt.
-Wait Key: Nhập vào phím mà phím Next key sẽ tự động bấm nếu skill được kích hoạt.
-Config F: Cấu hình trang bị vũ khí khiên cho các thanh F khi chuyển đổi, xem clip 
-ReClick: Cho phép tự động click lại nếu lần click trước đó không xuất skill
-Ghost Boss: Tự ghost quái vật, chọn không đánh quái nếu đang ở chế độ botting
Lưu ý:
-Biểu tượng giao dịch cần phải đặt ở slot số 0 của cả 4 thanh F để sử dụng được 4F
-Bạn nên sử dụng menu python để lấy được tên skill chính xác cho danh sách.
-Để kích hoạt, bạn cần nhập [Set g], để tắt bạn cần nhập [Set gg]
-Bạn nên tắt chức năng này ngay sau khi không sử dụng.
"""

GuardHelpEn_ = """
Auto Guard is a feature that auto equip the shield when it detects that...
...enemy is using a very strong skill to hit you during battle.
To setup, first you need to add a character to the list =>Edit Char,
-Next, add the names of your enemy's skills into the list where...
...you want to equip the shield if your enemy uses these skills.
-%HP: Only activate Guard if the character's health is below this threshold.
-Delay(ms): Is the delay time to equip the shield from the moment you...
...realize the enemy uses the skill(starts dancing) to attack your character.
-Next, input the shield name(required) and blade name (if any)
-Next, you need to add the game path(required)
-Next, add the option to lock keys immediately after equipping the shield...
...to avoid using combat skills that can unequip the shield before...
...the enemy's damage hits the character.
-Lock until, press: lock time(ms) or unlock key(if you want)
Note: There is a guide in log to activating vigor HP when start auto guard
"""

GuardHelpVi_ = """
Auto Guard là chức năng tự trang bị khiên khi nhận ra đối thủ đang sử dụng...
...một skill rất mạnh đánh vào bạn trong khi chiến đấu.
Để cài đặt, đầu tiên bạn cần thêm nhân vật vào danh sách =>Edit Char,
-Kế tiếp, nhập tên các skills của đối thủ vào danh sách mà bạn muốn...
...trang bị khiên nếu đối thủ sử dụng những skill này.
-%HP: Chỉ kích hoạt Guard nếu lượng máu của nhân vật dưới ngưỡng này.
-Delay(ms): Là thời gian trễ để trang bị khiên tính từ lúc nhận ra đối thủ...
...sử dụng skill(bắt đầu múa) để đánh nhân vật của bạn.
-Kế tiếp, bạn nhập tên khiên(bắt buộc) và tên blade(nếu có)
-Kế tiếp, bạn cần thêm đường dẫn game(bắt buộc)
-Kế tiếp, thêm tuỳ chọn các phím muốn khoá ngay sau khi trang bị khiên...
...để tránh trường hợp bạn sử dụng những skill chiến đấu có thể tháo khiên...
...trước khi damage của đối thủ chạm vào nhân vật.
-Lock until, press: thời gian khoá(tính bằng ms) hoặc phím mở khoá(nếu muốn)
Chú ý: Có hướng dẫn trong nhật ký phbot để bạn kích hoạt máu tím nếu muốn.
"""

GuardHelpLogEn_ = """
Plugin [%s]: If you want to pump HP or vigor health after equipping the shield, you need to go to the Conditions menu in phbot and add the following conditions:
Conditions 1 and 2:
- Input: select [Python], and input[GetEnableCondition]
- Output: select [Use item], and select HP or Vigor name you want to use
Condition 3:
- Input: select [Python], and input[GetEnableCondition]
- Output: select [Python], and input[SetDisableCondition]
Last, it should look like this:
if (Python == GetEnableCondition) {(Use item) (HP Recovery Potion (X-Large));}
if (Python == GetEnableCondition) {(Use item) (Vigor Recovery Potion (X-Large));}
if (Python == GetEnableCondition) {Python (SetDisableCondition);}
"""
GuardHelpLogVi_ = """
Plugin [%s]: Nếu bạn muốn bơm máu hoặc máu tím sau mỗi lần trang bị khiên, bạn cần vào menu Conditions trong phbot và thêm các điều kiện như sau:
Điều kiện 1 và 2:
- Đầu vào: chọn [python], và nhập [GetEnableCondition]
- Đầu ra: chọn [Use item], và chọn máu hoặc máu tím bạn muốn sử dụng
Điều kiện 3:
- Đầu vào: chọn [Python], và nhập [GetEnableCondition]
- Đầu ra: chọn [Python], và nhập [SetDisableCondition]
Sau khi hoàn thành các điều kiện, nó phải có dạng như sau:
if (Python == GetEnableCondition) {(Use item) (HP Recovery Potion (X-Large));}
if (Python == GetEnableCondition) {(Use item) (Vigor Recovery Potion (X-Large));}
if (Python == GetEnableCondition) {Python (SetDisableCondition);}
"""

ChangePtHelpEn_ = """
This menu is used to automatically log in/out the character.
From/To to calculate the login/logout green time
Town to buy and sell, store items, run scripts, Town must set the respawn point.
Dead/last to DCN to go to training, if not selected, char will run to training.
Items Store to store equipment in the guild warehouse after the green time is over.
Fully equip so that all items are equipped instead of just checking weapons.
Pt to wait for enough members, wait up to 10 minutes if not enough will go to training.
Storing equipment after farming is configured in the items menu.
Note when configuring to use this menu:
- If using manager to manage:
++ Required to initialize Start Once
++ Select silkroad client (line 6)
++ Select Reconect on disconect (line 2)
- If not using Manager (only using phbot):
++ Must also select the function of line 6 and line 2 similar to Manager
++ Must have a pre-configured training area
"""
ChangePtHelpVi_ = """
Menu này sử dụng để tự động đăng nhập/đăng xuất nhân vật.
Cấu hình From/To để tính giờ xanh login/logout, cần cấu hình đúng cú pháp.
Chọn Town để mua bán, lưu trữ items, chạy script, Town phải đặt điểm hồi sinh.
Chọn Dead/last để DCN lên bãi, nếu không chọn, nhân vật sẽ chạy bộ lên bãi.
Chọn Items Store để lưu trữ thiết bị vào kho guild sau khi đã hết giờ xanh.
Chọn Fully equip để mọi items đều được trang bị thay vì chỉ kiểm tra mỗi vũ khí.
Chọn Pt để đợi đủ số lượng thành viên, chờ tối đa 10 phút nếu không đủ sẽ lên bãi.
Lưu trữ trang bị sau khi farm được cấu hình tại menu items.
Lưu ý khi cấu hình để sử dụng menu này:
- Nếu sử dụng manager để quản lý:
++ Bắt buộc khởi tạo Start Once(Bắt đầu 1 lần)
++ Chọn silkroad client(dòng 6)
++ Chọn Reconect on disconect(dòng 2)
- Nếu không dùng Manager(chỉ dùng phbot):
++ Cũng phải chọn chức năng của dòng 6 và dòng 2 tương tự Manager
++ Cần phải có vùng training đã được cấu hình sẵn
"""

CopyConfigHelpEn_ = """
This is the function to copy phbot configuration from character to other characters.
The function is divided into three parts:
Part 1:
- Data source to copy, you need to select the server and choose a character in that server.
- If you change server, you should press Reload chars button, it will list the characters again.
- You need to select an item in the Copy Menu list if you want to copy all or just one menu.
Part 2:
- Destination, you also need to select server and enter character who needs to receive new data.
- Select Chat reload if you want to send a message requesting to reload the object's configuration.
Part 3:
- Click Start copy to copy the config data.
- Click restore button to restore
Note:
- If you want to copy all configurations, just select All menus from the Copy Menu list.
- Do not copy the character config to another server, because the two servers may not synchronize data.
- The software only copies the default profile to the default profile of another character.
"""
CopyConfigHelpVi_ = """
Đây là chức năng copy cấu hình phbot từ nhân vật sang các nhân vật khác.
Chức năng được chia thành ba phàn:
Phần 1: 
- Nguồn dữ liệu để copy, bạn cần chọn server và chọn một nhân vật trong server đó.
- Nếu bạn thay đổi server, bạn nên bấm nút Reload chars, nó sẽ liệt kê lại các nhân vật.
- Bạn cần chọn một mục trong danh mục Menu copy nếu bạn muốn copy hết hay chỉ copy 1 menu.
Phần 2:
- Đích đến, bạn cũng cần chọn server và nhập tên nhân vật cần nhận dữ liệu mới.
- Chọn mục Chat reload nếu muốn gửi một tin nhắn yêu cầu reload cấu hình cho đối tượng.
Phần 3:
- Bấm nút Start copy để sao chép cấu hình với nội dung trong danh mục copy menu.
- Bấm nút Restore để phục hôi cấu hình nếu trước đó có sự nhầm lẫn trong việc sao chép.
Lưu ý:
- Nếu muốn copy hết cấu hình, chỉ cần chọn All menu từ danh sách Menu copy.
- Không nên copy cầu hình nhân vật khác server, vì hai server có thể không đồng bộ dữ liệu.
- Phần mềm chỉ copy tù profile mặc định của nhân vật này sang profile mặc định của nhân vật khác.

"""

JobRadaHelpEn_ = """
This is the function to detect hunters/traders or Thieves
- It will send notify when it founded object, and repeat if no one shows up.
- The Start/Stop button will maintain its state during every login session.
- There are 4 params to embed in the notification(time, name, loc, coord)
- The wait option is wait for a reminder to be sent if an ally is not present.
- From Team: Makes a voice if Union announces that a hunter/thieft has been found.
Page 2:
- Enter name destination and click convert to re-translate the current location.
- Click Add Slient zone to add locations to the list of not sending notifications.
- Click Get Zone name to receive the name of the location you are standing at.
Note: Remember to press the save and reload buttons before pressing start.
"""
JobRadaHelpVi_ = """
Đây là chức năng dò tìm hunters/traders hoặc Thieves
- Nó sẽ gửi thông báo khi tìm thấy đối tượng, và nhắc lại nếu không thấy ai lên.
- Nút Start/Stop sẽ giữ nguyên trạng thái trong mọi phiên đăng nhập.
- Có 4 tham số để bạn nhúng vào thông báo(thời gian, tên, địa điểm, toạ độ)
- Lựa chọn wait là số phút để chờ gửi nhắc nhở nếu không thấy đồng minh có mặt.
- Downtime: Khoảng thời gian tối thiểu giữa hai lần thông báo liên tiếp.
- From Team: Phát ra giọng nói nếu liên minh thông báo đã tìm thấy hunter/thieft.
Trang 2:
- Nhập name destination và nhấn convert để việt hoá lại địa điểm đang đứng.
- Bấm Add Slient zone để thêm địa điểm vào danh sách không gửi thông báo.
- Bấm Get Zone name để nhận tên địa điểm đang đứng.
Lưu ý: Nhớ bấm nút lưu khi chỉnh sửa xong, và reload trước khi bấm start.
Khi gửi thông báo tới chính bạn, sẽ có em gái mưa thông báo bằng giọng nói.
Chỉ có các nhân vật nằm trong danh sách mới có thể gửi thông báo.
"""

BuyF10HelpEn_ = """
This is the function to buy items in F10
The Start/Stop button will keep state until Stop/Start is pressed again.
The Check state button will check the characters in Start/Stop state
The first time you configure, you need to sample the items you will buy in F10.
To get sample, let press Begin sample, then go into the game, open F10,...
...purchase items to be sampled, purchase qty of 1 for each sample.
When you click End sample to stop sampling, items will save in the sample list.
Select from the sample list the items to buy, enter qty and conditions...
...then click Add item, it will be included in the to-buy list.
If you choose Extension pet, pick pet will be extended(need to have pet)
If you choose Buy GoldTime, you will buy golden hour tickets when it expire.
If you choose to relogin, after purchasing, it will auto disconnect and relogin.
The purchase scanning cycle should be 30 minutes or more for optimal results.
Enter the command Set b or Set bb to start or stop, this command has a suffix.
Note: Qty to buy is calculated by package, conditions are calculated by unit.
"""
BuyF10HelpVi_ = """
Đây là chức năng mua các vật phẩm item trong F10
Nút Start/Stop sẽ giữ trạng thái Start/Stop trong mọi phiên đăng nhập.
Nút Check state sẽ kiểm tra các nhân vật trong trạng thái Start/Stop
Lần đầu tiên cấu hình, bạn cần lấy mẫu các item sẽ mua trong F10.
Để lấy mẫu, bạn cần bấm nút Begin sample, sau đó vào game, mở F10,...
...mua các vật phẩm cần lấy mẫu, mua số lượng 1 cho mỗi mẫu.
Khi bạn bấm End sample để dừng lấy mẫu, các mẫu sẽ được đưa vào danh sách mẫu.
Chọn từ danh sách mẫu những item cần mua, nhập số lượng mua và điều kiện...
...sau đó bấm Add item, nó sẽ được đưa vào danh sách cần mua.
Nếu chọn Extension pet, sẽ gia hạn pet nhặt đồ(cần có sẵn pet trong kho)
Nếu chọn Buy GoldTime, sẽ mua vé giờ vàng khi hết hạn sử dụng.
Nếu chọn relogin, sau khi mua xong sẽ tự động disconnect và reconnect.
Nếu chọn DCN, hãy bỏ chọn relogin
Nhập lệnh Set b hoặc Set bb để start hoặc stop, lệnh này có hậu tố.
Lưu ý: Số lượng cần mua tính theo gói trong F10, điều kiện tính theo đơn vị.
"""

MoveMeOnHelpEn_ = f"""
You can activate this function by clicking on the hello icon(first position) instead of using the chat command
Enter the command [Move me on] or [Move me icon] to enable; Enter [Move meme] to disable
"""
MoveMeOnHelpVi_ = f"""
Bạn có thể kích hoạt chức năng này bằng click chuột vào biểu tượng chào(vị trí đầu tiên) thay vì dùng lệnh chat
Bạn nhập lệnh [Move me on] hoặc [Move me icon] để kích hoạt; bạn nhập [Move meme] để huỷ
"""

SupportToken = ""

xTrans = {
    "1": ("        Tiếng Việt        ",
          "        English        "),
    "2": ("   Menu Guide   ",
          "   Hướng Dẫn Menu   "),
    "3": ("   Access Menu   ",
          "   Truy cập Menu   "),
    "4": ("Guild/Players",
          "Guild/Players"),
    "5": ("Move Commands",
          "Các lệnh Move"),
    "6": ("Set Commands",
          "Các lệnh Set"),
    "7": ("ExMap Menu",
          "Menu ExMap"),
    "8": ("FixMap Menu",
          "Menu FixMap"),
    "9": ("Weapon/Shield",
          "Vũ khí/Khiên"),
    "10": ("Storage/Take Items",
           "Gửi/Lấy Items"),
    "11": ("Python",
           "Python"),
    "12": ("Remove Player",
           "Xoá Player"),
    "13": ("Remove Guild",
           "Xoá Guild"),
    "15": ("Select a value in the Original list then input shortcut name.",
           "Lựa chọn 1 giá trị trong danh sách gốc sau đó nhập tên shortcut."),
    "16": ("Original Name List",
           "Danh Sách Tên Gốc"),
    "17": ("Shortcuts List",
           "Danh Sách Shortcuts"),
    "18": ("Add Shortcut =>",
           "Add Shortcut =>"),
    "19": ("Del Shortcut <=",
           "Del Shortcut <="),
    "20": ("View Character List",
           "Danh sách nhân vật"),
    "21": (
        "Plugin [%s] v %s loaded: Keyboard module not found in library, you will be able to use all utilities, except Ghost and Cure",
        "Plugin [%s] v %s loaded: Không tìm thấy module Keyboard trong thư viện, bạn sẽ sử dụng được hết các chức năng, ngoại trừ Ghost và Cure"),
    "22": ("Plugin [%s] v%s succesfully loaded",
           "Plugin [%s] v%s đã nạp thành công"),
    "23": ("Teleport",
           "Teleport"),
    "24": ("ManaShield",
           "ManaShield"),
    "25": ("Script",
           "Script"),
    "26": ("Auto Ghost",
           "Auto Ghost"),
    "27": ("Auto Cure",
           "Auto Cure"),
    "28": ("Plugin [%s]: Reset default language mode: %s",
           "Plugin [%s]: Đã đặt lại chế độ ngôn ngữ mặc định: %s"),
    "29": ("Auto Guard",
           "Auto Guard"),
    "30": ("Plugin [%s]: [%s] already exists.",
           "Plugin [%s]: [%s] đã tồn tại trước đó"),
    "31": ("Plugin [%s]: [%s] contains spaces.",
           "Plugin [%s]: [%s] có chứa khoảng trắng."),
    "32": ("Plugin [%s]: Successfully reset the %s commands.",
           "Plugin [%s]: Đã reset thành công tập lệnh [%s]"),
    "33": ("Plugin [%s]: Successfully saved the %s commands.",
           "Plugin [%s]: Đã lưu thành công tập lệnh [%s]"),

    "34": ("Plugin [%s]: You need to modify code [%s] again before saving.",
           "Plugin [%s]: Bạn cần sửa đổi lại mã [%s] trước khi lưu"),

    "35": ("Plugin [%s]: Error with duplicate code name.",
           "Plugin [%s]: Lỗi trùng tên code"),
    "36": ("Plugin [%s]: Code [%s] cannot be left blank.",
           "Plugin [%s]: Mã code [%s] không được để trống"),
    "37": ("Plugin [%s]: Success! Remember to reload before using",
           "Plugin [%s]: Thực hiện thành công! Bạn nhớ reload trước khi sử dụng"),
    "38": ("Plugin [%s]: [%s] is not valid.",
           "Plugin [%s]: [%s] không hợp lệ"),
    "39": ("Reset Shortcut",
           "Reset Shortcut"),

    "40": ("Plugin [%s]: [%s] contains comma.",
           "Plugin [%s]: [%s] có chứa dấu phẩy."),
    "41": ("Plugin [%s]: [%s] does not exist in data.",
           "Plugin [%s]: [%s] không tồn tại trong dữ liệu."),
    "42": (
        "Plugin [%s]: You have disabled [walk], the system will not auto equip the shield when you dodge enemy or run.",
        "Plugin [%s]: Bạn đã disiable [walk], hệ thống sẽ không tự trang bị shield khi bạn né tránh đối thủ hoặc chạy bộ."),

    "43": ("Plugin [%s]: Result of python function [%s%s]:",
           "Plugin [%s]: Kết quả của hàm python [%s%s]:"),

    "44": ("Notice: You don't have manashield so you can't add it to the usage list.",
           "Lưu ý: Bạn không có manashield nên không thể thêm vào danh sách sử dụng."),
    "44b": ("Notice: Skills will be added to the current profile if you click save.",
            "Lưu ý: Skill sẽ được thêm vào profile đang sử dụng nếu bạn click Save."),

    "45": ("Plugin [%s]: You can delete, but you are not allowed to update skill to [%s]",
           "Plugin [%s]: Bạn có thể xóa nhưng không được phép cập nhật skill cho [%s]"),
    "46": (
        "Plugin [%s]: Updated skill [%s] to conditions catalogue in character's profile [%s].",
        "Plugin [%s]: Đã cập nhật skill [%s] vào Condition trong profile [%s] của nhân vật."),

    "47": ("Plugin [%s]: Removed manashield activation condition in phBot",
           "Plugin [%s]: Đã xoá điều kiện kích hoạt manashield trong phBot"),
    "48": ("Notice: You don't have Force Cure Skill so you can't add it to the usage list.",
           "Lưu ý: Bạn không có Force Cure Skill nên không thể thêm vào danh sách sử dụng."),

    "49": ("_________________",
           "_________________"),

    "50": ("Plugin [%s]: You need to select a character from the list to update the items.",
           "Plugin [%s]: Bạn cần lựa chọn một nhân vật trong danh sách để cập nhật các item"),

    "51": ("Plugin [%s]: You need to scan and select the game folder path before saving.",
           "Plugin [%s]: Bạn cần quét và lựa chọn đường dẫn thư mục game trước khi lưu."),
    "52": ("Select skill name or tele source NPC, then input name and press search button!",
           "Lựa chọn tên skill hoặc nguồn tele, sau đó nhập tên và nhấn nút tìm kiếm!"),
    "53": ("Plugin [%s]:You need to scan the game path and save so the system has search data.",
           "Plugin [%s]:Bạn cần scan đường dẫn game và lưu lại để hệ thống có dữ liệu tìm kiếm."),

    "54": ("Plugin [%s]:Did not receive returned data, you need to recheck the name [%s]",
           "Plugin [%s]:Không nhận được dữ liệu trả về, bạn cần kiểm tra lại tên [%s]"),

    "55": (
        "Plugin [%s]: This version of the plugin prevents you from updating both rings with the same name and plus index.",
        "Plugin [%s]: Phiên bản plugin này ngăn cản bạn cập nhật cả hai nhẫn có cùng tên và cùng chỉ số cộng."),
    "56": ("Plugin [%s]:You have %s days left to use the plugin. We will be happy if you extend the usage date(3 months/10$) to support the author!",
           "Plugin [%s]:Bạn còn %s ngày để sử dụng plugin. Chúng tôi sẽ rất vui nếu bạn gia hạn ngày sử dụng(gói 3 tháng/200k) để ủng hộ tác giả!"),

    "57": ("Plugin [%s]: Plugin shelf life is %s days.",
           "Plugin [%s]: Thời hạn sử dụng plugin còn lại %s ngày."),
           
    "58": ("Chương mục khắc phục lỗi nếu server cấm phbot(thêm tên server đang cấm vào danh sách)",
           "Chương mục khắc phục lỗi nếu server cấm phbot(thêm tên server đang cấm vào danh sách)"),
    "59": ("Plugin [%s]: Thank you for renewing to use the plugin! If the functions are not unlocked, you need to reload.",
           "Plugin [%s]: Cảm ơn bạn đã gia hạn sử dụng plugin! Nếu các chức năng chưa được mở khóa, bạn cần reload."),           
    "60": ("Plugin [%s]: Upgraded successfully! You need to restart phBot to use the latest plugin version!",
           "Plugin [%s]: Nâng cấp thành công! Bạn cần khởi động lại phBot để sử dụng phiên bản plugin mới nhất!"),
    "61": ("Plugin [%s]: An error occurred while updating the plugin, please restart phBot and try again. You need support if the update fails!",
           "Plugin [%s]: Có lỗi xảy ra trong khi cập nhật plugin, vui lòng khởi động lại phBot và thử lại lần nữa. Bạn cần sự hỗ trợ nếu cập nhật không thành công!"),
    "62": ("Plugin [%s]: Warning: If you are sharing plugin, we will stop updates and may block licenses if we discover this.",
           "Plugin [%s]: Cảnh báo: Dường nhu bạn đang chia sẻ plugin, chúng tôi sẽ dừng cập nhật và có thể khoá license nếu phát hiện ra điều này."),           
    "63": ("Plugin [%s]: Enter the key you need to press in the Press Key section to activate Auto Cure",
           "Plugin [%s]: Bạn nhập phím cần bấm trong mục Press Key để kích hoạt hoá giải di trạng"),          
    "64": ("Notice: If change to another profile, you need to reconfigure auto cure.\nAdd Sword and Shield if you want to auto equip.\nClick on the smile icon to activate.",
           "Lưu ý: Nếu đổi sang profile khác, bạn cần cấu hình lại auto cure.\nThêm Kiếm và Khiên nếu muốn tự động trang bị trước khi hoá giải.\nClick chuột vào biểu tượng mỉm cười(smile) để kích hoạt."),          
    "65": ("Plugin [%s]: Shield and Shield Skill are required",
           "Plugin [%s]: Shield và Skill của Shield là bắt buộc"),           
    "66": ("Plugin [%s]: You haven't created the game path in the python menu!",
           "Plugin [%s]: Bạn chưa tạo đường dẫn game trong menu python!"),  
    "67": ("Plugin [%s]: Error: There is no item in the list.",
           "Plugin [%s]: Lỗi: chưa có item trong danh sách."), 
    "68": ("Plugin [%s]: Sampling is starting, you have up to 5 minutes to collect the sample.",
           "Plugin [%s]: Lấy mẫu đang bắt đầu, bạn có tối đa 5 phút để lấy mẫu."),           
    "69": ("Plugin [%s]: Sampling has stopped, go to the sample list to see the results!",
           "Plugin [%s]: Đã dừng lấy mẫu, bạn vào danh sách mẫu để xem kết quả!"),         
    "70": ("Plugin [%s]: [%s] was not added to the list but has been configured.",
           "Plugin [%s]: [%s] không được thêm vào danh sách nhưng đã được cấu hình."),        
    "71": ("Plugin [%s]: Copied the configuration from [%s] to [%s], you should check the data again before starting.",
           "Plugin [%s]: Đã copy cấu hình từ [%s] sang [%s], bạn nên kiểm tra lại dữ liệu trước khi start."),        
    "72": ("Plugin [%s]: An error occurred, code:[%s], you need to copy the error code and contact us immediately to resolve the problem!",
           "Plugin [%s]: Có lỗi xảy ra, mã lỗi:[%s], bạn cần copy mã lỗi và liên hệ ngay để giải quyết vấn đề!"),   
    "73": ("Plugin [%s]: Note: You need to check the game path in the python menu to make sure it has been configured correctly for each character added to the list.",
           "Plugin [%s]: Lưu ý: Cần kiểm tra lại đường dẫn game trong menu python để chắc chắn đã được cấu hình chính xác cho từng nhân vật đã thêm vào danh sách."), 
    "74": ("Plugin [%s]: Note: Characters will not automatically equip shields if they do not have a sword or blade",
           "Plugin [%s]: Lưu ý: Nhân vật sẽ không tự động trang bị khiên nếu không có kiếm hoặc đao ngắn"),             
    "75": ("Plugin [%s]: Cannot be left blank",
           "Plugin [%s]: Không được để trống"), 
    "76": ("Plugin [%s]: Error while executing copy command.",
           "Plugin [%s]: Lỗi trong khi thực hiện lệnh copy."), 
    "77": ("Plugin [%s]: Warning: You have copied the configuration of two different servers, you should check the data consistency of the two servers to make sure there are no errors when logging in.",
           "Plugin [%s]: Cảnh báo: Bạn đã copy cấu hình của hai server khác nhau, bạn nên kiểm tra sự đồng nhất về dữ liệu của hai server để chăc chắn không bị lỗi khi đăng nhập."),            
    "78": ("Plugin [%s]: Copy successfully: from [%s] copied to [%s]. You should restart the [%s] character to get the new configuration if it is logged in.",
           "Plugin [%s]: Đã copy thành công: từ [%s] đã copy tới [%s]. Bạn nên khởi động lại nhân vật [%s] hoặc nhập lệnh [Set py reload_profile] để nhận cấu hình mới nếu nó đang đăng nhập."),           
    "79": ("Plugin [%s]: Reloaded character list in server [%s]",
           "Plugin [%s]: Đã nạp lại danh sách nhân vật trong server [%s]"),
    "80": ("Plugin [%s]: The reload configuration command was not sent to [%s]",
           "Plugin [%s]: Tin nhắn reload cấu hình đã không được gửi đến [%s]"),         
    "81": ("Plugin [%s]: No data found to recover for [%s]",
           "Plugin [%s]: Không tìm thấy dữ liệu để phục hồi cho [%s]"),      
    "82": ("Plugin [%s]: The plugin's license has been locked due to violating commercial copyright policy.",
           "Plugin [%s]: License của plugin đã bị khoá do vi phạm chính sách bản quyền thương mại."),   
    "83": ("Plugin [%s]: The license has been unlocked, you need to restart the bot for it to take effect.",
           "Plugin [%s]: Đã mở khoá license, bạn cần khởi động lại bot để có hiệu lực."),   
    "84": ("Plugin [%s]: Refuse to unlock license.",
           "Plugin [%s]: Từ chối mở khoá license."),      
    "85": ("Plugin [%s]: Temporarily disable all features.",
           "Plugin [%s]: Tạm khoá mọi chức năng do có điều gì bất thường đang xảy ra."),              
    "86": ("Plugin [%s]: You need to choose a pet that is available in the inventory and is different from the pets of other characters..",
           "Plugin [%s]: Bạn cần chọn 1 con pet có sẵn trong kho và khác loại với pet của các nhân vật khác."),            
    "87": ("Plugin [%s]: Pet saved successfully.",
           "Plugin [%s]: Đã lưu pet thành công."),            
    "88": ("Plugin [%s]: There is no pet %s in inventory.",
           "Plugin [%s]: Không có pet %s trong hòm đồ, lưu ý bắt buộc pet được mua 10 loại cơ bản trong F10, không phải pet miễn phí.\nCác pets có tên tiếng việt tương ứng như sau:\n[Rabbit: Con Thỏ, Spotted Rabbit: Thỏ đốm, Squirrel: Con Sóc, Monkey: Con Khỉ, Raccoon dog: Gấu Chó, Cat: Linh miêu, Sylph: Tiểu tiên nữ, Great Glider: Cánh lớn, Gold Pig: Heo vàng, Pink Pig: Heo hồng]"),            
    "89": ("Plugin [%s]: Mã cấu hình cho các thanh F cần bỏ trống hoặc được viết theo dạng: f1 1 f2 12 f3 1",
           "Plugin [%s]: Mã cấu hình cho các thanh F cần bỏ trống hoặc được viết theo dạng: f1 1 f2 12 f3 1"),              
    "90": ("Plugin [%s]: Có lỗi xảy ra khi lắng nghe phím [%s], có thể bạn cần stop và start lại để giải quyết vấn đề",
           "Plugin [%s]: Có lỗi xảy ra khi lắng nghe phím [%s], có thể bạn cần stop và start lại để giải quyết vấn đề"),             
    "91": ("Plugin [%s]: Nội dung lỗi như sau: %s",
           "Plugin [%s]: Nội dung lỗi như sau: %s"), 
    "92": ("Plugin [%s]: Error found when import data",
           "Plugin [%s]: Có lỗi trong khi nạp dữ liệu"),           
    "93": ("Plugin [%s]: Plugin not working due to insufficient data",
           "Plugin [%s]: Plugin không hoạt động do chưa đủ dữ liệu"),  
    "94": ("Plugin [%s]: ReClicked [%s] key to activate %s key",
           "Plugin [%s]: Đã bấm lại(ReClick) phím [%s] để kích hoạt phím %s"),            
    "95": ("Plugin [%s]: License not valid.",
           "Plugin [%s]: License không hợp lệ."),  
    "96": ("Plugin [%s]: Data loading...",
           "Plugin [%s]: Đang nạp dữ liệu..."),             
    "101": ("Plugin [%s]: Command type [%s %s] is invalid.",
            "Plugin [%s]: Kiểu lệnh [%s %s] không hợp lệ."),
    "102": ("Plugin [%s]: You need a party to use the command [%s %s].",
            "Plugin [%s]: Bạn cần có party để sử dụng lệnh [%s %s]."),
    "103": ("Plugin [%s]: Command was canceled because it waited more than 2 seconds but did not receive data.",
            "Plugin [%s]: Lệnh đã bị hủy vì đợi hơn 2 giây nhưng không nhận được dữ liệu."),
    "104": ("Plugin [%s]: Moved to [%s], pos(%s, %s, %s).",
            "Plugin [%s]: Đã dịch chuyển tới [%s], toạ độ(%s, %s, %s)"),
    "105": ("Plugin [%s]: No return scroll found.",
            "Plugin [%s]: Không tìm thấy cuộn giấy dịch chuyển."),
    "106": ("Plugin [%s]: The training area has been set to a new position: [X:%.1f,Y:%.1f]",
            "Plugin [%s]: Vùng training đã được thiết lập vị trí mới: [X:%.1f,Y:%.1f]"),
    "107": ("Plugin [%s]: Starting bot...",
            "Plugin [%s]: Đang bắt đầu bot..."),
    "108": ("Plugin [%s]: Stoping bot(if any)...",
            "Plugin [%s]: Đang tắt bot(nếu có)..."),
    "109": ("Plugin [%s]: Starting follow...",
            "Plugin [%s]: Đang bắt đầu follow..."),
    "110": ("Plugin [%s]: Stoping follow(if any)...",
            "Plugin [%s]: Đang tắt follow(nếu có)..."),
    "111": ("Waiting for %s(s) to into guild storage",
            "Dang doi %s(s) de vao kho guild"),

    "112": ("Plugin [%s]: Calling skill [%s]...",
            "Plugin [%s]: Đang gọi skill [%s]..."),
    "113": ("Plugin [%s]: [%s] mode with unlimited number of buffs [%s]",
            "Plugin [%s]: Đã [%s] chế độ không giới hạn số lần buff [%s]"),
    "114": ("Plugin [%s]: [%s] automatic switching between items when using corresponding skills",
            "Plugin [%s]: [%s] tự động chuyển đổi qua lại các item khi dùng skills tương ứng"),
    "115": ("Plugin [%s]: An error occurred related to [%s]",
            "Plugin [%s]: Có lỗi xuất hiện liên quan tới [%s]"),

    "116": ("Plugin [%s]: Value [%s] could not be determined in the data",
            "Plugin [%s]: Không xác định được giá trị[%s] trong dữ liệu"),
    "117": ("Plugin [%s]: Teleporting to [%s]",
            "Plugin [%s]: Đang tele tới [%s]"),
    "118": ("Plugin [%s]: Not found NPC",
            "Plugin [%s]: Không thấy NPC"),
    "119": ("Plugin [%s]: Teleport data not found, need to check the inputs again",
            "Plugin [%s]: Dữ liệu Teleport không thấy, cần kiểm tra lại các đầu vào"),
    "120": ("Plugin [%s]: Reloaded Success",
            "Plugin [%s]: Đã reload thành công"),
    "121": ("Plugin [%s]: Town name [%s] is not in the list: %s",
            "Plugin [%s]: Tên thị trấn [%s] không có trong danh sách: %s"),
    "122": ("Plugin [%s]: The training area has been changed to: [%s]",
            "Plugin [%s]: Vùng luyện tập đã được thay đổi sang: [%s]"),
    "123": ("Plugin [%s]: Training area [%s] not found in the list",
            "Plugin [%s]: Không tìm thấy vùng luyện tập [%s] trong danh sách"),
    "124": ("Plugin [%s]: The training radius has been changed to: %s(m)",
            "Plugin [%s]: Bán kính luyện tập đã đổi thành: %s(m)"),
    "125": ("Plugin [%s]: Moving to destination: (%s, %s)",
            "Plugin [%s]: Đang di chuyển tới toạ độ: (%s, %s)"),
    "126": ("Plugin [%s]: Executing command [%s %s]",
            "Plugin [%s]: Đang thực hiện lệnh [%s %s]"),
    "127": ("Left GuildStorage, it is ready for the next character.",
            "Da thoat kho guild"),
    "128": ("Plugin [%s]: [%s] %s",
            "Plugin [%s]: Đã [%s] %s"),

    "129": ("Plugin [%s]: %s [%s]",
            "Plugin [%s]: %s [%s]"),
    "130": ("Plugin [%s]: The name of skills are not accurate",
            "Plugin [%s]: Tên các skills để ghost chưa chính xác"),

    "131": (
        "Plugin [%s]: Running [%s] for [%s] times, total running time is [%s(minute)], remember to turn off after use.",
        "Plugin [%s]: Đang [%s] lần thứ [%s], tổng thời gian đang chạy là[%s(minute)], bạn nhớ tắt sau khi sử dụng."),

    "132": ("Plugin [%s]: Leaving the party...",
            "Plugin [%s]: Bạn đang rời party..."),
    "133": ("Plugin [%s]: The names %s skills not found data in game",
            "Plugin [%s]: Tên các skill %s không tìm thấy trong dữ liệu game"),
    "134": ("Plugin [%s]: Unlocked keys %s",
            "Plugin [%s]: Đã mở khoá các phím %s"),

    "135": ("Plugin [%s]: module not found",
            "Plugin [%s]: Không tìm thấy module"),

    "136": (
        "Plugin [%s]: To activate the [%s %s] command by clicking on the icon, you need input [on] or [icon] instead of [%s]",
        "Plugin [%s]: Để kích hoạt lệnh [%s %s] bằng click chuột vào biểu tượng, bạn cần nhập [on] hoặc [icon] thay vì [%s]"),
    "137": ("Plugin [%s]: Warning: Item [%s]+[%s] is not equipped, you need to check again.",
            "Plugin [%s]: Cảnh báo: Item [%s]+[%s] chưa được trang bị, bạn cần kiểm tra lại."),
    "138": ("Warning: Item [%s]+[%s] is not equipped.",
            "Warning: Item [%s]+[%s] is not equipped."),
    "139": ("Warning: Item [%s]+[%s] has not been stored in GuildStorage",
            "Warning: Item [%s]+[%s] has not been stored in GuildStorage"),
    "140": ("Plugin [%s]: Closed GuildStorage.",
            "Plugin [%s]: Đã thoát khỏi kho guild."),
    "141": ("Plugin [%s]: Opening GuildStorage...",
            "Plugin [%s]: Đang mở kho guild..."),
    "142": ("Plugin [%s]: Info - Item [%s]+[%s] is found in inventory before opening the guild storage ",
            "Plugin [%s]: Thông tin - Item [%s]+[%s] được tìm thấy trong kho cá nhân trước khi mở kho guild"),
    "143": ("Plugin [%s]: Infor - All items found in inventory before opening guild storage",
            "Plugin [%s]: Thông tin - Tất cả item được tìm thấy trong kho cá nhân trước khi mở kho guild"),
    "144": ("Plugin [%s]: Warning - Fully Guild Storage",
            "Plugin [%s]: Cảnh báo - Kho guil đã đầy"),
    "145": ("Warning - [%s] not found in inventory",
            "Warning - [%s] not found in inventory"),
    "146": ("Plugin [%s]: Warning - Fully Guild Storage.",
            "Plugin [%s]: Cảnh báo - Kho guild đã đầy."),
    "147": ("Plugin [%s]: The guild storage is full or there are no items to add to guild storage",
            "Plugin [%s]: Kho guild đã đầy hoặc không có item nào cần thêm vào kho guild"),
    "148": ("Plugin [%s]: Info - [%s] was previously equipped",
            "Plugin [%s]: Thông tin - [%s] được trang bị sẵn trước đó"),
    "149": ("Plugin [%s]: Storing [%s] to the guild storage...",
            "Plugin [%s]: Đang lưu trữ [%s] vào kho guild..."),
    "150": ("Plugin [%s]: Taking [%s] from guild storage...",
            "Plugin [%s]: Đang lấy [%s] từ kho guild..."),
    "151": ("The guild storage NPC is too far away.",
            "NPC kho guild ở quá xa."),
    "152": ("Not found NPC guild storage",
            "Không thấy NPC kho guild"),
    "153": ("Plugin [%s]: Info %s: [%s] needs to wait for [%s(s)] to enter the guild storage",
            "Plugin [%s]: Thông tin %s: [%s] cần đợi [%s(s)] để vào kho guild"),
    "154": (
        "Plugin [%s] v%s loaded: You need to restart phbot to reload data!",
        "Plugin [%s] v%s loaded: Bạn cần khởi động lại phbot để nạp lại dữ liệu!"),
    "155": ("Plugin [%s] v%s succesfully loaded",
            "Plugin [%s] v%s đã nạp thành công"),
    "156": ("Plugin [%s]: Guild storage is busy, trying to access times [%s]",
            "Plugin [%s]: Kho guild đang bận, đang cố gắng truy cập lần [%s]"),
    "157": ("Plugin [%s]: Cancel to the guild storage because it is busy and timed out",
            "Plugin [%s]: Huỷ bỏ vào kho guild do kho guild đang bận và hết thời gian chờ"),
    "158": ("Plugin [%s]: This version is not unlocked so you can move(reverse scroll) to the cave [%s]",
            "Plugin [%s]: Phiên bản này chưa mở khoá để bạn dịch chuyển tới hang động [%s]"),
    "159": (GuardHelpLogEn_,
            GuardHelpLogVi_),
    "160": (MoveMeOnHelpEn_,
            MoveMeOnHelpVi_),
    "161": ("Plugin [%s]: Profile has been changed: [%s]",
            "Plugin [%s]: Profile đã được thay đổi sang: [%s]"),
    "162": ("Plugin [%s]: Profile [%s] was not found in the list",
            "Plugin [%s]: Không tìm thấy profile [%s] trong danh sách"),            
    "163": ("Plugin [%s]: You are using a limited edition plugin",
            "Plugin [%s]: Bạn đang sử dụng plugin phiên bản giới hạn"),
    "164": ("Plugin [%s] v%s succesfully loaded. Some menus have been locked in the trial version, we hope for your understanding!",
            "Plugin [%s] v%s đã nạp thành công. Một số menu đã bị khoá trong phiên bản dùng thử, rất mong các bạn thông cảm! "),   
    "165": ("Plugin [%s]: An error appears, possibly due to lag on the computer or on the server.",
            "Plugin [%s]: Lỗi xuất hiện, có thể do lag trên máy tính hoặc trên server."),            
    "166": ("Plugin [%s]: Error buying item in F10, maybe out of silk, has paused purchasing in current login section waiting for you to resolve.",
            "Plugin [%s]: Lỗi mua item trong F10, có thể hết silk, đã tạm dừng mua hàng ở phiên đăng nhập hiện tại để chờ bạn giải quyết."),  
    "167": ("Plugin [%s]: Purchase has been paused in current login section because the purchase list is empty.",
            "Plugin [%s]: Đã tạm dừng mua hàng ở phiên đăng nhập hiện tại do danh sách mua hàng đang để trống."),  
    "168": ("Plugin [%s]: Purchased [%s] in quantity [%s] packs.",
            "Plugin [%s]: Đã mua [%s] với số lượng [%s] gói."),       
    "169": ("Plugin [%s]: The auto-purchase function in F10 has started with every login session, the scan cycle is [%s] minutes.",
            "Plugin [%s]: Chức năng tự động mua hàng trong F10 đã bắt đầu với mọi phiên đăng nhập, chu kỳ quét là [%s] phút."),     
    "170": ("Plugin [%s]: Renewed [%s].",
            "Plugin [%s]: Đã gia hạn [%s]."),     
    "171": ("Stopped buying f10, error empty silk.",
            "Đã tạm dừng mua f10, lỗi hết silk."),  
    "172": ("Stopped buying f10, error of full inventory.",
            "Đã tạm dừng mua f10, lỗi đầy kho."),   
    "173": ("Plugin [%s]: Stopped buying f10",
            "Plugin [%s]: Đã Stop mua hàng trong F10"),
    "174": ("Hide game window due to device lag",
            "Ẩn cửa sổ game do máy lag"),     
    "175": ("Plugin [%s]: Used [%s].",
            "Plugin [%s]: Đã sử dụng [%s]."), 
    "176": ("Plugin [%s]: Incorrect syntax of the Chat command was entered in the script",
            "Plugin [%s]: Đã nhập sai cú pháp của lệnh Chat trong Script"),     
    "177": ("Plugin [%s]: Do not automatically equip weapons or shields when you are in fortress.",
            "Plugin [%s]: Không tự động trang bị vũ khí hoặc khiên khi bạn đang công thành chiến."),       
    "178": ("Plugin [%s]: Temporarily lock the license because you have used it to log in to more computers than allowed.",
            "Plugin [%s]: Tạm khoá license vì bạn đã sử dụng nó để đăng nhập nhiều máy tính hơn mức cho phép."),             
    "179": ("Plugin [%s]: You are configuring a monster fight, not a person fight!",
            "Plugin [%s]: Bạn đang cấu hình đánh boss chứ đâu phải đánh người!"),        
    "180": ("Plugin [%s]: You are configuring to fight players, not monsters!",
            "Plugin [%s]: Bạn đang cấu hình đánh người chơi chứ đâu phải đánh quái!"),             
    "181": ("Plugin [%s]: Auto login/logout function has started to apply to all login sessions!",
            "Plugin [%s]: Chức năng auto login/logout đã bắt đầu áp dụng với mọi phiên đăng nhập!"),       
    "182": ("Plugin [%s]: Auto login/logout function has stopped for all login sessions!",
            "Plugin [%s]: Chức năng auto login/logout đã stop cho mọi phiên đăng nhập!"),   
    "183": ("Plugin [%s]: Current character status:[%s]",
            "Plugin [%s]: Trạng thái nhân vật hiện tại:[%s]"),   
    "184": ("Plugin [%s]: No character name in the list",
            "Plugin [%s]: Không có tên nhân vật trong danh sách"),   
    "185": ("Plugin [%s]: The system is activating the game client to prepare for login...",
            "Plugin [%s]: Hệ thống đang kích hoạt game client để chuẩn bị login..."),   
    "186": ("Plugin [%s]: Waited for more than 3 minutes but the character has not logged in...",
            "Plugin [%s]: Đã chờ đợi quá 3 phút mà nhân vật chưa login..."),    
    "187": ("Plugin [%s]: Waiting [%s]s for the system to activate auto login/farm",
            "Plugin [%s]: Đang đợi [%s]s để hệ thống kích hoạt auto login/farm"),     
    "188": ("Plugin [%s]: This is the case [%s] but not yet controlled: Connected-%s, Logined-%s, PressDis-%s",
            "Plugin [%s]: Đây là trường hợp [%s] nhưng chưa được kiểm soát: Connected-%s, Logined-%s, PressDis-%s"),     
    "189": ("Plugin [%s]: Green time is over, need to wait %ss for the system to automatically activate to town/logout",
            "Plugin [%s]: Giờ xanh đã hết, cần đợi %ss để hệ thống tự động kích hoạt về thị trấn/logout"),     
    "190": ("Plugin [%s]: An auto login function has been paused because you pressed the stop menu Auto login button.",
            "Plugin [%s]: Một chức năng của auto login đã tạm dừng do bạn đã bấm nút stop menu Auto login."),     
    "191": ("Plugin [%s]: Start bot enabled because character has enough items",
            "Plugin [%s]: Đã kích hoạt start bot do nhân vật có đủ đồ"),     
    "192": ("Plugin [%s]: Character is not equipped enough, looking for solutions to equip...",
            "Plugin [%s]: Nhân vật chưa trang bị đủ, đang tìm kiếm các giải pháp để trang bị..."),     
    "193": ("Plugin [%s]: It seems the character is stuck or the script is broken, waiting 30s to continue the script...",
            "Plugin [%s]: Dường như nhân vật đang bị kẹt hoặc script bị lỗi, đang đợi 30s để tiếp tục script..."),     
    "194": ("Plugin [%s]: It seems like the paper roll has run out and disconnect has been activated. You need to check again if you didn't suddenly press the stop button just now.",
            "Plugin [%s]: Có vẻ như hết cuộn giấy về thành nên đã kích hoạt disconect, bạn cần kiểm tra lại nếu như vừa rồi không bấm nút stop đột ngột"),     
    "195": ("Plugin [%s]: Waiting (no more than 5 minutes) for [%s] party members...",
            "Plugin [%s]: Đang đợi(không quá 5 phút) để có [%s] thành viên trong party..."),     
    "196": ("Plugin [%s]: Enough [%s] members in party, entering guild warehouse...",
            "Plugin [%s]: Đã đủ số lượng [%s] thành viên trong party, đang vào kho guild..."),    
    "197": ("Plugin [%s]: Warning: teleported back to end point, but current position does not match training area",
            "Plugin [%s]: Cảnh báo: đã dịch chuyển ngược tới điểm cuối, nhưng vị trí hiện tại không khớp với bãi farm"),    
    "198": ("Plugin [%s]: Items sent (or received) successfully",
            "Plugin [%s]: Đã gửi(hoặc nhận) thành công các items"),     
    "199": ("Plugin [%s]: Using teleportation scroll...",
            "Plugin [%s]: Đang sử dụng cuộn giấy dịch chuyển..."),     
    "200": ("Plugin [%s]: Teleportation failed, you need to review the scroll to return to the town.",
            "Plugin [%s]: Dịch chuyển không thành công, bạn cần xem lại cuộn giấy phù về thành"),     
    "201": ("Plugin [%s]: Character has been buying/selling items in the city for more than 5 minutes, resulting in unwanted behavior.",
            "Plugin [%s]: Nhân vật đã mua/bán item trong thành quá 5 phút, dẫn đến hành vi không mong muốn."),     
    "202": ("Plugin [%s]: Oh no! The return scroll is out, now using the reverse teleportation scroll instead...",
            "Plugin [%s]: Không ổn rồi! cuộn giấy về thành đã hết, giờ đang sử dụng cuộn dịch chuyển ngược để thay thế..."),              
    "203": ("Plugin [%s]: Waited for more than 10 minutes, no scroll to return to the town, no monster killed, the system automatically disconnected for you to solve",
            "Plugin [%s]: Đã chờ quá 10 phút, không có cuộn giấy về thành, không bị quái giết, hệ thống tự động ngắt kết nối để bạn vào giải quyết"),     
    "204": ("Plugin [%s]: Equipment not received or missing from inventory, returning to guild warehouse...",
            "Plugin [%s]: Trang bị đã chưa nhận hoặc lưu kho còn thiếu, đang vào lại kho guild..."),     
    "205": ("Plugin [%s]: Opened guild warehouse [%s] times in [%s] minutes but still failed",
            "Plugin [%s]: Đã mở kho guild [%s] lần trong khoảng [%s] phút nhưng vẫn không thành công"),     
    "206": ("Plugin [%s]: Entering guild warehouse for [%s] time, will try up to 20 times, each time 10s-20s apart",
            "Plugin [%s]: Đang vào kho guild lần thứ [%s], sẽ thử tối đa 20 lần, mỗi lần cách nhau từ 10s-20s"),     
    "207": ("Plugin [%s]: The members have all equipped their items and are ready to go...",
            "Plugin [%s]: Các thành viên đều đã trang bị đủ item, chuẩn bị lên bãi..."),  
    "208": ("Plugin [%s]: The current phbot state of [%s] character, Disconnect is out of green time and hibernating:%s",
            "Plugin [%s]: Trạng thái phbot của [%s] nhân vật ở hiện tại, Disconect là trạng thái hết giờ xanh và đang ngủ đông:%s"),  
    "209": ("Plugin [%s]: You did not specify a spawn point of [%s], so the script failed to run. Now teleporting to [%s]...",
            "Plugin [%s]: Bạn chưa chỉ định điểm hồi sinh về [%s], do đó đã bị lỗi chạy script. Bây giờ đang dịch chuyển tới [%s]..."),                           
    "210": ("Plugin [%s]: Stuck while running script, going back to...",
            "Plugin [%s]: Bị kẹt khi chạy script, đang phù về lại..."),            
    "211": ("Plugin [%s]: Waiting (no more than 5 minutes) to confirm that all members are fully equipped...",
            "Plugin [%s]: Đang đợi(không quá 5 phút) để xác định các thành viên đều đã trang bị đủ đồ nghề..."),     
    "212": ("Plugin [%s]: Trying (no more than 5 minutes) to get into guild warehouse...",
            "Plugin [%s]: Đang cố gắng(không quá 5 phút) để vào được kho guild..."),     
    "213": ("Plugin [%s]: List of characters and online time:%s",
            "Plugin [%s]: Danh sách nhân vật và thời gian online:%s"),     
    "214": ("Plugin [%s]: If you want to exit the guild warehouse opening loop, use the chat command (note the suffix 1, -1, name):%s",
            "Plugin [%s]: Nếu muốn thoát vòng lặp mở kho guild, hãy chat lệnh(lưu ý hậu tố 1, -1, tên):%s "),     
    "215": ("Plugin [%s]: Stopped guild inventory opening loop due to request",
            "Plugin [%s]: Đã dừng vòng lặp mở kho guild do được yêu cầu"),                                             
    "216": ("Plugin [%s]: Pet not found in inventory",
            "Plugin [%s]: Không tìm thấy pet trong hòm đồ inventory"),                                             
    "217": ("Plugin [%s]: Found the pet already in inventory, so no need to get more from guild warehouse",
            "Plugin [%s]: Đã tìm thấy pet đang có sẵn trong hòm đồ inventory, nên không cần lấy thêm từ kho guild"),                                             
    "218": ("Plugin [%s]: Guild warehouse is full or there are no pets in inventory",
            "Plugin [%s]: Kho guild đã đầy hoặc không có pet trong hòm đồ inventory"),                                             
    "219": ("Plugin [%s]: Equip twice but still not enough, temporarily disconnect until you go in to fix it.",
            "Plugin [%s]: Đã hai lần trang bị đồ nhưng vẫn không đủ, tạm disconect cho đến khi bạn vào khắc phục."),                                             
    "220": ("Plugin [%s]: If possible, we hope you support the 3-month package for 10$, or activate the auto pk job function and follow the pt owner for 25$.",
            "Plugin [%s]: Nếu có thể, rất mong được bạn ủng hộ gói 3 tháng sử dụng giá 200k, hoặc kích hoạt chức năng auto pk job và đánh theo chủ pt có giá 500k"),                                                                     
           
            
    "MainHelp": (MainHelpEn_,
                 MainHelpVi_),
    "GuildHelp": (GuildHelpEn_,
                  GuildHelpVi_),
    "MoveHelp": (MoveHelpEn_,
                 MoveHelpVi_),
    "SetHelp": (SetHelpEn_,
                SetHelpVi_),
    "ExMapHelp": (ExMapHelpEn_,
                  ExMapHelpVi_),
    "FixMapHelp": (FixMapHelpEn_,
                   FixMapHelpVi_),
    "ConvertItemHelp": (ConvertItemHelpEn_,
                        ConvertItemHelpVi_),
    "PythonHelp": (PythonHelpEn_,
                   PythonHelpVi_),
    "StoreItemHelp": (StoreItemHelpEn_,
                      StoreItemHelpVi_),
    "TeleHelp": (TeleHelpEn_,
                 TeleHelpVi_),
    "MNSHelp": (MNSHelpEn_,
                MNSHelpVi_),
    "ScriptHelp": (ScriptHelpEn_,
                   ScriptHelpVi_),
    "CureHelp": (CureHelpEn_,
                 CureHelpVi_),
    "GhostHelp": (GhostHelpEn_,
                  GhostHelpVi_),
    "GuardHelp": (GuardHelpEn_,
                  GuardHelpVi_),
    "BuyF10Help": (BuyF10HelpEn_,
                  BuyF10HelpVi_),
    "ChangePtHelp": (ChangePtHelpEn_,
                  ChangePtHelpVi_),            
    "CopyConfigHelp": (CopyConfigHelpEn_,
                  CopyConfigHelpVi_),
    "JobRadaHelp": (JobRadaHelpEn_,
                  JobRadaHelpVi_),                      
}


