_B7='%s %s reload_profile %s'
_B6='Character:'
_B5='Plugin [%s]: Cần thêm hoặc chọn nhân vật từ danh sách'
_B4='Ghost Boss'
_B3='xGetEnableCure'
_B2='xGetEnableMNS'
_B1='%s(%s ===> %s)'
_B0='Skill Name'
_A_='Shortcut:'
_Az='Code name:'
_Ay='Plugin Auto login'
_Ax='Plugin menu items'
_Aw='fully'
_Av='GoldTime'
_Au='exPet'
_At='notify'
_As='cycle'
_Ar='Sound'
_Aq='Remove Char'
_Ap='press'
_Ao='Shield:'
_An='profile'
_Am='leavept'
_Al='recall'
_Ak='radius'
_Aj='exmap'
_Ai='fixmap'
_Ah='party'
_Ag='storage'
_Af='online'
_Ae='ToMe'
_Ad='ToUnion'
_Ac='ToParty'
_Ab='ToGuild'
_Aa='downtime'
_AZ='Dich Chuyen:'
_AY='relog'
_AX='No Pet'
_AW='fCode'
_AV='Edit Char'
_AU='region'
_AT='dead'
_AS='home'
_AR='hide'
_AQ='wait'
_AP='Renotify'
_AO='sample'
_AN='Notify'
_AM='Del Char'
_AL='delay'
_AK='over'
_AJ='hpper'
_AI='skills_for_weapon_3'
_AH='skills_for_weapon_2'
_AG='skills_for_weapon_1'
_AF='weapon_3'
_AE='weapon_2'
_AD='weapon_1'
_AC='exmapdata'
_AB='autologin'
_AA='buyf10'
_A9='python'
_A8='weapon'
_A7='start'
_A6='item'
_A5='follow'
_A4='guilds'
_A3='players'
_A2='|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|'
_A1='ScanTrader'
_A0='Add Char'
_z='lockkeys'
_y='skills_for_shield'
_x='notme'
_w='justme'
_v='servers'
_u='fixbug'
_t='version'
_s='Players'
_r='Silent'
_q='skills'
_p='Chars:'
_o='skills_for_weapon_4'
_n='+'
_m='Stop'
_l='Start'
_k='Char:'
_j='shortcuts'
_i='tele'
_h='last'
_g='control'
_f=None
_e='fixmapdata'
_d='server'
_c='blade'
_b='enemyskills'
_a='weapon_4'
_Z='Save'
_Y='running'
_X='extend'
_W='items'
_V='('
_U='_'
_T='mns'
_S='dataitem'
_R='script'
_Q='shield'
_P='dirgame'
_O='cure'
_N='members'
_M='ghost'
_L='code'
_K='changeteam'
_J='chars'
_I='f10'
_H='data'
_G='Rada'
_F='guard'
_E='dataweapon'
_D='movecommand'
_C='setcommand'
_B='name'
_A='types'
import os,sys
from _lib.silkroad import*
hhtizdLRxJDclVvtcTSo='ChatControl'
HkbgUnqkPodJtewqRPnE=BXxnPGdFgiHeQuztmsNz
ClKpoayHpwwSviKZagfc=BXxnPGdFgiHeQuztmsNz
ChfcAMsGCyHQvoqTAIuZ=BXxnPGdFgiHeQuztmsNz
lXFpjJHIhLCAKxStdIIN=BXxnPGdFgiHeQuztmsNz
WXOlKzccVdGkHUjRXXsZ=BXxnPGdFgiHeQuztmsNz
hxYJYDWvaFluRTTSJySH=BXxnPGdFgiHeQuztmsNz
bmxUIMLqLFjHPZiSfsMG=BXxnPGdFgiHeQuztmsNz
nmoMZqJalmdpGvQlvcFN=BXxnPGdFgiHeQuztmsNz
RKmDAbtczjVYieHRRdAI=BXxnPGdFgiHeQuztmsNz
nMhZqiHrxCrOPNEdHeDX=BXxnPGdFgiHeQuztmsNz
gtlsRcKNLeroyQSrGAWI=BXxnPGdFgiHeQuztmsNz
dltpVDzRJuNUOeKNWlZO=BXxnPGdFgiHeQuztmsNz
CyIvXRCscUQUzKzKgvtX=BXxnPGdFgiHeQuztmsNz
XHutdYTebhNytzkxsqHB=BXxnPGdFgiHeQuztmsNz
AikJGYbVxICEhnCEmMtM=BXxnPGdFgiHeQuztmsNz
xBuyF10Var=BXxnPGdFgiHeQuztmsNz
xChangePtVar=BXxnPGdFgiHeQuztmsNz
ASKmopOSSsyBceSyeaqq=BXxnPGdFgiHeQuztmsNz
ATQXujoMxxZtrVjfMcKz=BXxnPGdFgiHeQuztmsNz
KXiCt22HdJMCAUghaqqIA()
OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
JzLZxXwzKEnKOuUNolBu=KRsJzeKTYFIlLTuRSRiR()
def lzovRLuFrkUsuuVcbTTz():
	if OlFpZxSIOWOxoYIYEJhM.get(_t,[]):value=OlFpZxSIOWOxoYIYEJhM[_t][1];result=value[0]if MmzIXEdZSRjOAAIYlWJF()else value[1];dRBzRDsZDulhsFtoVKPh(result%(hhtizdLRxJDclVvtcTSo,OlFpZxSIOWOxoYIYEJhM[_t][0]))
def joined_game():
	global JzLZxXwzKEnKOuUNolBu;JzLZxXwzKEnKOuUNolBu=KRsJzeKTYFIlLTuRSRiR();Timer(15.,lzovRLuFrkUsuuVcbTTz).start();buyf10state=ChSlozxVuBDjPTUsewsE(FudbnvReIPieRucoAuaD)
	if buyf10state:
		dqzkwztjTPhEwczvDoVS(FudbnvReIPieRucoAuaD)
		if uiaVPJytuyuhpwQnLUUr():Timer(12e1,jdlEJLBNagOrhOEwsfwH).start()
		Timer(6e1,ArzcGiIEiStebmNligLe).start()
	if JzLZxXwzKEnKOuUNolBu[_d]in OlFpZxSIOWOxoYIYEJhM[_u].get(_v,[]):Timer(5,VuWvvMPRpWucuClUsDME,(JzLZxXwzKEnKOuUNolBu[_B],)).start()
	OGptGZSlsMViKQHSEfsL(FudbnvReIPieRucoAuaD)
	try:
		name=JzLZxXwzKEnKOuUNolBu[_B]
		if OlFpZxSIOWOxoYIYEJhM[_K][name][_Y]:hide=OlFpZxSIOWOxoYIYEJhM[_K][name];hide=hide.get(_AR,BXxnPGdFgiHeQuztmsNz);uHMSPGUVvFhtnAYJZIlM(hide);siKzOlMeldZyVPPewFTK(FudbnvReIPieRucoAuaD);Thread(target=tobWMVztmmrJfmgqaJug).start()
	except:pass
def connected():YXiIgXjZqLArgFHjvIlG(FudbnvReIPieRucoAuaD);xSetFlagEnableAutoLogoutCTFunc(BXxnPGdFgiHeQuztmsNz)
def disconnected():
	YXiIgXjZqLArgFHjvIlG(BXxnPGdFgiHeQuztmsNz)
	if nVxwkmKtlfblagNmyvCs():xBtvkWltTepDermyPxih(BXxnPGdFgiHeQuztmsNz)
	if OUqTSdfJGPcUyEYpxaEx():VijlQEqMyGonacEtDTCv(BXxnPGdFgiHeQuztmsNz)
	if EWHeJXPvlNluoCondyqQ():EGYPwxYxafykiRQHFYhH(BXxnPGdFgiHeQuztmsNz)
	OGptGZSlsMViKQHSEfsL(BXxnPGdFgiHeQuztmsNz);beMktYuIQjIzJQuMCEmm(BXxnPGdFgiHeQuztmsNz);yDANSXbATkEBABYibLxE()
def event_loop():
	if KhiOMEGFROxQfkwqdLki():dfRDGqRhmmuotlMipoue();VtNaihreyEBlTuLssDgv(BXxnPGdFgiHeQuztmsNz)
	if DdJewTaYMPPuEVuVQvoV():VmnZdVxCyWkDPzNSQRdO()
gui=fPuMEwTQVUhFmZTrkuQr(__name__,hhtizdLRxJDclVvtcTSo)
jEHwoYvtOlbVjNhLKYti=omskgOqYICjokgtwBAis(gui,'avEFUdeooQUGYdkMPHZK',NweMXVypQZSXaVSCagqM(1),X,Y)
evOwxJrsOZvaGUYoKqpb=omskgOqYICjokgtwBAis(gui,'mRBmsnqpjiPVNnyLwhpj',NweMXVypQZSXaVSCagqM(2),X,Y)
xDaEEvpcoVSKCUvKhGFA=MTbiymEMtofPpUnLhCKE(gui,'JYtfVLndoXfNOEgVYBCB','English Default',X,Y)
ooGleuELUDeaUvBNvXLk=omskgOqYICjokgtwBAis(gui,'XPNIzFgKtFaEifUlqaWH',NweMXVypQZSXaVSCagqM(3),X,Y)
FKErQpKRMOMgGqMZMIwo(gui,xDaEEvpcoVSKCUvKhGFA,MmzIXEdZSRjOAAIYlWJF())
vVuWMtEcHQQPjdIUnXnM=omskgOqYICjokgtwBAis(gui,'UFJXkBXckhTclizKAjWW','Reload',X,Y)
HrhrMrFKhXEbhdFeWNSk=omskgOqYICjokgtwBAis(gui,'AMsZJfMtkKDclVPNQcBo','',X,Y)
jqOqWPAhBFlvRJTMDktR=sNOKqVOQPcbIohrgrUAk(gui,_U*115,10,30)
lWcrwRtrEDxMZXyfKvxL=sNOKqVOQPcbIohrgrUAk(gui,_U*115,10,31)
def JYtfVLndoXfNOEgVYBCB(s):
	global OlFpZxSIOWOxoYIYEJhM
	if not OlFpZxSIOWOxoYIYEJhM:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM['english']=s;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(28,hhtizdLRxJDclVvtcTSo,'English'if s else'Tiếng Việt'))
def dfRDGqRhmmuotlMipoue():global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
def UFJXkBXckhTclizKAjWW():VtNaihreyEBlTuLssDgv(FudbnvReIPieRucoAuaD);PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD)
def AMsZJfMtkKDclVPNQcBo():
	if not OlFpZxSIOWOxoYIYEJhM.get(_t,[]):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(61,hhtizdLRxJDclVvtcTSo))
	else:_thead=Thread(target=tJAVhgZyWCHYGORijoRl);_thead.start()
IcbAIPRcQbkYAYMlnRsN=FudbnvReIPieRucoAuaD
OwbJzZbyVhInwpLOEEVg=BXxnPGdFgiHeQuztmsNz
GCSBvlxtrqkACwpjcNiK=BXxnPGdFgiHeQuztmsNz
hDzUpAaPErGtcuEyRuvq=omskgOqYICjokgtwBAis(gui,'UPuhKmXbkxZweOWKAiLT','Back Menu',10,45)
NRuouxFMZxZsFiAQRxZP=omskgOqYICjokgtwBAis(gui,'cDehvDHiGeptSyoejRov','Next Menu',110,45)
tGbRwQhbAErYotZZkeSf(gui,hDzUpAaPErGtcuEyRuvq,BXxnPGdFgiHeQuztmsNz)
gWdKbUSpeAxLBsFpKEoh=omskgOqYICjokgtwBAis(gui,'SIsHTGdXttjOvlTrTfog',NweMXVypQZSXaVSCagqM(4),10,80)
uxEEKQBahJEZmcaIYvwz=omskgOqYICjokgtwBAis(gui,'wzWvBKZeDSPpaZvcfaiu',NweMXVypQZSXaVSCagqM(5),10,110)
TQIGWOCWIwQiiaAiZuoh=omskgOqYICjokgtwBAis(gui,'bjhQMrJquOuyWkpGpokv',NweMXVypQZSXaVSCagqM(6),10,140)
eOtvjPpLCvYJLAcmGmWE=omskgOqYICjokgtwBAis(gui,'kKXizTuNCoVHBWqIRyCE',NweMXVypQZSXaVSCagqM(7),10,170)
RXLhvOUUgCoAWtoSabHd=omskgOqYICjokgtwBAis(gui,'vZbwPSaGMtYsLVpnILPA',NweMXVypQZSXaVSCagqM(8),10,200)
LABGrwxIiQmJiCamnppg=omskgOqYICjokgtwBAis(gui,'hAmVmaqpqAhwscgiTLGn',NweMXVypQZSXaVSCagqM(9),10,230)
UOeyomueyHdkSVmrxcuU=omskgOqYICjokgtwBAis(gui,'HhqoOVrmkYHQnwEPINpV',NweMXVypQZSXaVSCagqM(11),10,260)
UadeXYTTjsnHZgbjglBF=omskgOqYICjokgtwBAis(gui,'OxJyKNebHeBNEugrSGgi',NweMXVypQZSXaVSCagqM(10),X,Y)
pOqhqjahTChffUmvYNpV=omskgOqYICjokgtwBAis(gui,'aelHUBqwmRxNsvHjPiOs',NweMXVypQZSXaVSCagqM(23),X,Y)
LRpdqDEzxIiYuvRgmPQv=omskgOqYICjokgtwBAis(gui,'mfhnPQximhOFoxaAfuXt',NweMXVypQZSXaVSCagqM(24),X,Y)
ueRlwYOgYMOANNGltjlM=omskgOqYICjokgtwBAis(gui,'wiwpfXBKgKKiAsmfjvNk',NweMXVypQZSXaVSCagqM(25),X,Y)
rLUdvylZXYXGFgnnQxpR=omskgOqYICjokgtwBAis(gui,'GTlPvaTmraCYzGiacZPg',NweMXVypQZSXaVSCagqM(26),X,Y)
ynMQpjqQNdICJcJRoSKz=omskgOqYICjokgtwBAis(gui,'TQgSkKFXJXKazsPDBoSN',NweMXVypQZSXaVSCagqM(27),X,Y)
JETeNgvirUhkMZGnFCCC=omskgOqYICjokgtwBAis(gui,'PSYSokMGVPKVzhMEBsIw',NweMXVypQZSXaVSCagqM(29),X,Y)
xBtnShowBuyF10=omskgOqYICjokgtwBAis(gui,'wfexbJIauFrpZHPbyJLh','Buy F10',X,Y)
xBtnShowChangePt=omskgOqYICjokgtwBAis(gui,'ZyPtbDesIpIbcBszUSxO','Auto Login',X,Y)
gchiMbbqpxaRcgMTnhMD=omskgOqYICjokgtwBAis(gui,'gcWRCYHLtJvgmSxOrTBz','Copy Config',X,Y)
ZDfyCJwrIyzereZbIFbZ=omskgOqYICjokgtwBAis(gui,'YneTOWPtApnTBdckFgIU','Job Rada',X,Y)
icdWsWoPIKjNbjLqEZjz=sNOKqVOQPcbIohrgrUAk(gui,'===>',X,Y)
gwXQWfOriebzfPHUaOoB=sNOKqVOQPcbIohrgrUAk(gui,_U*115,10,280)
JWLQJbtMDjTLDIwiFReV=sNOKqVOQPcbIohrgrUAk(gui,_U*115,10,279)
dorYTeiVylKGetVvkoCE=FeDRalZYwLwiBJwVubBM(gui,GyNHsjSRJQGlpcROaYoJ(1),10,295,695,18)
tGbRwQhbAErYotZZkeSf(gui,dorYTeiVylKGetVvkoCE,BXxnPGdFgiHeQuztmsNz)
CYKrgfiKgkhVlCJxqzGw=sNOKqVOQPcbIohrgrUAk(gui,'P:',X,Y)
eppXpjnTqxMPHpFKCfsK=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,100,25)
fOWIyDNVHgiEGwrStpPX=omskgOqYICjokgtwBAis(gui,'VbHmsrXqfoflPYIhtgPk','Add Player',X,Y)
ToPQCoIfNiwtIuiRtmZK=sNOKqVOQPcbIohrgrUAk(gui,'G:',X,Y)
yJATnvnBuSJSkcIrbajr=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,100,25)
EwrTknRthJdiVOdNRCJf=omskgOqYICjokgtwBAis(gui,'NdyASRMSSdUDcaoUGrkC','Add Guild',X,Y)
rnWkPCjfVbsZkvZDBZmJ=fNfddKvwFWUTSfLOPZiL(gui,X,Y,200,170)
jdvWfgFqbdKqWrqBvcfR=fNfddKvwFWUTSfLOPZiL(gui,X,Y,200,170)
JWmayNaPnbnduOjFLtlH=omskgOqYICjokgtwBAis(gui,'gyiCEeGScBeUKERTplTt','',X,Y)
roIyFiuCYvLeXobAwWni=omskgOqYICjokgtwBAis(gui,'nQEJlWaklusPHVbdVaCg','',X,Y)
aCEdOhLCcTbSWlOopccn=sNOKqVOQPcbIohrgrUAk(gui,'',210,35)
def UlStahWlATZklIGCbJOn():
	data=OlFpZxSIOWOxoYIYEJhM[_g];char=KRsJzeKTYFIlLTuRSRiR();name=char[_B];guild=char['guild']
	if name and name not in data[_A3]:uTjWQRuHkfUwHqUKBXer(gui,eppXpjnTqxMPHpFKCfsK,name)
	if guild and guild not in data[_A4]:uTjWQRuHkfUwHqUKBXer(gui,yJATnvnBuSJSkcIrbajr,guild)
	RcgxmwdulXbFqNCcXalf(gui,rnWkPCjfVbsZkvZDBZmJ);RcgxmwdulXbFqNCcXalf(gui,jdvWfgFqbdKqWrqBvcfR)
	for i in data[_A4]:qqiewGGMbbypNfVFpsFt(gui,jdvWfgFqbdKqWrqBvcfR,i)
	for i in data[_A3]:qqiewGGMbbypNfVFpsFt(gui,rnWkPCjfVbsZkvZDBZmJ,i)
	uTjWQRuHkfUwHqUKBXer(gui,JWmayNaPnbnduOjFLtlH,NweMXVypQZSXaVSCagqM(12));uTjWQRuHkfUwHqUKBXer(gui,roIyFiuCYvLeXobAwWni,NweMXVypQZSXaVSCagqM(13))
def VbHmsrXqfoflPYIhtgPk():
	p=PRptGTFSeNBhCFUPbbfz(gui,eppXpjnTqxMPHpFKCfsK);p=p.strip()
	if not sXkMGiiYfTCJYksKpBKb(p):return BXxnPGdFgiHeQuztmsNz
	if p:
		check=CXmyKqeqvrjquzBvrliF(p,OlFpZxSIOWOxoYIYEJhM[_g][_A3])
		if not check:return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,rnWkPCjfVbsZkvZDBZmJ,p);OlFpZxSIOWOxoYIYEJhM[_g][_A3].append(p);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
	return FudbnvReIPieRucoAuaD
def NdyASRMSSdUDcaoUGrkC():
	g=PRptGTFSeNBhCFUPbbfz(gui,yJATnvnBuSJSkcIrbajr);g=g.strip()
	if not sXkMGiiYfTCJYksKpBKb(g):return BXxnPGdFgiHeQuztmsNz
	if g:
		check=CXmyKqeqvrjquzBvrliF(g,OlFpZxSIOWOxoYIYEJhM[_g][_A4])
		if not check:return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,jdvWfgFqbdKqWrqBvcfR,g);OlFpZxSIOWOxoYIYEJhM[_g][_A4].append(g);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
	return FudbnvReIPieRucoAuaD
def gyiCEeGScBeUKERTplTt():
	p=PRptGTFSeNBhCFUPbbfz(gui,rnWkPCjfVbsZkvZDBZmJ)
	if p:lywbvBarobpigBBffFVQ(gui,rnWkPCjfVbsZkvZDBZmJ,p);OlFpZxSIOWOxoYIYEJhM[_g][_A3].remove(p);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
def nQEJlWaklusPHVbdVaCg():
	g=PRptGTFSeNBhCFUPbbfz(gui,jdvWfgFqbdKqWrqBvcfR)
	if g:lywbvBarobpigBBffFVQ(gui,jdvWfgFqbdKqWrqBvcfR,g);OlFpZxSIOWOxoYIYEJhM[_g][_A4].remove(g);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
FGyktaHapXwfXhvZlbTf=omskgOqYICjokgtwBAis(gui,'ZKxSRIFSCBQGtCSUWhJW','Reset',X,Y)
lxQtTBRLIxPeeibjVimW=omskgOqYICjokgtwBAis(gui,'sBmXWNNTVUjEoYRNtuCB',_Z,X,Y)
VOVogadnyYomUcqqUuTq=sNOKqVOQPcbIohrgrUAk(gui,_U*83,X,Y)
qFephjHXtxbXKXKokOgA=sNOKqVOQPcbIohrgrUAk(gui,_Az,X,Y)
gtHoDVJzKSVwQNScpbWZ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,20)
vpvKqXMfbfITdKmfiXin=sNOKqVOQPcbIohrgrUAk(gui,'Just me:',X,Y)
OTjBHMLqRODpyNxHLiXw=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
OOdqGfaMpHYqlnUQFaiX=sNOKqVOQPcbIohrgrUAk(gui,'Not me:',X,Y)
kQMjbvwmYtwxebdEijwt=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
YByJftUWNhdabggdxFlm=sNOKqVOQPcbIohrgrUAk(gui,_U*83,X,Y)
LACdoUaoitphWphaFlqU=sNOKqVOQPcbIohrgrUAk(gui,'Home:',X,Y)
CqythJGjfWTXuxMKcyoH=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
WkMmMflZOgRIFwrlMkFc=sNOKqVOQPcbIohrgrUAk(gui,'Dead:',X,Y)
tGIHLOycDmpRhZOXCLIJ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
smIzvHJtsPgVjJdEXUXc=sNOKqVOQPcbIohrgrUAk(gui,'Last:',X,Y)
ZbSlFPfNCDjTwbTmRZoc=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
mnpRsxxDXoNWCIcrhxUb=sNOKqVOQPcbIohrgrUAk(gui,'Party:**',X,Y)
vaOEZlzwNtKLFlnuVATY=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
vvJygwgturAXxiJlvAVe=sNOKqVOQPcbIohrgrUAk(gui,'FixMap:',X,Y)
uCyzhgqqsDjxCbgBbZHD=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
OYveQLGpEmYOWEoTWiJS=sNOKqVOQPcbIohrgrUAk(gui,'ExMap:**',X,Y)
UnjehnwwmwRKXxGOxhry=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
IbEdwamajTPcuygjSLxt=sNOKqVOQPcbIohrgrUAk(gui,'Tele:',X,Y)
YUgyEkTwWeJKninmvaOv=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
XjSTEFrFGZcIwXpWHkaz=sNOKqVOQPcbIohrgrUAk(gui,'Follow:',X,Y)
vRwfvWsWvsIwoHimeBri=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
iLwFRDzcisapgKAzjUwr=sNOKqVOQPcbIohrgrUAk(gui,'NoFollow:',X,Y)
vejetvcRmXXwJxxMAAjh=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
tGbRwQhbAErYotZZkeSf(gui,vejetvcRmXXwJxxMAAjh,BXxnPGdFgiHeQuztmsNz)
PluHgJfTgYNCTcHRwcKP=sNOKqVOQPcbIohrgrUAk(gui,'XY:',X,Y)
UFIeOKAidjhZXKYvzMgX=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
RVDtlAkbmMlKCIJWHajp=sNOKqVOQPcbIohrgrUAk(gui,'Me:**',X,Y)
PZswfQcHILPfuidyehUo=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
lnmGOcGnrtsyIAEzboJy=sNOKqVOQPcbIohrgrUAk(gui,'Script:',X,Y)
ITlfbgHDiifjFniuIuMU=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
MupsMnhlAKkpRpEtMhCO=sNOKqVOQPcbIohrgrUAk(gui,'StopScript:',X,Y)
thzEwAUoCljdFruEjWmN=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
tGbRwQhbAErYotZZkeSf(gui,thzEwAUoCljdFruEjWmN,BXxnPGdFgiHeQuztmsNz)
FlwZKQoKMlvhPAMIfvwS=sNOKqVOQPcbIohrgrUAk(gui,'Item:',X,Y)
uscozwxJjhheGOXHuIRf=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
aXopVQWCAJszlgSFGvWn=sNOKqVOQPcbIohrgrUAk(gui,'StopItem:',X,Y)
wgwMPmKkbXisxqsqvMLx=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
tGbRwQhbAErYotZZkeSf(gui,wgwMPmKkbXisxqsqvMLx,BXxnPGdFgiHeQuztmsNz)
def sBmXWNNTVUjEoYRNtuCB():
	global OlFpZxSIOWOxoYIYEJhM;code=PRptGTFSeNBhCFUPbbfz(gui,gtHoDVJzKSVwQNScpbWZ);justme=PRptGTFSeNBhCFUPbbfz(gui,OTjBHMLqRODpyNxHLiXw);notme=PRptGTFSeNBhCFUPbbfz(gui,kQMjbvwmYtwxebdEijwt);home=PRptGTFSeNBhCFUPbbfz(gui,CqythJGjfWTXuxMKcyoH);dead=PRptGTFSeNBhCFUPbbfz(gui,tGIHLOycDmpRhZOXCLIJ);last=PRptGTFSeNBhCFUPbbfz(gui,ZbSlFPfNCDjTwbTmRZoc);party=PRptGTFSeNBhCFUPbbfz(gui,vaOEZlzwNtKLFlnuVATY);fixmap=PRptGTFSeNBhCFUPbbfz(gui,uCyzhgqqsDjxCbgBbZHD);exmap=PRptGTFSeNBhCFUPbbfz(gui,UnjehnwwmwRKXxGOxhry);tele=PRptGTFSeNBhCFUPbbfz(gui,YUgyEkTwWeJKninmvaOv);follow=PRptGTFSeNBhCFUPbbfz(gui,vRwfvWsWvsIwoHimeBri);xy=PRptGTFSeNBhCFUPbbfz(gui,UFIeOKAidjhZXKYvzMgX);me=PRptGTFSeNBhCFUPbbfz(gui,PZswfQcHILPfuidyehUo);script=PRptGTFSeNBhCFUPbbfz(gui,ITlfbgHDiifjFniuIuMU);item=PRptGTFSeNBhCFUPbbfz(gui,uscozwxJjhheGOXHuIRf);l=[code,justme,notme,home,dead,last,party,fixmap,exmap,tele,follow,xy,me,script,item];s=set(l)
	if len(l)!=len(s):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(35,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	if code==OlFpZxSIOWOxoYIYEJhM[_C][_L]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(35,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	for i in l:
		check=sXkMGiiYfTCJYksKpBKb(i)and DCdbDWJgUlpNxlEtyZgy(i)
		if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(34,hhtizdLRxJDclVvtcTSo,i));return BXxnPGdFgiHeQuztmsNz
		if not i:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,i));return BXxnPGdFgiHeQuztmsNz
	if OlFpZxSIOWOxoYIYEJhM[_D][_L]!=code:OlFpZxSIOWOxoYIYEJhM[_D][_L]=code
	if OlFpZxSIOWOxoYIYEJhM[_N][_w]!=justme:OlFpZxSIOWOxoYIYEJhM[_N][_w]=justme
	if OlFpZxSIOWOxoYIYEJhM[_N][_x]!=notme:OlFpZxSIOWOxoYIYEJhM[_N][_x]=notme
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_AS]!=home:OlFpZxSIOWOxoYIYEJhM[_D][_A][_AS]=home
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_AT]!=dead:OlFpZxSIOWOxoYIYEJhM[_D][_A][_AT]=dead
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_h]!=last:OlFpZxSIOWOxoYIYEJhM[_D][_A][_h]=last
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_Ah]!=party:OlFpZxSIOWOxoYIYEJhM[_D][_A][_Ah]=party
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_Ai]!=fixmap:OlFpZxSIOWOxoYIYEJhM[_D][_A][_Ai]=fixmap
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_Aj]!=exmap:OlFpZxSIOWOxoYIYEJhM[_D][_A][_Aj]=exmap
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_i]!=tele:OlFpZxSIOWOxoYIYEJhM[_D][_A][_i]=tele
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_A5]!=follow:OlFpZxSIOWOxoYIYEJhM[_D][_A][_A5]=follow
	if OlFpZxSIOWOxoYIYEJhM[_D][_A]['xy']!=xy:OlFpZxSIOWOxoYIYEJhM[_D][_A]['xy']=xy
	if OlFpZxSIOWOxoYIYEJhM[_D][_A]['me']!=me:OlFpZxSIOWOxoYIYEJhM[_D][_A]['me']=me
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_R]!=script:OlFpZxSIOWOxoYIYEJhM[_D][_A][_R]=script
	if OlFpZxSIOWOxoYIYEJhM[_D][_A][_A6]!=item:OlFpZxSIOWOxoYIYEJhM[_D][_A][_A6]=item
	uTjWQRuHkfUwHqUKBXer(gui,vejetvcRmXXwJxxMAAjh,2*OlFpZxSIOWOxoYIYEJhM[_D][_A][_A5]);uTjWQRuHkfUwHqUKBXer(gui,thzEwAUoCljdFruEjWmN,2*OlFpZxSIOWOxoYIYEJhM[_D][_A][_R]);uTjWQRuHkfUwHqUKBXer(gui,wgwMPmKkbXisxqsqvMLx,2*OlFpZxSIOWOxoYIYEJhM[_D][_A][_A6]);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(33,hhtizdLRxJDclVvtcTSo,OlFpZxSIOWOxoYIYEJhM[_D][_L]));return FudbnvReIPieRucoAuaD
def nHqFxzaxMNtRDdQNTqVd():uTjWQRuHkfUwHqUKBXer(gui,gtHoDVJzKSVwQNScpbWZ,OlFpZxSIOWOxoYIYEJhM[_D][_L]);uTjWQRuHkfUwHqUKBXer(gui,OTjBHMLqRODpyNxHLiXw,OlFpZxSIOWOxoYIYEJhM[_N][_w]);uTjWQRuHkfUwHqUKBXer(gui,kQMjbvwmYtwxebdEijwt,OlFpZxSIOWOxoYIYEJhM[_N][_x]);uTjWQRuHkfUwHqUKBXer(gui,CqythJGjfWTXuxMKcyoH,OlFpZxSIOWOxoYIYEJhM[_D][_A][_AS]);uTjWQRuHkfUwHqUKBXer(gui,tGIHLOycDmpRhZOXCLIJ,OlFpZxSIOWOxoYIYEJhM[_D][_A][_AT]);uTjWQRuHkfUwHqUKBXer(gui,ZbSlFPfNCDjTwbTmRZoc,OlFpZxSIOWOxoYIYEJhM[_D][_A][_h]);uTjWQRuHkfUwHqUKBXer(gui,vaOEZlzwNtKLFlnuVATY,OlFpZxSIOWOxoYIYEJhM[_D][_A][_Ah]);uTjWQRuHkfUwHqUKBXer(gui,uCyzhgqqsDjxCbgBbZHD,OlFpZxSIOWOxoYIYEJhM[_D][_A][_Ai]);uTjWQRuHkfUwHqUKBXer(gui,UnjehnwwmwRKXxGOxhry,OlFpZxSIOWOxoYIYEJhM[_D][_A][_Aj]);uTjWQRuHkfUwHqUKBXer(gui,YUgyEkTwWeJKninmvaOv,OlFpZxSIOWOxoYIYEJhM[_D][_A][_i]);uTjWQRuHkfUwHqUKBXer(gui,vRwfvWsWvsIwoHimeBri,OlFpZxSIOWOxoYIYEJhM[_D][_A][_A5]);uTjWQRuHkfUwHqUKBXer(gui,vejetvcRmXXwJxxMAAjh,2*OlFpZxSIOWOxoYIYEJhM[_D][_A][_A5]);uTjWQRuHkfUwHqUKBXer(gui,UFIeOKAidjhZXKYvzMgX,OlFpZxSIOWOxoYIYEJhM[_D][_A]['xy']);uTjWQRuHkfUwHqUKBXer(gui,PZswfQcHILPfuidyehUo,OlFpZxSIOWOxoYIYEJhM[_D][_A]['me']);uTjWQRuHkfUwHqUKBXer(gui,ITlfbgHDiifjFniuIuMU,OlFpZxSIOWOxoYIYEJhM[_D][_A][_R]);uTjWQRuHkfUwHqUKBXer(gui,thzEwAUoCljdFruEjWmN,2*OlFpZxSIOWOxoYIYEJhM[_D][_A][_R]);uTjWQRuHkfUwHqUKBXer(gui,uscozwxJjhheGOXHuIRf,OlFpZxSIOWOxoYIYEJhM[_D][_A][_A6]);uTjWQRuHkfUwHqUKBXer(gui,wgwMPmKkbXisxqsqvMLx,2*OlFpZxSIOWOxoYIYEJhM[_D][_A][_A6])
def ZKxSRIFSCBQGtCSUWhJW():global OlFpZxSIOWOxoYIYEJhM;move_default=ZHdZcnXlryTxXrMfZMBG(raFSqktoLkVRGgSkjRzE[_D][_A]);move_code_default=raFSqktoLkVRGgSkjRzE[_D][_L];members_default=ZHdZcnXlryTxXrMfZMBG(raFSqktoLkVRGgSkjRzE[_N]);OlFpZxSIOWOxoYIYEJhM[_D][_A]=move_default;OlFpZxSIOWOxoYIYEJhM[_D][_L]=move_code_default;OlFpZxSIOWOxoYIYEJhM[_N]=members_default;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);nHqFxzaxMNtRDdQNTqVd();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(32,hhtizdLRxJDclVvtcTSo,OlFpZxSIOWOxoYIYEJhM[_D][_L]))
FKxqfELWGyhlGnEeOhPo=omskgOqYICjokgtwBAis(gui,'tEHunPZSRcPEORCpVCha','Reset',X,Y)
DwJAmngnYKprYHTXZwIH=omskgOqYICjokgtwBAis(gui,'VYQsOldKplYNrxwjzhtO',_Z,X,Y)
AareDXiMMvavpdjJCjEb=sNOKqVOQPcbIohrgrUAk(gui,_Az,X,Y)
iHqLOvJrHUqbodjlTOKM=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,20)
rTUveHsFjTdNdOCapOgJ=sNOKqVOQPcbIohrgrUAk(gui,'Start Bot:',X,Y)
kEyFZGwfHGFxilWEorHG=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
kOCmTwqGpUUeWgpmOffZ=sNOKqVOQPcbIohrgrUAk(gui,'Stop Bot:',X,Y)
lHielohtlBApnFHhjgbe=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
xjQgmArshGxHLADAtZDM=sNOKqVOQPcbIohrgrUAk(gui,'Radius:',X,Y)
ZdpAASRyfxQVNKXTvDlb=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
FFVPfPYMjImEAgLQWilF=sNOKqVOQPcbIohrgrUAk(gui,'ReCall:',X,Y)
tCNMmYYzsCliwIIuqxMA=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
iVwQHksjIeBjqqQYPPNB=sNOKqVOQPcbIohrgrUAk(gui,'Training:',X,Y)
WOkwTlhWLluNPfNfwSpE=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
lIGFmAhfPwJKMVIZqdJF=sNOKqVOQPcbIohrgrUAk(gui,'Weapon:*',X,Y)
EcXJOXCZeFQLIiljCGuG=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
cTXvIKjtxVVYEKCpamwX=sNOKqVOQPcbIohrgrUAk(gui,'StopWp:',X,Y)
BCoWqKkvUWRvTmvbQkTe=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
EVDNyGgQwbdTJQcvRIAg=sNOKqVOQPcbIohrgrUAk(gui,'LeavePt:',X,Y)
ezmeCRPxtMSzhhlUldaV=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
ogZxZJWFpSAfBFbuxsQk=sNOKqVOQPcbIohrgrUAk(gui,'Python:',X,Y)
IFuPxNcrNBJZyytEOAnj=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
HJVLdCYpyPREIwbBAdRQ=sNOKqVOQPcbIohrgrUAk(gui,'ManaShield:*',X,Y)
VGIboPCATIoBNYGGgcVW=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
STninBTkmZJRTzMnWELG=sNOKqVOQPcbIohrgrUAk(gui,'Profile:',X,Y)
mKxlNlGsUzVfBXmzFtQS=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
ilgTepDVGsLKEEIVHrnu=sNOKqVOQPcbIohrgrUAk(gui,'Cure:*',X,Y)
nJhVIBPuIenJJObDvvjZ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
VcpVmwjQXxcMlrXYTszB=sNOKqVOQPcbIohrgrUAk(gui,'Ghost:*',X,Y)
TfTDLyLjCfqTWfZHqfCI=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
xLabelAutoLogin=sNOKqVOQPcbIohrgrUAk(gui,'Autologin:',X,Y)
xLineAutoLogin=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
STJWxPziEYTUCXKDJUXt=sNOKqVOQPcbIohrgrUAk(gui,'StopGhost:',X,Y)
XYVQWIYoTDRwDEvFvLRl=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
gozpOqzwkdOOYyJGLqvD=sNOKqVOQPcbIohrgrUAk(gui,'Guard:*',X,Y)
SUgmPoetsXniINKQOFwU=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
kIbzkKAAsoWGYcsauhnD=sNOKqVOQPcbIohrgrUAk(gui,'NoGuard:',X,Y)
FCYMpBYVFqgQUFddJacy=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
SeOmTUjfMZLGTzvGKlTC=sNOKqVOQPcbIohrgrUAk(gui,'BuyF10:',X,Y)
BsRXlRNuACCvLbvEBiOl=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,30,20)
tGbRwQhbAErYotZZkeSf(gui,XYVQWIYoTDRwDEvFvLRl,BXxnPGdFgiHeQuztmsNz)
tGbRwQhbAErYotZZkeSf(gui,BCoWqKkvUWRvTmvbQkTe,BXxnPGdFgiHeQuztmsNz)
tGbRwQhbAErYotZZkeSf(gui,lHielohtlBApnFHhjgbe,BXxnPGdFgiHeQuztmsNz)
tGbRwQhbAErYotZZkeSf(gui,FCYMpBYVFqgQUFddJacy,BXxnPGdFgiHeQuztmsNz)
def VYQsOldKplYNrxwjzhtO():
	global OlFpZxSIOWOxoYIYEJhM;code=PRptGTFSeNBhCFUPbbfz(gui,iHqLOvJrHUqbodjlTOKM);justme=PRptGTFSeNBhCFUPbbfz(gui,OTjBHMLqRODpyNxHLiXw);notme=PRptGTFSeNBhCFUPbbfz(gui,kQMjbvwmYtwxebdEijwt);start=PRptGTFSeNBhCFUPbbfz(gui,kEyFZGwfHGFxilWEorHG);radius=PRptGTFSeNBhCFUPbbfz(gui,ZdpAASRyfxQVNKXTvDlb);recall=PRptGTFSeNBhCFUPbbfz(gui,tCNMmYYzsCliwIIuqxMA);area=PRptGTFSeNBhCFUPbbfz(gui,WOkwTlhWLluNPfNfwSpE);weapon=PRptGTFSeNBhCFUPbbfz(gui,EcXJOXCZeFQLIiljCGuG);leavept=PRptGTFSeNBhCFUPbbfz(gui,ezmeCRPxtMSzhhlUldaV);python=PRptGTFSeNBhCFUPbbfz(gui,IFuPxNcrNBJZyytEOAnj);mns=PRptGTFSeNBhCFUPbbfz(gui,VGIboPCATIoBNYGGgcVW);profile=PRptGTFSeNBhCFUPbbfz(gui,mKxlNlGsUzVfBXmzFtQS);cure=PRptGTFSeNBhCFUPbbfz(gui,nJhVIBPuIenJJObDvvjZ);ghost=PRptGTFSeNBhCFUPbbfz(gui,TfTDLyLjCfqTWfZHqfCI);guard=PRptGTFSeNBhCFUPbbfz(gui,SUgmPoetsXniINKQOFwU);buyf10=PRptGTFSeNBhCFUPbbfz(gui,BsRXlRNuACCvLbvEBiOl);autologin=PRptGTFSeNBhCFUPbbfz(gui,xLineAutoLogin);l=[code,justme,notme,start,radius,recall,area,weapon,leavept,python,mns,profile,cure,ghost,guard,buyf10,autologin];s=set(l)
	if len(l)!=len(s):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(35,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	if code==OlFpZxSIOWOxoYIYEJhM[_D][_L]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(35,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	for i in l:
		check=sXkMGiiYfTCJYksKpBKb(i)and DCdbDWJgUlpNxlEtyZgy(i)
		if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(34,hhtizdLRxJDclVvtcTSo,i));return BXxnPGdFgiHeQuztmsNz
		if not i:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,i));return BXxnPGdFgiHeQuztmsNz
	if OlFpZxSIOWOxoYIYEJhM[_C][_L]!=code:OlFpZxSIOWOxoYIYEJhM[_C][_L]=code
	if OlFpZxSIOWOxoYIYEJhM[_N][_w]!=justme:OlFpZxSIOWOxoYIYEJhM[_N][_w]=justme
	if OlFpZxSIOWOxoYIYEJhM[_N][_x]!=notme:OlFpZxSIOWOxoYIYEJhM[_N][_x]=notme
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_A7]!=start:OlFpZxSIOWOxoYIYEJhM[_C][_A][_A7]=start
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_Ak]!=radius:OlFpZxSIOWOxoYIYEJhM[_C][_A][_Ak]=radius
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_Al]!=recall:OlFpZxSIOWOxoYIYEJhM[_C][_A][_Al]=recall
	if OlFpZxSIOWOxoYIYEJhM[_C][_A]['area']!=area:OlFpZxSIOWOxoYIYEJhM[_C][_A]['area']=area
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_A8]!=weapon:OlFpZxSIOWOxoYIYEJhM[_C][_A][_A8]=weapon
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_Am]!=leavept:OlFpZxSIOWOxoYIYEJhM[_C][_A][_Am]=leavept
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_A9]!=python:OlFpZxSIOWOxoYIYEJhM[_C][_A][_A9]=python
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_T]!=mns:OlFpZxSIOWOxoYIYEJhM[_C][_A][_T]=mns
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_An]!=profile:OlFpZxSIOWOxoYIYEJhM[_C][_A][_An]=profile
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_O]!=cure:OlFpZxSIOWOxoYIYEJhM[_C][_A][_O]=cure
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_M]!=ghost:OlFpZxSIOWOxoYIYEJhM[_C][_A][_M]=ghost
	if OlFpZxSIOWOxoYIYEJhM[_C][_A][_F]!=guard:OlFpZxSIOWOxoYIYEJhM[_C][_A][_F]=guard
	if OlFpZxSIOWOxoYIYEJhM[_C][_A].get(_AA,'b')!=buyf10:OlFpZxSIOWOxoYIYEJhM[_C][_A][_AA]=buyf10
	if OlFpZxSIOWOxoYIYEJhM[_C][_A].get(_AB,'a')!=autologin:OlFpZxSIOWOxoYIYEJhM[_C][_A][_AB]=autologin
	uTjWQRuHkfUwHqUKBXer(gui,lHielohtlBApnFHhjgbe,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_A7]);uTjWQRuHkfUwHqUKBXer(gui,XYVQWIYoTDRwDEvFvLRl,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_M]);uTjWQRuHkfUwHqUKBXer(gui,BCoWqKkvUWRvTmvbQkTe,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_A8]);uTjWQRuHkfUwHqUKBXer(gui,FCYMpBYVFqgQUFddJacy,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_F])
	if not OlFpZxSIOWOxoYIYEJhM[_C][_A].get(_AA):OlFpZxSIOWOxoYIYEJhM[_C][_A][_AA]='b'
	if not OlFpZxSIOWOxoYIYEJhM[_C][_A].get(_AB):OlFpZxSIOWOxoYIYEJhM[_C][_A][_AB]='a'
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(33,hhtizdLRxJDclVvtcTSo,OlFpZxSIOWOxoYIYEJhM[_C][_L]));return FudbnvReIPieRucoAuaD
def eBfulHLCnrYSDKRDJDPu():uTjWQRuHkfUwHqUKBXer(gui,iHqLOvJrHUqbodjlTOKM,OlFpZxSIOWOxoYIYEJhM[_C][_L]);uTjWQRuHkfUwHqUKBXer(gui,OTjBHMLqRODpyNxHLiXw,OlFpZxSIOWOxoYIYEJhM[_N][_w]);uTjWQRuHkfUwHqUKBXer(gui,kQMjbvwmYtwxebdEijwt,OlFpZxSIOWOxoYIYEJhM[_N][_x]);uTjWQRuHkfUwHqUKBXer(gui,kEyFZGwfHGFxilWEorHG,OlFpZxSIOWOxoYIYEJhM[_C][_A][_A7]);uTjWQRuHkfUwHqUKBXer(gui,ZdpAASRyfxQVNKXTvDlb,OlFpZxSIOWOxoYIYEJhM[_C][_A][_Ak]);uTjWQRuHkfUwHqUKBXer(gui,tCNMmYYzsCliwIIuqxMA,OlFpZxSIOWOxoYIYEJhM[_C][_A][_Al]);uTjWQRuHkfUwHqUKBXer(gui,WOkwTlhWLluNPfNfwSpE,OlFpZxSIOWOxoYIYEJhM[_C][_A]['area']);uTjWQRuHkfUwHqUKBXer(gui,EcXJOXCZeFQLIiljCGuG,OlFpZxSIOWOxoYIYEJhM[_C][_A][_A8]);uTjWQRuHkfUwHqUKBXer(gui,ezmeCRPxtMSzhhlUldaV,OlFpZxSIOWOxoYIYEJhM[_C][_A][_Am]);uTjWQRuHkfUwHqUKBXer(gui,IFuPxNcrNBJZyytEOAnj,OlFpZxSIOWOxoYIYEJhM[_C][_A][_A9]);uTjWQRuHkfUwHqUKBXer(gui,VGIboPCATIoBNYGGgcVW,OlFpZxSIOWOxoYIYEJhM[_C][_A][_T]);uTjWQRuHkfUwHqUKBXer(gui,mKxlNlGsUzVfBXmzFtQS,OlFpZxSIOWOxoYIYEJhM[_C][_A][_An]);uTjWQRuHkfUwHqUKBXer(gui,nJhVIBPuIenJJObDvvjZ,OlFpZxSIOWOxoYIYEJhM[_C][_A][_O]);uTjWQRuHkfUwHqUKBXer(gui,TfTDLyLjCfqTWfZHqfCI,OlFpZxSIOWOxoYIYEJhM[_C][_A][_M]);uTjWQRuHkfUwHqUKBXer(gui,SUgmPoetsXniINKQOFwU,OlFpZxSIOWOxoYIYEJhM[_C][_A][_F]);uTjWQRuHkfUwHqUKBXer(gui,BsRXlRNuACCvLbvEBiOl,OlFpZxSIOWOxoYIYEJhM[_C][_A].get(_AA,'b'));uTjWQRuHkfUwHqUKBXer(gui,xLineAutoLogin,OlFpZxSIOWOxoYIYEJhM[_C][_A].get(_AB,'a'));uTjWQRuHkfUwHqUKBXer(gui,lHielohtlBApnFHhjgbe,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_A7]);uTjWQRuHkfUwHqUKBXer(gui,XYVQWIYoTDRwDEvFvLRl,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_M]);uTjWQRuHkfUwHqUKBXer(gui,BCoWqKkvUWRvTmvbQkTe,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_A8]);uTjWQRuHkfUwHqUKBXer(gui,FCYMpBYVFqgQUFddJacy,2*OlFpZxSIOWOxoYIYEJhM[_C][_A][_F])
def tEHunPZSRcPEORCpVCha():global OlFpZxSIOWOxoYIYEJhM;set_default=ZHdZcnXlryTxXrMfZMBG(raFSqktoLkVRGgSkjRzE[_C][_A]);set_set_default=raFSqktoLkVRGgSkjRzE[_C][_L];members_default=ZHdZcnXlryTxXrMfZMBG(raFSqktoLkVRGgSkjRzE[_N]);OlFpZxSIOWOxoYIYEJhM[_C][_A]=set_default;OlFpZxSIOWOxoYIYEJhM[_C][_L]=set_set_default;OlFpZxSIOWOxoYIYEJhM[_N]=members_default;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);eBfulHLCnrYSDKRDJDPu();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(32,hhtizdLRxJDclVvtcTSo,OlFpZxSIOWOxoYIYEJhM[_C][_L]))
zpDfPQpMqZobAypfHuoG=sNOKqVOQPcbIohrgrUAk(gui,'Name:',X,Y)
odSJOBwRiCpDqrqLQNEn=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,60,25)
mmARntQLxJUgFHpKzyUb=sNOKqVOQPcbIohrgrUAk(gui,'Note:',X,Y)
iYmiIPndXGahrfGVXlqk=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,185,25)
RETqPASxBRHGsQhcsHxu=omskgOqYICjokgtwBAis(gui,'fZUqINFIABZmbMqRqyqD',' Add ',X,Y)
JsfvmLYmBOKwhthzZVdS=fNfddKvwFWUTSfLOPZiL(gui,X,Y,500,170)
byeeCwVMmGkQnWsezHsC=omskgOqYICjokgtwBAis(gui,'SGfdiDMkdjmurTxxrhPT','___________ Remove ___________',X,Y)
def fZUqINFIABZmbMqRqyqD():
	name=PRptGTFSeNBhCFUPbbfz(gui,odSJOBwRiCpDqrqLQNEn);note=PRptGTFSeNBhCFUPbbfz(gui,iYmiIPndXGahrfGVXlqk);check=sXkMGiiYfTCJYksKpBKb(name)and DCdbDWJgUlpNxlEtyZgy(name)
	if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(34,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	if not name:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	if name.find(_V)!=-1:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	for key in OlFpZxSIOWOxoYIYEJhM[_AC].keys():
		if name==key:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	pos=JXTzMNfuXNwApUpCcpfl()
	if not pos:return
	OlFpZxSIOWOxoYIYEJhM[_AC][name]=[pos[_AU],int(pos['x']),int(pos['y']),int(pos['z']),note];item=name+_V+note+')';qqiewGGMbbypNfVFpsFt(gui,JsfvmLYmBOKwhthzZVdS,item);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
def SGfdiDMkdjmurTxxrhPT():
	name=PRptGTFSeNBhCFUPbbfz(gui,JsfvmLYmBOKwhthzZVdS);lywbvBarobpigBBffFVQ(gui,JsfvmLYmBOKwhthzZVdS,name);idx=name.find(_V)
	if idx>=0:name=name[:idx];del OlFpZxSIOWOxoYIYEJhM[_AC][name]
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def kpdGqfGpCHeuEeChTRpI():
	if not OlFpZxSIOWOxoYIYEJhM[_AC]:return BXxnPGdFgiHeQuztmsNz
	RcgxmwdulXbFqNCcXalf(gui,JsfvmLYmBOKwhthzZVdS)
	for(key,value)in OlFpZxSIOWOxoYIYEJhM[_AC].items():item=key+_V+value[4]+')';qqiewGGMbbypNfVFpsFt(gui,JsfvmLYmBOKwhthzZVdS,item)
	return FudbnvReIPieRucoAuaD
MobawbrxDRLlGAwHwbBm=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
HKhYwBkIDVrnqeUltwfY=sNOKqVOQPcbIohrgrUAk(gui,_A_,X,Y)
HvRSvcDSLbCRiOgaRaUM=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
plHnjHIANMeClSOOrqXV=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
tbJcVTSbxWdzpGZDIWDt=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
EnRasHJZGPFhEIUrktCg=fNfddKvwFWUTSfLOPZiL(gui,X,Y,180,200)
nBgqVEqDCMMjiYhQoAKM=fNfddKvwFWUTSfLOPZiL(gui,X,Y,180,200)
QUQdURaLIcsUtJkdnXup=omskgOqYICjokgtwBAis(gui,'qzXAezKZjVIQiBNmABxt','',X,Y)
dBVfgUPDejkiFzTnKJNw=omskgOqYICjokgtwBAis(gui,'WlTtrQypRwkNVSdZeAqe','',X,Y)
xVQhBkSvnqyvefjxfXZc=omskgOqYICjokgtwBAis(gui,'mTVmZowwmCgDtMfVuuMn','',X,Y)
def bxfpHzyWCjsFrRVCamUR():
	uTjWQRuHkfUwHqUKBXer(gui,MobawbrxDRLlGAwHwbBm,NweMXVypQZSXaVSCagqM(15));uTjWQRuHkfUwHqUKBXer(gui,plHnjHIANMeClSOOrqXV,NweMXVypQZSXaVSCagqM(16));uTjWQRuHkfUwHqUKBXer(gui,tbJcVTSbxWdzpGZDIWDt,NweMXVypQZSXaVSCagqM(17));uTjWQRuHkfUwHqUKBXer(gui,QUQdURaLIcsUtJkdnXup,NweMXVypQZSXaVSCagqM(18));uTjWQRuHkfUwHqUKBXer(gui,dBVfgUPDejkiFzTnKJNw,NweMXVypQZSXaVSCagqM(19));uTjWQRuHkfUwHqUKBXer(gui,xVQhBkSvnqyvefjxfXZc,NweMXVypQZSXaVSCagqM(39));RcgxmwdulXbFqNCcXalf(gui,EnRasHJZGPFhEIUrktCg);RcgxmwdulXbFqNCcXalf(gui,nBgqVEqDCMMjiYhQoAKM)
	for i in OlFpZxSIOWOxoYIYEJhM[_e]['original']:qqiewGGMbbypNfVFpsFt(gui,EnRasHJZGPFhEIUrktCg,i)
	for(key,value)in OlFpZxSIOWOxoYIYEJhM[_e][_j].items():item=key+_V+value+')';qqiewGGMbbypNfVFpsFt(gui,nBgqVEqDCMMjiYhQoAKM,item)
def qzXAezKZjVIQiBNmABxt():
	shortcut=PRptGTFSeNBhCFUPbbfz(gui,HvRSvcDSLbCRiOgaRaUM);source=PRptGTFSeNBhCFUPbbfz(gui,EnRasHJZGPFhEIUrktCg)
	if shortcut.find(_V)!=-1:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,shortcut));return BXxnPGdFgiHeQuztmsNz
	if not shortcut or not source:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,''));return BXxnPGdFgiHeQuztmsNz
	check=DCdbDWJgUlpNxlEtyZgy(shortcut)
	if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(34,hhtizdLRxJDclVvtcTSo,shortcut));return BXxnPGdFgiHeQuztmsNz
	l=list(OlFpZxSIOWOxoYIYEJhM[_e][_j].keys())
	if l:
		check=CXmyKqeqvrjquzBvrliF(shortcut,l)
		if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_e][_j][shortcut]=source;item=shortcut+_V+source+')';qqiewGGMbbypNfVFpsFt(gui,nBgqVEqDCMMjiYhQoAKM,item);uTjWQRuHkfUwHqUKBXer(gui,HvRSvcDSLbCRiOgaRaUM,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
def WlTtrQypRwkNVSdZeAqe():item=PRptGTFSeNBhCFUPbbfz(gui,nBgqVEqDCMMjiYhQoAKM);lywbvBarobpigBBffFVQ(gui,nBgqVEqDCMMjiYhQoAKM,item);idx=item.find(_V);name=item[:idx];del OlFpZxSIOWOxoYIYEJhM[_e][_j][name];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def mTVmZowwmCgDtMfVuuMn():
	global OlFpZxSIOWOxoYIYEJhM;default_short=ZHdZcnXlryTxXrMfZMBG(raFSqktoLkVRGgSkjRzE[_e][_j]);OlFpZxSIOWOxoYIYEJhM[_e][_j]=default_short;RcgxmwdulXbFqNCcXalf(gui,nBgqVEqDCMMjiYhQoAKM)
	for(key,value)in OlFpZxSIOWOxoYIYEJhM[_e][_j].items():item=key+_V+value+')';qqiewGGMbbypNfVFpsFt(gui,nBgqVEqDCMMjiYhQoAKM,item)
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
hrfRRqlCDgtKEzJCRaFI=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
BBjUOolVbwszJtAzJOTV=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
OeuGXwWrutRnWdXDphVC=omskgOqYICjokgtwBAis(gui,'kqnoMGoxEmEobJMpgGVZ','Add',X,Y)
AnDFaMnuwwNeSuSldYXS=omskgOqYICjokgtwBAis(gui,'qDdGtPcUieBDSNVzFgVu','Remove',X,Y)
GNACPvjcSHdRUdbxNaDP=cicZNGijwHyNUpQUUWrF(gui,X,Y,160,25)
telcEYudhoxjhlYfCUsl=omskgOqYICjokgtwBAis(gui,'iwUxnVcTXHHbKavNaatA','Edit Weapon',X,Y)
ZzhUTDoUrppMAZhMHJwr=omskgOqYICjokgtwBAis(gui,'AVwYcpQykRLGMGotBbav','Edit Skills',X,Y)
hNauhoyLOphGqcOxhVOc=omskgOqYICjokgtwBAis(gui,'rJewSeAjgHZTRTkEBYfs','Update',X,Y)
JOwmBODCRnwRhbngijue=omskgOqYICjokgtwBAis(gui,'hikBaxRREhJlbXOlsFkF',_l,X,Y)
LfzlKLInRNfozmyvrQwm=omskgOqYICjokgtwBAis(gui,'zjItsRazGYrreVBKKqrU',_m,X,Y)
xqPefLEeBVDDXlfsBiMx=sNOKqVOQPcbIohrgrUAk(gui,_Ao,X,Y)
ispiQylkvdXiLMDoEiIK=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
syyzMVnsDLeZJSlWvhXy=sNOKqVOQPcbIohrgrUAk(gui,_n,X,Y)
fiqTIihCWJTPsJNTCXAk=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,25,25)
zvBFKhDjqnJBobvZFUnb=sNOKqVOQPcbIohrgrUAk(gui,'Weapon1:',X,Y)
yiddbxUqhoypPeQCrEmg=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
MxmRxeSZdbExarfBJztH=sNOKqVOQPcbIohrgrUAk(gui,_n,X,Y)
fgjDmBgWzeBfuoDHfPlR=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,25,25)
fWHGrKTGaCeOPNuWvYmB=sNOKqVOQPcbIohrgrUAk(gui,'Weapon2:',X,Y)
mLdfFVUarbBQThXVJodi=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
GXLozTwlrNowRXQPDNBH=sNOKqVOQPcbIohrgrUAk(gui,_n,X,Y)
lUCsUAONYIeDhhXzSKsV=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,25,25)
yVNblTCQEOnncrZkYnvl=sNOKqVOQPcbIohrgrUAk(gui,'Weapon3:',X,Y)
sniLJqvMMOyDXSvxjHwE=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
FqmYqDabJbxZbLDomzsa=sNOKqVOQPcbIohrgrUAk(gui,_n,X,Y)
iOUqxwkxDAwHVUepZddP=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,25,25)
AfzmHfOSEwpbXZngPJfE=sNOKqVOQPcbIohrgrUAk(gui,'Weapon4:',X,Y)
xCsPKafLAaEBiqmQyRXk=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
sqBYWfnqKTxpuehCufAb=sNOKqVOQPcbIohrgrUAk(gui,_n,X,Y)
zZhYovwMdUVbnWieiflj=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,25,25)
VdunfnMGuQDmiYrhJqnj=sNOKqVOQPcbIohrgrUAk(gui,_U*83,X,Y)
BdSAbnChmaCjNMNIhurR=MTbiymEMtofPpUnLhCKE(gui,'oWVVYpMMjEbRxsfjiKlZ','Walk',X,Y)
SjVtsOkCsVgMJhCvrpBs=sNOKqVOQPcbIohrgrUAk(gui,'Skill:',X,Y)
CRVYDBKUIYsElTDrAvWQ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,200,25)
ghiIkXKoZIEovqPQtJiu=omskgOqYICjokgtwBAis(gui,'wTxBZNOyBISOXWuDLcxC','Add To Shield',X,Y)
dpxaHwVGzWLOJPslkCYl=omskgOqYICjokgtwBAis(gui,'zUxUQRAbeLQhEbJNoZEQ','Add To Weapon 1',X,Y)
UsWbDuAnPmeREsofuJhS=omskgOqYICjokgtwBAis(gui,'doixoLMVKUQQvXIvrQBm','Add To Weapon 2',X,Y)
hrdHeLHjKAZpnuPqYQfI=omskgOqYICjokgtwBAis(gui,'cNimyzgVUabdGoUVBZam','Add To Weapon 3',X,Y)
WGNPjkrtGmdTdhbGQEzz=omskgOqYICjokgtwBAis(gui,'xAddToSkillWeapon4','Add To Weapon 4',X,Y)
UWxJkjntvijVJfWoNtRd=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
kJuOTTRjrFFCeXtoiSSY=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
lrssqOuhKnDjsbdWJrcP=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
nyYVRAWHhfCnNHZuXIjn=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
UQoaqMaJyZaRzaQKfHJp=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
nVwRFllkWqIMMHszJTfR=omskgOqYICjokgtwBAis(gui,'tkWhksvnbYakclbhdxyo','Remove Skill of Shield',X,Y)
YNPLOSulEgupefueCsyt=omskgOqYICjokgtwBAis(gui,'jGeIsWTYrlyAjIarhnAG','Remove Skill of Weapon 1',X,Y)
ZNOCtuFaxzpOIGnThkbs=omskgOqYICjokgtwBAis(gui,'mmbadSzyWxhrOMLyxAss','Remove Skill of Weapon 2',X,Y)
EnGjCXHDmLKculodXMAn=omskgOqYICjokgtwBAis(gui,'oaMHkAliboKqWdcsoqCQ','Remove Skill of Weapon 3',X,Y)
sUnYgpoOwclDNHgIvKSp=omskgOqYICjokgtwBAis(gui,'xRemoveFromWeapon4','Remove Skill of Weapon 4',X,Y)
def YYTkoMLMHyGQFSzikkhJ():
	if bmxUIMLqLFjHPZiSfsMG and not HkbgUnqkPodJtewqRPnE:
		char=JzLZxXwzKEnKOuUNolBu;names=eVgCyKIrycDTuQqfdcWP(gui,GNACPvjcSHdRUdbxNaDP);_state=kYxNLbOLPvUHAInemPWk()
		if not char or char[_B]not in names and not _state:WvZHbCVTxTJBCgjShmye(gui,JOwmBODCRnwRhbngijue,600,85);WvZHbCVTxTJBCgjShmye(gui,LfzlKLInRNfozmyvrQwm,X,Y);tGbRwQhbAErYotZZkeSf(gui,JOwmBODCRnwRhbngijue,BXxnPGdFgiHeQuztmsNz);return
		if _state:WvZHbCVTxTJBCgjShmye(gui,JOwmBODCRnwRhbngijue,X,Y);WvZHbCVTxTJBCgjShmye(gui,LfzlKLInRNfozmyvrQwm,600,85)
		else:WvZHbCVTxTJBCgjShmye(gui,JOwmBODCRnwRhbngijue,600,85);WvZHbCVTxTJBCgjShmye(gui,LfzlKLInRNfozmyvrQwm,X,Y);tGbRwQhbAErYotZZkeSf(gui,JOwmBODCRnwRhbngijue,FudbnvReIPieRucoAuaD)
	elif bmxUIMLqLFjHPZiSfsMG and HkbgUnqkPodJtewqRPnE:WvZHbCVTxTJBCgjShmye(gui,JOwmBODCRnwRhbngijue,X,Y);WvZHbCVTxTJBCgjShmye(gui,LfzlKLInRNfozmyvrQwm,X,Y)
def hikBaxRREhJlbXOlsFkF():
	name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);_state=kYxNLbOLPvUHAInemPWk()
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return
	if _state or JzLZxXwzKEnKOuUNolBu[_B]!=name:return
	_shield=OlFpZxSIOWOxoYIYEJhM[_E][name][_Q];_shield_skill=OlFpZxSIOWOxoYIYEJhM[_E][name][_y]
	if not _shield or not _shield_skill:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(65,hhtizdLRxJDclVvtcTSo));return
	if not MgBELXNmBCXlKACcxQtT():return
	WErkgqBrBCDAblsNmlSb(time());fhqdyUBqzkFSuScixXCa(FudbnvReIPieRucoAuaD);fVDpswbUWpNsmGipXCEf(FudbnvReIPieRucoAuaD);YYTkoMLMHyGQFSzikkhJ();hUHSuqxFjSVWRPqpYxid()
def zjItsRazGYrreVBKKqrU():fhqdyUBqzkFSuScixXCa(BXxnPGdFgiHeQuztmsNz);WErkgqBrBCDAblsNmlSb(_f);dOrXDexRZzUmdtnPElWS(0);fVDpswbUWpNsmGipXCEf(BXxnPGdFgiHeQuztmsNz);YYTkoMLMHyGQFSzikkhJ()
def QDprCggZAXODBvcpcaSR():
	RcgxmwdulXbFqNCcXalf(gui,GNACPvjcSHdRUdbxNaDP)
	for key in OlFpZxSIOWOxoYIYEJhM[_E].keys():qqiewGGMbbypNfVFpsFt(gui,GNACPvjcSHdRUdbxNaDP,key)
	if JzLZxXwzKEnKOuUNolBu and JzLZxXwzKEnKOuUNolBu[_B]in eVgCyKIrycDTuQqfdcWP(gui,GNACPvjcSHdRUdbxNaDP):uTjWQRuHkfUwHqUKBXer(gui,GNACPvjcSHdRUdbxNaDP,JzLZxXwzKEnKOuUNolBu[_B])
	else:uTjWQRuHkfUwHqUKBXer(gui,BBjUOolVbwszJtAzJOTV,JzLZxXwzKEnKOuUNolBu[_B]if JzLZxXwzKEnKOuUNolBu else'')
	YYTkoMLMHyGQFSzikkhJ()
def ncYQeRuzISjoMkjLtetn(name):FKErQpKRMOMgGqMZMIwo(gui,BdSAbnChmaCjNMNIhurR,OlFpZxSIOWOxoYIYEJhM[_E][name]['walk']);uTjWQRuHkfUwHqUKBXer(gui,ispiQylkvdXiLMDoEiIK,OlFpZxSIOWOxoYIYEJhM[_E][name][_Q][0]);uTjWQRuHkfUwHqUKBXer(gui,fiqTIihCWJTPsJNTCXAk,str(OlFpZxSIOWOxoYIYEJhM[_E][name][_Q][1]));uTjWQRuHkfUwHqUKBXer(gui,yiddbxUqhoypPeQCrEmg,OlFpZxSIOWOxoYIYEJhM[_E][name][_AD][0]);uTjWQRuHkfUwHqUKBXer(gui,fgjDmBgWzeBfuoDHfPlR,str(OlFpZxSIOWOxoYIYEJhM[_E][name][_AD][1]));uTjWQRuHkfUwHqUKBXer(gui,mLdfFVUarbBQThXVJodi,OlFpZxSIOWOxoYIYEJhM[_E][name][_AE][0]);uTjWQRuHkfUwHqUKBXer(gui,lUCsUAONYIeDhhXzSKsV,str(OlFpZxSIOWOxoYIYEJhM[_E][name][_AE][1]));uTjWQRuHkfUwHqUKBXer(gui,sniLJqvMMOyDXSvxjHwE,OlFpZxSIOWOxoYIYEJhM[_E][name][_AF][0]);uTjWQRuHkfUwHqUKBXer(gui,iOUqxwkxDAwHVUepZddP,str(OlFpZxSIOWOxoYIYEJhM[_E][name][_AF][1]));uTjWQRuHkfUwHqUKBXer(gui,xCsPKafLAaEBiqmQyRXk,''if not OlFpZxSIOWOxoYIYEJhM[_E][name].get(_a)else OlFpZxSIOWOxoYIYEJhM[_E][name][_a][0]);uTjWQRuHkfUwHqUKBXer(gui,zZhYovwMdUVbnWieiflj,'0'if not OlFpZxSIOWOxoYIYEJhM[_E][name].get(_a)else str(OlFpZxSIOWOxoYIYEJhM[_E][name][_a][1]))
def NbjQjEeOxBfyIJoOvNFd(name):
	keys=[_y,_AG,_AH,_AI,_o];data=OlFpZxSIOWOxoYIYEJhM[_E][name];RcgxmwdulXbFqNCcXalf(gui,UWxJkjntvijVJfWoNtRd);RcgxmwdulXbFqNCcXalf(gui,kJuOTTRjrFFCeXtoiSSY);RcgxmwdulXbFqNCcXalf(gui,lrssqOuhKnDjsbdWJrcP);RcgxmwdulXbFqNCcXalf(gui,nyYVRAWHhfCnNHZuXIjn);RcgxmwdulXbFqNCcXalf(gui,UQoaqMaJyZaRzaQKfHJp)
	for i in data[keys[0]]:qqiewGGMbbypNfVFpsFt(gui,UWxJkjntvijVJfWoNtRd,i)
	for i in data[keys[1]]:qqiewGGMbbypNfVFpsFt(gui,kJuOTTRjrFFCeXtoiSSY,i)
	for i in data[keys[2]]:qqiewGGMbbypNfVFpsFt(gui,lrssqOuhKnDjsbdWJrcP,i)
	for i in data[keys[3]]:qqiewGGMbbypNfVFpsFt(gui,nyYVRAWHhfCnNHZuXIjn,i)
	if data.get(keys[4],_f):
		for i in data[keys[4]]:qqiewGGMbbypNfVFpsFt(gui,UQoaqMaJyZaRzaQKfHJp,i)
def MJmayvoFNwefukOMDAtj():
	WvZHbCVTxTJBCgjShmye(gui,xqPefLEeBVDDXlfsBiMx,270,120);WvZHbCVTxTJBCgjShmye(gui,ispiQylkvdXiLMDoEiIK,315,120);WvZHbCVTxTJBCgjShmye(gui,syyzMVnsDLeZJSlWvhXy,465,120);WvZHbCVTxTJBCgjShmye(gui,fiqTIihCWJTPsJNTCXAk,475,120);WvZHbCVTxTJBCgjShmye(gui,zvBFKhDjqnJBobvZFUnb,250,150);WvZHbCVTxTJBCgjShmye(gui,yiddbxUqhoypPeQCrEmg,315,150);WvZHbCVTxTJBCgjShmye(gui,MxmRxeSZdbExarfBJztH,465,150);WvZHbCVTxTJBCgjShmye(gui,fgjDmBgWzeBfuoDHfPlR,475,150);WvZHbCVTxTJBCgjShmye(gui,fWHGrKTGaCeOPNuWvYmB,250,180);WvZHbCVTxTJBCgjShmye(gui,mLdfFVUarbBQThXVJodi,315,180);WvZHbCVTxTJBCgjShmye(gui,GXLozTwlrNowRXQPDNBH,465,180);WvZHbCVTxTJBCgjShmye(gui,lUCsUAONYIeDhhXzSKsV,475,180);WvZHbCVTxTJBCgjShmye(gui,yVNblTCQEOnncrZkYnvl,250,210);WvZHbCVTxTJBCgjShmye(gui,sniLJqvMMOyDXSvxjHwE,315,210);WvZHbCVTxTJBCgjShmye(gui,FqmYqDabJbxZbLDomzsa,465,210);WvZHbCVTxTJBCgjShmye(gui,iOUqxwkxDAwHVUepZddP,475,210);WvZHbCVTxTJBCgjShmye(gui,AfzmHfOSEwpbXZngPJfE,250,240);WvZHbCVTxTJBCgjShmye(gui,xCsPKafLAaEBiqmQyRXk,315,240);WvZHbCVTxTJBCgjShmye(gui,sqBYWfnqKTxpuehCufAb,465,240);WvZHbCVTxTJBCgjShmye(gui,zZhYovwMdUVbnWieiflj,475,240);WvZHbCVTxTJBCgjShmye(gui,BdSAbnChmaCjNMNIhurR,550,120);WvZHbCVTxTJBCgjShmye(gui,hNauhoyLOphGqcOxhVOc,550,150);name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP)
	if not name:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,'name list'));return BXxnPGdFgiHeQuztmsNz
	ncYQeRuzISjoMkjLtetn(name)
def WZbKPTNfTSFrSKNUyejJ():
	WvZHbCVTxTJBCgjShmye(gui,SjVtsOkCsVgMJhCvrpBs,210,125);WvZHbCVTxTJBCgjShmye(gui,CRVYDBKUIYsElTDrAvWQ,250,120);WvZHbCVTxTJBCgjShmye(gui,ghiIkXKoZIEovqPQtJiu,210,150);WvZHbCVTxTJBCgjShmye(gui,dpxaHwVGzWLOJPslkCYl,210,180);WvZHbCVTxTJBCgjShmye(gui,UsWbDuAnPmeREsofuJhS,210,210);WvZHbCVTxTJBCgjShmye(gui,hrdHeLHjKAZpnuPqYQfI,210,240);WvZHbCVTxTJBCgjShmye(gui,hrdHeLHjKAZpnuPqYQfI,210,240);WvZHbCVTxTJBCgjShmye(gui,WGNPjkrtGmdTdhbGQEzz,210,265);WvZHbCVTxTJBCgjShmye(gui,UWxJkjntvijVJfWoNtRd,360,150);WvZHbCVTxTJBCgjShmye(gui,kJuOTTRjrFFCeXtoiSSY,360,180);WvZHbCVTxTJBCgjShmye(gui,lrssqOuhKnDjsbdWJrcP,360,210);WvZHbCVTxTJBCgjShmye(gui,nyYVRAWHhfCnNHZuXIjn,360,240);WvZHbCVTxTJBCgjShmye(gui,UQoaqMaJyZaRzaQKfHJp,360,265);WvZHbCVTxTJBCgjShmye(gui,nVwRFllkWqIMMHszJTfR,530,150);WvZHbCVTxTJBCgjShmye(gui,YNPLOSulEgupefueCsyt,530,180);WvZHbCVTxTJBCgjShmye(gui,ZNOCtuFaxzpOIGnThkbs,530,210);WvZHbCVTxTJBCgjShmye(gui,EnGjCXHDmLKculodXMAn,530,240);WvZHbCVTxTJBCgjShmye(gui,sUnYgpoOwclDNHgIvKSp,530,265);name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP)
	if not name:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,'list name'));return BXxnPGdFgiHeQuztmsNz
	NbjQjEeOxBfyIJoOvNFd(name)
def dhkSeyhSvaoSeMaiVJLO():
	for widget in(xqPefLEeBVDDXlfsBiMx,ispiQylkvdXiLMDoEiIK,syyzMVnsDLeZJSlWvhXy,fiqTIihCWJTPsJNTCXAk,zvBFKhDjqnJBobvZFUnb,yiddbxUqhoypPeQCrEmg,MxmRxeSZdbExarfBJztH,fgjDmBgWzeBfuoDHfPlR,fWHGrKTGaCeOPNuWvYmB,mLdfFVUarbBQThXVJodi,GXLozTwlrNowRXQPDNBH,lUCsUAONYIeDhhXzSKsV,yVNblTCQEOnncrZkYnvl,sniLJqvMMOyDXSvxjHwE,AfzmHfOSEwpbXZngPJfE,xCsPKafLAaEBiqmQyRXk,sqBYWfnqKTxpuehCufAb,zZhYovwMdUVbnWieiflj,FqmYqDabJbxZbLDomzsa,iOUqxwkxDAwHVUepZddP,BdSAbnChmaCjNMNIhurR,hNauhoyLOphGqcOxhVOc):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def aPVJNjqZPdWNERGxkSvw():
	for widget in(SjVtsOkCsVgMJhCvrpBs,CRVYDBKUIYsElTDrAvWQ,ghiIkXKoZIEovqPQtJiu,dpxaHwVGzWLOJPslkCYl,UsWbDuAnPmeREsofuJhS,hrdHeLHjKAZpnuPqYQfI,UWxJkjntvijVJfWoNtRd,WGNPjkrtGmdTdhbGQEzz,UWxJkjntvijVJfWoNtRd,kJuOTTRjrFFCeXtoiSSY,lrssqOuhKnDjsbdWJrcP,nyYVRAWHhfCnNHZuXIjn,UQoaqMaJyZaRzaQKfHJp,nVwRFllkWqIMMHszJTfR,YNPLOSulEgupefueCsyt,ZNOCtuFaxzpOIGnThkbs,EnGjCXHDmLKculodXMAn,sUnYgpoOwclDNHgIvKSp):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def kqnoMGoxEmEobJMpgGVZ():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,BBjUOolVbwszJtAzJOTV);players=list(OlFpZxSIOWOxoYIYEJhM[_E].keys());check=sXkMGiiYfTCJYksKpBKb(name)
	if not check:return BXxnPGdFgiHeQuztmsNz
	for p in players:
		if p==name:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_E][name]={'walk':FudbnvReIPieRucoAuaD,_Q:['',0],_AD:['',0],_AE:['',0],_AF:['',0],_a:['',0],_y:[],_AG:[],_AH:[],_AI:[],_o:[]};QDprCggZAXODBvcpcaSR();uTjWQRuHkfUwHqUKBXer(gui,GNACPvjcSHdRUdbxNaDP,name);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
def iwUxnVcTXHHbKavNaatA():name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);uTjWQRuHkfUwHqUKBXer(gui,BBjUOolVbwszJtAzJOTV,name);aPVJNjqZPdWNERGxkSvw();MJmayvoFNwefukOMDAtj()
def AVwYcpQykRLGMGotBbav():name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);uTjWQRuHkfUwHqUKBXer(gui,BBjUOolVbwszJtAzJOTV,name);dhkSeyhSvaoSeMaiVJLO();WZbKPTNfTSFrSKNUyejJ()
def qDdGtPcUieBDSNVzFgVu():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,BBjUOolVbwszJtAzJOTV)
	for p in OlFpZxSIOWOxoYIYEJhM[_E].keys():
		if p==name:lywbvBarobpigBBffFVQ(gui,GNACPvjcSHdRUdbxNaDP,p);del OlFpZxSIOWOxoYIYEJhM[_E][p];dhkSeyhSvaoSeMaiVJLO();aPVJNjqZPdWNERGxkSvw();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);return FudbnvReIPieRucoAuaD
	dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(41,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
def oWVVYpMMjEbRxsfjiKlZ(s):
	if not s:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(42,hhtizdLRxJDclVvtcTSo))
def rJewSeAjgHZTRTkEBYfs():
	global OlFpZxSIOWOxoYIYEJhM;sh_name=PRptGTFSeNBhCFUPbbfz(gui,ispiQylkvdXiLMDoEiIK);sh_p=PRptGTFSeNBhCFUPbbfz(gui,fiqTIihCWJTPsJNTCXAk);wp1_name=PRptGTFSeNBhCFUPbbfz(gui,yiddbxUqhoypPeQCrEmg);wp1_p=PRptGTFSeNBhCFUPbbfz(gui,fgjDmBgWzeBfuoDHfPlR);wp2_name=PRptGTFSeNBhCFUPbbfz(gui,mLdfFVUarbBQThXVJodi);wp2_p=PRptGTFSeNBhCFUPbbfz(gui,lUCsUAONYIeDhhXzSKsV);wp3_name=PRptGTFSeNBhCFUPbbfz(gui,sniLJqvMMOyDXSvxjHwE);wp3_p=PRptGTFSeNBhCFUPbbfz(gui,iOUqxwkxDAwHVUepZddP);wp4_name=PRptGTFSeNBhCFUPbbfz(gui,xCsPKafLAaEBiqmQyRXk);wp4_p=PRptGTFSeNBhCFUPbbfz(gui,zZhYovwMdUVbnWieiflj);walk=LBRexqqDJqawZRqWrNZr(gui,BdSAbnChmaCjNMNIhurR);name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP)
	if not(sh_p.isdigit()and wp1_p.isdigit()and wp2_p.isdigit()and wp3_p.isdigit()and wp4_p.isdigit()):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,_n));return BXxnPGdFgiHeQuztmsNz
	if JzLZxXwzKEnKOuUNolBu[_B]==name:
		_inv_items=LDlkmjOOgaGCsuHjpvOt()[_W];_name_items=[item[_B]for item in _inv_items if item];_select_items=[sh_name,wp1_name,wp2_name,wp3_name,wp4_name]
		for _select in _select_items:
			if _select and _select not in _name_items:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,_select));return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_E][name]['walk']=walk;OlFpZxSIOWOxoYIYEJhM[_E][name][_Q][0]=sh_name;OlFpZxSIOWOxoYIYEJhM[_E][name][_Q][1]=int(sh_p);OlFpZxSIOWOxoYIYEJhM[_E][name][_AD][0]=wp1_name;OlFpZxSIOWOxoYIYEJhM[_E][name][_AD][1]=int(wp1_p);OlFpZxSIOWOxoYIYEJhM[_E][name][_AE][0]=wp2_name;OlFpZxSIOWOxoYIYEJhM[_E][name][_AE][1]=int(wp2_p);OlFpZxSIOWOxoYIYEJhM[_E][name][_AF][0]=wp3_name;OlFpZxSIOWOxoYIYEJhM[_E][name][_AF][1]=int(wp3_p)
	if not OlFpZxSIOWOxoYIYEJhM[_E][name].get(_a):OlFpZxSIOWOxoYIYEJhM[_E][name][_a]=['',0]
	OlFpZxSIOWOxoYIYEJhM[_E][name][_a][0]=wp4_name;OlFpZxSIOWOxoYIYEJhM[_E][name][_a][1]=int(wp4_p);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
def wTxBZNOyBISOXWuDLcxC():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,CRVYDBKUIYsElTDrAvWQ)
	if skill:
		if skill in OlFpZxSIOWOxoYIYEJhM[_E][name][_y]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,skill));return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,UWxJkjntvijVJfWoNtRd,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_y].append(skill);uTjWQRuHkfUwHqUKBXer(gui,UWxJkjntvijVJfWoNtRd,skill);uTjWQRuHkfUwHqUKBXer(gui,CRVYDBKUIYsElTDrAvWQ,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def zUxUQRAbeLQhEbJNoZEQ():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,CRVYDBKUIYsElTDrAvWQ)
	if skill:
		if skill in OlFpZxSIOWOxoYIYEJhM[_E][name][_AG]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,skill));return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,kJuOTTRjrFFCeXtoiSSY,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_AG].append(skill);uTjWQRuHkfUwHqUKBXer(gui,kJuOTTRjrFFCeXtoiSSY,skill);uTjWQRuHkfUwHqUKBXer(gui,CRVYDBKUIYsElTDrAvWQ,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def doixoLMVKUQQvXIvrQBm():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,CRVYDBKUIYsElTDrAvWQ)
	if skill:
		if skill in OlFpZxSIOWOxoYIYEJhM[_E][name][_AH]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,skill));return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,lrssqOuhKnDjsbdWJrcP,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_AH].append(skill);uTjWQRuHkfUwHqUKBXer(gui,lrssqOuhKnDjsbdWJrcP,skill);uTjWQRuHkfUwHqUKBXer(gui,CRVYDBKUIYsElTDrAvWQ,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def cNimyzgVUabdGoUVBZam():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,CRVYDBKUIYsElTDrAvWQ)
	if skill:
		if skill in OlFpZxSIOWOxoYIYEJhM[_E][name][_AI]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,skill));return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,nyYVRAWHhfCnNHZuXIjn,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_AI].append(skill);uTjWQRuHkfUwHqUKBXer(gui,nyYVRAWHhfCnNHZuXIjn,skill);uTjWQRuHkfUwHqUKBXer(gui,CRVYDBKUIYsElTDrAvWQ,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def xAddToSkillWeapon4():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,CRVYDBKUIYsElTDrAvWQ)
	if not OlFpZxSIOWOxoYIYEJhM[_E][name].get(_o,[]):OlFpZxSIOWOxoYIYEJhM[_E][name][_o]=[]
	if skill:
		if skill in OlFpZxSIOWOxoYIYEJhM[_E][name][_o]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,skill));return BXxnPGdFgiHeQuztmsNz
		qqiewGGMbbypNfVFpsFt(gui,UQoaqMaJyZaRzaQKfHJp,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_o].append(skill);uTjWQRuHkfUwHqUKBXer(gui,UQoaqMaJyZaRzaQKfHJp,skill);uTjWQRuHkfUwHqUKBXer(gui,CRVYDBKUIYsElTDrAvWQ,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def tkWhksvnbYakclbhdxyo():global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,UWxJkjntvijVJfWoNtRd);lywbvBarobpigBBffFVQ(gui,UWxJkjntvijVJfWoNtRd,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_y].remove(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def jGeIsWTYrlyAjIarhnAG():global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,kJuOTTRjrFFCeXtoiSSY);lywbvBarobpigBBffFVQ(gui,kJuOTTRjrFFCeXtoiSSY,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_AG].remove(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def mmbadSzyWxhrOMLyxAss():global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,lrssqOuhKnDjsbdWJrcP);lywbvBarobpigBBffFVQ(gui,kJuOTTRjrFFCeXtoiSSY,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_AH].remove(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def oaMHkAliboKqWdcsoqCQ():global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,nyYVRAWHhfCnNHZuXIjn);lywbvBarobpigBBffFVQ(gui,kJuOTTRjrFFCeXtoiSSY,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_AI].remove(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def xRemoveFromWeapon4():global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,GNACPvjcSHdRUdbxNaDP);skill=PRptGTFSeNBhCFUPbbfz(gui,UQoaqMaJyZaRzaQKfHJp);lywbvBarobpigBBffFVQ(gui,kJuOTTRjrFFCeXtoiSSY,skill);OlFpZxSIOWOxoYIYEJhM[_E][name][_o].remove(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
odUMrFUWBNZPYZachzLw=sNOKqVOQPcbIohrgrUAk(gui,'Func:',X,Y)
JNPpSaBIOpHzWYkuBxiP=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
dfxrdENzgSgzCrqXZFpA=sNOKqVOQPcbIohrgrUAk(gui,'Args:',X,Y)
RYEABhDXNWqAJyqriCNF=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
kzVqGXInVrcHlodyQAUN=omskgOqYICjokgtwBAis(gui,'bMxRpnTLKqtqeDTnElGX','Execute',X,Y)
CXJhNKiaMrmvuLUdMHLj=omskgOqYICjokgtwBAis(gui,'iDSzKUXCqRatGkUTMrKb','Get Active Buff Skills Name',X,Y)
puRQouCxsHsybkqTfbwZ=omskgOqYICjokgtwBAis(gui,'dcKyDotRgnznRWEMPbaU','Get Equipped Items Name',X,Y)
OzTkCJKypeOsdJRXzkPK=omskgOqYICjokgtwBAis(gui,'WSGruWjxkfTaBwiWrHEE','Get NPCs',X,Y)
uNEfTvmumqDmNoGKGcRP=sNOKqVOQPcbIohrgrUAk(gui,NweMXVypQZSXaVSCagqM(52),X,Y)
CcIiURThQtAEMyocezTN=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,220,25)
aEuiYPZmxsJmcgXaywIn=cicZNGijwHyNUpQUUWrF(gui,X,Y,100,25)
UJthKvHKGsvbfCydfPgC=omskgOqYICjokgtwBAis(gui,'ZWDlAXpWIKMJdEgoEWMZ','Search',X,Y)
AWTVMRMRJHUYZCCBlLQy=omskgOqYICjokgtwBAis(gui,'bIkHEvImamZdiIWnvvbt','Get Character',X,Y)
ZGAdNwFfCWRTWAlpuWBs=sNOKqVOQPcbIohrgrUAk(gui,_U*83,X,Y)
XywKoKeVSHYqNrkBSDsl=omskgOqYICjokgtwBAis(gui,'xLshRkLnYHjaRjOLEZHZ','Scan Game Path',X,Y)
vewjwwieCRTEKJAQncfm=omskgOqYICjokgtwBAis(gui,'lXKSLqxysemEEiTGSmBe','Save Game Path',X,Y)
ablvGKJpDdQyjOlLOzFM=cicZNGijwHyNUpQUUWrF(gui,X,Y,230,25)
mQYeOiiApEvVUAjTnbjv=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,230,25)
tGbRwQhbAErYotZZkeSf(gui,mQYeOiiApEvVUAjTnbjv,BXxnPGdFgiHeQuztmsNz)
def bMxRpnTLKqtqeDTnElGX():func_name=PRptGTFSeNBhCFUPbbfz(gui,JNPpSaBIOpHzWYkuBxiP);args_st=PRptGTFSeNBhCFUPbbfz(gui,RYEABhDXNWqAJyqriCNF);WnxgXCdsZTEiLQZmVmmv(func_name,args_st)
def HBfXwtxyHbGtLThrMmXW():
	l=[_B0,'NPC Name'];RcgxmwdulXbFqNCcXalf(gui,aEuiYPZmxsJmcgXaywIn)
	for i in l:qqiewGGMbbypNfVFpsFt(gui,aEuiYPZmxsJmcgXaywIn,i)
def iDSzKUXCqRatGkUTMrKb():SOzEhWrexBJrUYXcvxTg()
def dcKyDotRgnznRWEMPbaU():WbkLgAxOLplHFuULWcuD()
def xLshRkLnYHjaRjOLEZHZ():
	global ElXjOmBgdYoKHNrpXedh;ElXjOmBgdYoKHNrpXedh=LztAXnhiKGgHUhZAOKPm()
	if ElXjOmBgdYoKHNrpXedh:
		RcgxmwdulXbFqNCcXalf(gui,ablvGKJpDdQyjOlLOzFM)
		for key in ElXjOmBgdYoKHNrpXedh.keys():qqiewGGMbbypNfVFpsFt(gui,ablvGKJpDdQyjOlLOzFM,key)
def lXKSLqxysemEEiTGSmBe():
	global OlFpZxSIOWOxoYIYEJhM
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Let login please!'%hhtizdLRxJDclVvtcTSo);return
	_path=PRptGTFSeNBhCFUPbbfz(gui,ablvGKJpDdQyjOlLOzFM)
	if not _path:dRBzRDsZDulhsFtoVKPh('Plugin [%s]: First, you need to scan and select one path!'%hhtizdLRxJDclVvtcTSo);return
	if not ElXjOmBgdYoKHNrpXedh:return
	name=JzLZxXwzKEnKOuUNolBu[_B];names=list(OlFpZxSIOWOxoYIYEJhM[_F].keys())
	if name in names:OlFpZxSIOWOxoYIYEJhM[_F][name][_P]=[];OlFpZxSIOWOxoYIYEJhM[_F][name][_P].append(_path);OlFpZxSIOWOxoYIYEJhM[_F][name][_P].append(ElXjOmBgdYoKHNrpXedh[_path])
	else:OlFpZxSIOWOxoYIYEJhM[_F][name]={_b:[],_AJ:80,_Q:['',0],_c:['',0],_z:[],_AK:300,_Ap:'',_P:[_path,ElXjOmBgdYoKHNrpXedh[_path]],_AL:0}
	uTjWQRuHkfUwHqUKBXer(gui,mQYeOiiApEvVUAjTnbjv,_path);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
def wqxqzSYnxaWVUUkpHoAm():
	global ElXjOmBgdYoKHNrpXedh,OlFpZxSIOWOxoYIYEJhM
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return
	name=JzLZxXwzKEnKOuUNolBu[_B];names=list(OlFpZxSIOWOxoYIYEJhM[_F].keys())
	if name not in names:
		_game_path_list=eBFciUzCRRTSAhSZULuE()
		if not _game_path_list:return
		OlFpZxSIOWOxoYIYEJhM[_F][name]={_b:[],_AJ:80,_Q:['',0],_c:['',0],_z:[],_AK:300,_Ap:'',_P:[_game_path_list[0],_game_path_list[1]],_AL:0};YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
	uTjWQRuHkfUwHqUKBXer(gui,mQYeOiiApEvVUAjTnbjv,''if not OlFpZxSIOWOxoYIYEJhM[_F][name][_P]else OlFpZxSIOWOxoYIYEJhM[_F][name][_P][0])
def WSGruWjxkfTaBwiWrHEE():
	_npcs=JocbWMBWLrvzNQuCZXHG()
	if _npcs:
		dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Searching result for NPCs:'%hhtizdLRxJDclVvtcTSo);count=1
		for _npc in _npcs.values():dRBzRDsZDulhsFtoVKPh('NPC %s: name:[%s],   xy:[%s, %s]'%(count,_npc[_B],round(_npc['x']),round(_npc['y'])));count+=1
	else:dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Searching result for NPCs: NOT FOUND'%hhtizdLRxJDclVvtcTSo)
def bIkHEvImamZdiIWnvvbt():
	char=KRsJzeKTYFIlLTuRSRiR();count=1;dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Show infor my character [%s]:'%(hhtizdLRxJDclVvtcTSo,char[_B]))
	for(key,value)in char.items():dRBzRDsZDulhsFtoVKPh('Info %s - %s: [%s]'%(count,key,value));count+=1
def ZWDlAXpWIKMJdEgoEWMZ():_selected=PRptGTFSeNBhCFUPbbfz(gui,aEuiYPZmxsJmcgXaywIn);_queryName=PRptGTFSeNBhCFUPbbfz(gui,CcIiURThQtAEMyocezTN);aiTaJqHuqviUdWEjGNJS(_selected,_queryName)
PqZPYxmdZwpJzeCiTmeV=sNOKqVOQPcbIohrgrUAk(gui,'Source:',X,Y)
vTvJAPMuPyzCSAlLcQEL=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
AltklHJZyrkzUAkSVJbr=sNOKqVOQPcbIohrgrUAk(gui,'Destination:',X,Y)
kHEAUrbHwTaadRzzUpfw=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
cykiSggZvutUxGUnlUwE=sNOKqVOQPcbIohrgrUAk(gui,_A_,X,Y)
WGWBoKyuEMJZAXVodmer=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,100,25)
SfFwyqWaDwIHEtjtsTve=omskgOqYICjokgtwBAis(gui,'sEDONJUXSxaKjJsqfVLN','Add Shortcut',X,Y)
OVoqSNhfCDplPAJijZZK=fNfddKvwFWUTSfLOPZiL(gui,X,Y,400,140)
uwdOkMzrjBQcdQFqjuuS=omskgOqYICjokgtwBAis(gui,'esRyLzFYaBshOwEQzCLc','Remove Shortcut',X,Y)
def sEDONJUXSxaKjJsqfVLN():
	global OlFpZxSIOWOxoYIYEJhM;source=PRptGTFSeNBhCFUPbbfz(gui,vTvJAPMuPyzCSAlLcQEL);des=PRptGTFSeNBhCFUPbbfz(gui,kHEAUrbHwTaadRzzUpfw);shortcut=PRptGTFSeNBhCFUPbbfz(gui,WGWBoKyuEMJZAXVodmer)
	if not(source and des and shortcut):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,'blank'));return BXxnPGdFgiHeQuztmsNz
	check=sXkMGiiYfTCJYksKpBKb(shortcut)and DCdbDWJgUlpNxlEtyZgy(shortcut)
	if not check:return BXxnPGdFgiHeQuztmsNz
	for name in OlFpZxSIOWOxoYIYEJhM[_i]:
		if name==shortcut:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,shortcut));return BXxnPGdFgiHeQuztmsNz
	name=_B1%(shortcut,source,des);OlFpZxSIOWOxoYIYEJhM[_i][shortcut]=[source,des];qqiewGGMbbypNfVFpsFt(gui,OVoqSNhfCDplPAJijZZK,name);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);uTjWQRuHkfUwHqUKBXer(gui,WGWBoKyuEMJZAXVodmer,'');dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
def esRyLzFYaBshOwEQzCLc():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,OVoqSNhfCDplPAJijZZK)
	if not name:return BXxnPGdFgiHeQuztmsNz
	lywbvBarobpigBBffFVQ(gui,OVoqSNhfCDplPAJijZZK,name);idx=name.find(_V);key=name[:idx];del OlFpZxSIOWOxoYIYEJhM[_i][key];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def FAAhdhCFGhAzusPJXQmO():
	RcgxmwdulXbFqNCcXalf(gui,OVoqSNhfCDplPAJijZZK)
	for(key,value)in OlFpZxSIOWOxoYIYEJhM[_i].items():name=_B1%(key,value[0],value[1]);qqiewGGMbbypNfVFpsFt(gui,OVoqSNhfCDplPAJijZZK,name)
GkWkMgGIIehMPXbNwYLA=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
ikydHWmMpBLUdSIOGlvK=cicZNGijwHyNUpQUUWrF(gui,X,Y,200,25)
duvPBMyXxHopmneSLHOL=omskgOqYICjokgtwBAis(gui,'tOTJOjpSOxOhTEkHoVhy','Add me',X,Y)
CVHMQMQlPRMTCJRrBqKI=omskgOqYICjokgtwBAis(gui,'sJnTlZINwWhOEzkWrZwu',_Aq,X,Y)
BAUKrYkcpwFWrPcoiLmN=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
mgowRmhINieSpmMmeWMO=sNOKqVOQPcbIohrgrUAk(gui,'List of Available ManaShield Skills:',X,Y)
BlRnlERUmLsluJLUECGJ=cicZNGijwHyNUpQUUWrF(gui,X,Y,200,25)
rUVEsIIVUfjekONEyVEP=sNOKqVOQPcbIohrgrUAk(gui,'Selected ManaShield Skill:',X,Y)
ZNkEbuWFgYMbxXlMwrZj=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
cgaZXmkFmRBykQZeUZAa=omskgOqYICjokgtwBAis(gui,'PVCWJnphZilBtbPhnhUX','Save and Active Selected Skill',X,Y)
def LFtezZvuEYrzeZvbyQGe():
	WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,145);WvZHbCVTxTJBCgjShmye(gui,GkWkMgGIIehMPXbNwYLA,220,60);WvZHbCVTxTJBCgjShmye(gui,ikydHWmMpBLUdSIOGlvK,265,55);WvZHbCVTxTJBCgjShmye(gui,duvPBMyXxHopmneSLHOL,480,55);WvZHbCVTxTJBCgjShmye(gui,CVHMQMQlPRMTCJRrBqKI,580,55);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,80);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,210);WvZHbCVTxTJBCgjShmye(gui,BAUKrYkcpwFWrPcoiLmN,220,240);mRbBkQJRIcvKraJwjssn();check_mns=DZYQAnRvCqnTFypsInWg()
	if check_mns:WvZHbCVTxTJBCgjShmye(gui,mgowRmhINieSpmMmeWMO,220,125);WvZHbCVTxTJBCgjShmye(gui,BlRnlERUmLsluJLUECGJ,220,145);WvZHbCVTxTJBCgjShmye(gui,rUVEsIIVUfjekONEyVEP,450,125);WvZHbCVTxTJBCgjShmye(gui,ZNkEbuWFgYMbxXlMwrZj,450,145);WvZHbCVTxTJBCgjShmye(gui,cgaZXmkFmRBykQZeUZAa,220,175);uTjWQRuHkfUwHqUKBXer(gui,BAUKrYkcpwFWrPcoiLmN,NweMXVypQZSXaVSCagqM('44b'))
	else:uTjWQRuHkfUwHqUKBXer(gui,BAUKrYkcpwFWrPcoiLmN,NweMXVypQZSXaVSCagqM('44'))
	pDztymBmGPvJezMkrHLe()
def mRbBkQJRIcvKraJwjssn():
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	RcgxmwdulXbFqNCcXalf(gui,ikydHWmMpBLUdSIOGlvK);qqiewGGMbbypNfVFpsFt(gui,ikydHWmMpBLUdSIOGlvK,'');names=list(OlFpZxSIOWOxoYIYEJhM[_T].keys())
	for name in names:qqiewGGMbbypNfVFpsFt(gui,ikydHWmMpBLUdSIOGlvK,name)
	check=JzLZxXwzKEnKOuUNolBu[_B]in names;uTjWQRuHkfUwHqUKBXer(gui,ikydHWmMpBLUdSIOGlvK,JzLZxXwzKEnKOuUNolBu[_B]if check else'')
def DZYQAnRvCqnTFypsInWg():
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	char=JzLZxXwzKEnKOuUNolBu[_B];all_skills=ECxMEYCbpCwFIMDSlqlZ();mns=[]
	for item in all_skills.values():
		if item[_B].startswith('Snow Shield'):mns.append(item[_B])
	if not mns:
		_dirgame=OlFpZxSIOWOxoYIYEJhM[_F][JzLZxXwzKEnKOuUNolBu[_B]][_P]
		if _dirgame:
			_db_name=_dirgame[1];_names=bYWruMFCbnILrQgGEOwX(_db_name,_type=_T)
			for item in all_skills.values():
				if item[_B]in _names:mns.append(item[_B])
	RcgxmwdulXbFqNCcXalf(gui,BlRnlERUmLsluJLUECGJ);qqiewGGMbbypNfVFpsFt(gui,BlRnlERUmLsluJLUECGJ,'')
	if mns:
		for i in mns:qqiewGGMbbypNfVFpsFt(gui,BlRnlERUmLsluJLUECGJ,i)
		text=''if char not in list(OlFpZxSIOWOxoYIYEJhM[_T].keys())else OlFpZxSIOWOxoYIYEJhM[_T][char];uTjWQRuHkfUwHqUKBXer(gui,ZNkEbuWFgYMbxXlMwrZj,text);uTjWQRuHkfUwHqUKBXer(gui,BlRnlERUmLsluJLUECGJ,text);return FudbnvReIPieRucoAuaD
	return BXxnPGdFgiHeQuztmsNz
def pDztymBmGPvJezMkrHLe():
	res=DZYQAnRvCqnTFypsInWg()
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:tGbRwQhbAErYotZZkeSf(gui,duvPBMyXxHopmneSLHOL,BXxnPGdFgiHeQuztmsNz)
	else:
		check=JzLZxXwzKEnKOuUNolBu[_B]in list(OlFpZxSIOWOxoYIYEJhM[_T].keys())
		if check:tGbRwQhbAErYotZZkeSf(gui,duvPBMyXxHopmneSLHOL,BXxnPGdFgiHeQuztmsNz)
		else:
			tGbRwQhbAErYotZZkeSf(gui,duvPBMyXxHopmneSLHOL,BXxnPGdFgiHeQuztmsNz)
			if res:tGbRwQhbAErYotZZkeSf(gui,duvPBMyXxHopmneSLHOL,FudbnvReIPieRucoAuaD)
def tOTJOjpSOxOhTEkHoVhy():
	global OlFpZxSIOWOxoYIYEJhM
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	name=JzLZxXwzKEnKOuUNolBu[_B]
	if name in list(OlFpZxSIOWOxoYIYEJhM[_T].keys()):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	qqiewGGMbbypNfVFpsFt(gui,ikydHWmMpBLUdSIOGlvK,name);OlFpZxSIOWOxoYIYEJhM[_T][name]='';uTjWQRuHkfUwHqUKBXer(gui,ikydHWmMpBLUdSIOGlvK,name);pDztymBmGPvJezMkrHLe();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);return FudbnvReIPieRucoAuaD
def sJnTlZINwWhOEzkWrZwu():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,ikydHWmMpBLUdSIOGlvK)
	if not name:return BXxnPGdFgiHeQuztmsNz
	lywbvBarobpigBBffFVQ(gui,ikydHWmMpBLUdSIOGlvK,name);del OlFpZxSIOWOxoYIYEJhM[_T][name];pDztymBmGPvJezMkrHLe();mRbBkQJRIcvKraJwjssn();YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);BfXfXRnxqNIRoDCoKvFj(_B2);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def PVCWJnphZilBtbPhnhUX():
	global OlFpZxSIOWOxoYIYEJhM
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	char=PRptGTFSeNBhCFUPbbfz(gui,ikydHWmMpBLUdSIOGlvK);name=JzLZxXwzKEnKOuUNolBu[_B]
	if name!=char:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(45,hhtizdLRxJDclVvtcTSo,char));return BXxnPGdFgiHeQuztmsNz
	if name not in list(OlFpZxSIOWOxoYIYEJhM[_T].keys()):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(41,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	skill=PRptGTFSeNBhCFUPbbfz(gui,BlRnlERUmLsluJLUECGJ);OlFpZxSIOWOxoYIYEJhM[_T][name]=skill;uTjWQRuHkfUwHqUKBXer(gui,ZNkEbuWFgYMbxXlMwrZj,skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);sjWCVCmnutNMYBPDQZbf(skill,_B2,'xSetDisableMNS');dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
GnMRPkZkhFxOrZQTNPqd=sNOKqVOQPcbIohrgrUAk(gui,'Selected Town:',X,Y)
BtbfyPCeNcOYsuCeuzSw=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
dqlCIEbSJqZzHGQoaSfc=sNOKqVOQPcbIohrgrUAk(gui,'Wait(s):',X,Y)
qRdGTWYOHFcqrWNSnXsP=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,40,25)
KOdeNnWVgFswgyUoYsAE=omskgOqYICjokgtwBAis(gui,'dhuRIugqPPsQLRfITpue',_Z,X,Y)
vWyvYNTYjZRuynFBGTCU=sNOKqVOQPcbIohrgrUAk(gui,NweMXVypQZSXaVSCagqM(58),X,Y)
YfwxOORIdeShJnMauMvO=omskgOqYICjokgtwBAis(gui,'fCGlAYvFhHmEgYeMsEtb','Get Server',X,Y)
gwvwFLANPZdpctwEWZcS=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
EaFryNTbffMeUaBgeSTK=omskgOqYICjokgtwBAis(gui,'YXBgszytQzvnrnYVtAIC','Add',X,Y)
WmlLNGJVNwLLDyVNhAQy=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
caNTgPwifyXJjKMxRYFY=omskgOqYICjokgtwBAis(gui,'GWKazBbtHSSCDZIIzzZP','Del',X,Y)
def YXBgszytQzvnrnYVtAIC():
	global OlFpZxSIOWOxoYIYEJhM;sv=PRptGTFSeNBhCFUPbbfz(gui,gwvwFLANPZdpctwEWZcS)
	if sv:
		data=OlFpZxSIOWOxoYIYEJhM[_u].get(_v,[])
		if data:OlFpZxSIOWOxoYIYEJhM[_u][_v].append(sv)
		else:OlFpZxSIOWOxoYIYEJhM[_u][_v]=[sv]
	qqiewGGMbbypNfVFpsFt(gui,WmlLNGJVNwLLDyVNhAQy,sv);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def GWKazBbtHSSCDZIIzzZP():
	global OlFpZxSIOWOxoYIYEJhM;sv=PRptGTFSeNBhCFUPbbfz(gui,WmlLNGJVNwLLDyVNhAQy)
	if sv:lywbvBarobpigBBffFVQ(gui,WmlLNGJVNwLLDyVNhAQy,sv);OlFpZxSIOWOxoYIYEJhM[_u][_v].remove(sv);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def fCGlAYvFhHmEgYeMsEtb():
	sv=dVtbYiQwNejzohuHTgyt()
	if sv:uTjWQRuHkfUwHqUKBXer(gui,gwvwFLANPZdpctwEWZcS,sv)
def VuWvvMPRpWucuClUsDME(name):new_title=_U+name;DsVKBhZSdNCCkFokKyQN(new_title);dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Đã fix lỗi server cấm phbot, nếu chưa được, bạn cần báo lại với tác giả'%hhtizdLRxJDclVvtcTSo)
def BOohUKYIaWBaSdtRReQg():
	RcgxmwdulXbFqNCcXalf(gui,BtbfyPCeNcOYsuCeuzSw);_data=[i for i in dir(COwqWNHbKNkvSghNqUVW)if not i.startswith('__')]
	for i in _data:qqiewGGMbbypNfVFpsFt(gui,BtbfyPCeNcOYsuCeuzSw,i)
	uTjWQRuHkfUwHqUKBXer(gui,BtbfyPCeNcOYsuCeuzSw,OlFpZxSIOWOxoYIYEJhM[_R][0]);uTjWQRuHkfUwHqUKBXer(gui,qRdGTWYOHFcqrWNSnXsP,str(OlFpZxSIOWOxoYIYEJhM[_R][1]));servers=OlFpZxSIOWOxoYIYEJhM[_u].get(_v,[]);RcgxmwdulXbFqNCcXalf(gui,WmlLNGJVNwLLDyVNhAQy)
	for i in servers:qqiewGGMbbypNfVFpsFt(gui,WmlLNGJVNwLLDyVNhAQy,i)
def dhuRIugqPPsQLRfITpue():
	global OlFpZxSIOWOxoYIYEJhM;town=PRptGTFSeNBhCFUPbbfz(gui,BtbfyPCeNcOYsuCeuzSw);wait=PRptGTFSeNBhCFUPbbfz(gui,qRdGTWYOHFcqrWNSnXsP)
	if town and town!=OlFpZxSIOWOxoYIYEJhM[_R][0]or wait.isdigit()and int(wait)!=OlFpZxSIOWOxoYIYEJhM[_R][1]:OlFpZxSIOWOxoYIYEJhM[_R][0]=town;OlFpZxSIOWOxoYIYEJhM[_R][1]=int(wait);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
xtuagfOeVqSYhTpcdZiW=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
lGBQRLBXffAIHdxXVSYJ=cicZNGijwHyNUpQUUWrF(gui,X,Y,200,25)
WUfTqRfilBcWmSCtYnAn=omskgOqYICjokgtwBAis(gui,'bIyDTlokEwrKWtBOSwvL','Add me',X,Y)
ErnivciwFJYymTCBbJBR=omskgOqYICjokgtwBAis(gui,'FlSXYAjkXvMRFpQrvjSl',_Aq,X,Y)
kePvZTxfDGhuaYESZUsa=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
paELWPlmycLljpeNQUZj=sNOKqVOQPcbIohrgrUAk(gui,'List of Available Cure Skills:',X,Y)
WuXhwEFIEohufmZUxgjj=cicZNGijwHyNUpQUUWrF(gui,X,Y,200,25)
DXLEakCOKoppFIVyWyvD=sNOKqVOQPcbIohrgrUAk(gui,'Selected Cure Skill:',X,Y)
lhuFqKwfevOIMzWLQOeP=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
ABaMGGUGVgkMSOCtDUWe=omskgOqYICjokgtwBAis(gui,'wbUknIUyaTwpXewYUgHd',_Z,X,Y)
JtFAKYwfIUrhvIwgyRRq=omskgOqYICjokgtwBAis(gui,'AegvrmuhZhfORREQxpYf',_l,X,Y)
hoNasCNqyGMtchYPJQEp=omskgOqYICjokgtwBAis(gui,'BTKFyEOiGeSZOCOVjCLD',_m,X,Y)
ScKiNoagbHNcgOLZTVdl=sNOKqVOQPcbIohrgrUAk(gui,_Ao,X,Y)
MiRHljGgsnxqjYQFfVTq=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
WfOcwmECUeINZeCNdtwB=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,35,25)
zbhvdlVsAXfbOSqTABmU=sNOKqVOQPcbIohrgrUAk(gui,'Blade:',X,Y)
qIwTCEJInMETihfCcCYj=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
JDKzUOgiBIFImtbIyFup=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,35,25)
QBXulHlQUJUheqdMJtXM=MTbiymEMtofPpUnLhCKE(gui,'YWLeOhfVNIrwVjvpoFjO','Auto pill',X,Y)
ldNVjfcUprgCAoZASMvK=MTbiymEMtofPpUnLhCKE(gui,'UkkxjMIsMncuAEbWYlSU','Auto skill',X,Y)
FrWAyKuxtqkghGMICYdV=MTbiymEMtofPpUnLhCKE(gui,'qcyKfxyEUDIcQxQFTTGq','All level',X,Y)
def ftXQDpzExIfUzQQxOVbf():
	if CyIvXRCscUQUzKzKgvtX and not HkbgUnqkPodJtewqRPnE:
		char=JzLZxXwzKEnKOuUNolBu;names=eVgCyKIrycDTuQqfdcWP(gui,lGBQRLBXffAIHdxXVSYJ);_state=KaokGrhIXYPffSogkLUC()
		if not char or char[_B]not in names and not _state:WvZHbCVTxTJBCgjShmye(gui,JtFAKYwfIUrhvIwgyRRq,600,190);WvZHbCVTxTJBCgjShmye(gui,hoNasCNqyGMtchYPJQEp,X,Y);tGbRwQhbAErYotZZkeSf(gui,JtFAKYwfIUrhvIwgyRRq,BXxnPGdFgiHeQuztmsNz);return
		if _state:WvZHbCVTxTJBCgjShmye(gui,JtFAKYwfIUrhvIwgyRRq,X,Y);WvZHbCVTxTJBCgjShmye(gui,hoNasCNqyGMtchYPJQEp,600,190)
		else:WvZHbCVTxTJBCgjShmye(gui,JtFAKYwfIUrhvIwgyRRq,600,190);WvZHbCVTxTJBCgjShmye(gui,hoNasCNqyGMtchYPJQEp,X,Y);tGbRwQhbAErYotZZkeSf(gui,JtFAKYwfIUrhvIwgyRRq,FudbnvReIPieRucoAuaD)
	elif CyIvXRCscUQUzKzKgvtX and HkbgUnqkPodJtewqRPnE:WvZHbCVTxTJBCgjShmye(gui,JtFAKYwfIUrhvIwgyRRq,X,Y);WvZHbCVTxTJBCgjShmye(gui,hoNasCNqyGMtchYPJQEp,X,Y)
def AegvrmuhZhfORREQxpYf():
	name=PRptGTFSeNBhCFUPbbfz(gui,lGBQRLBXffAIHdxXVSYJ);_state=KaokGrhIXYPffSogkLUC()
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return
	if _state or JzLZxXwzKEnKOuUNolBu[_B]!=name:return
	if not OlFpZxSIOWOxoYIYEJhM[_O][name]:return
	if not MgBELXNmBCXlKACcxQtT():return
	VijlQEqMyGonacEtDTCv(FudbnvReIPieRucoAuaD);mqsobrZHAYkPaVTAFKAL(FudbnvReIPieRucoAuaD);ftXQDpzExIfUzQQxOVbf()
def BTKFyEOiGeSZOCOVjCLD():VijlQEqMyGonacEtDTCv(BXxnPGdFgiHeQuztmsNz);mqsobrZHAYkPaVTAFKAL(BXxnPGdFgiHeQuztmsNz);ftXQDpzExIfUzQQxOVbf()
def xCallAutoCure():0
def OLmUzKPhMAzZSdFwcLSe():
	WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,205);WvZHbCVTxTJBCgjShmye(gui,xtuagfOeVqSYhTpcdZiW,220,60);WvZHbCVTxTJBCgjShmye(gui,lGBQRLBXffAIHdxXVSYJ,265,55);WvZHbCVTxTJBCgjShmye(gui,WUfTqRfilBcWmSCtYnAn,480,55);WvZHbCVTxTJBCgjShmye(gui,ErnivciwFJYymTCBbJBR,580,55);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,80);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,210);oujkHlJFzuhPZIUoNIIu();check_cure=xgJpLiiAijigXcvaLLjR();WvZHbCVTxTJBCgjShmye(gui,kePvZTxfDGhuaYESZUsa,220,240)
	if check_cure:WvZHbCVTxTJBCgjShmye(gui,paELWPlmycLljpeNQUZj,220,100);WvZHbCVTxTJBCgjShmye(gui,WuXhwEFIEohufmZUxgjj,220,120);WvZHbCVTxTJBCgjShmye(gui,DXLEakCOKoppFIVyWyvD,450,100);WvZHbCVTxTJBCgjShmye(gui,lhuFqKwfevOIMzWLQOeP,450,120);WvZHbCVTxTJBCgjShmye(gui,zbhvdlVsAXfbOSqTABmU,220,160);WvZHbCVTxTJBCgjShmye(gui,qIwTCEJInMETihfCcCYj,260,155);WvZHbCVTxTJBCgjShmye(gui,JDKzUOgiBIFImtbIyFup,415,155);WvZHbCVTxTJBCgjShmye(gui,ScKiNoagbHNcgOLZTVdl,460,160);WvZHbCVTxTJBCgjShmye(gui,MiRHljGgsnxqjYQFfVTq,510,155);WvZHbCVTxTJBCgjShmye(gui,WfOcwmECUeINZeCNdtwB,665,155);WvZHbCVTxTJBCgjShmye(gui,QBXulHlQUJUheqdMJtXM,220,195);WvZHbCVTxTJBCgjShmye(gui,ldNVjfcUprgCAoZASMvK,310,195);WvZHbCVTxTJBCgjShmye(gui,FrWAyKuxtqkghGMICYdV,410,195);WvZHbCVTxTJBCgjShmye(gui,ABaMGGUGVgkMSOCtDUWe,510,190);uTjWQRuHkfUwHqUKBXer(gui,kePvZTxfDGhuaYESZUsa,NweMXVypQZSXaVSCagqM(64))
	else:uTjWQRuHkfUwHqUKBXer(gui,kePvZTxfDGhuaYESZUsa,NweMXVypQZSXaVSCagqM(48))
	jMIRyIZJPZLLuAoBLtTJ()
def oujkHlJFzuhPZIUoNIIu():
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	RcgxmwdulXbFqNCcXalf(gui,lGBQRLBXffAIHdxXVSYJ);qqiewGGMbbypNfVFpsFt(gui,lGBQRLBXffAIHdxXVSYJ,'');names=list(OlFpZxSIOWOxoYIYEJhM[_O].keys())
	for name in names:
		if name!='__PressKey__':qqiewGGMbbypNfVFpsFt(gui,lGBQRLBXffAIHdxXVSYJ,name)
	check=JzLZxXwzKEnKOuUNolBu[_B]in names;uTjWQRuHkfUwHqUKBXer(gui,lGBQRLBXffAIHdxXVSYJ,''if not check else JzLZxXwzKEnKOuUNolBu[_B]);ftXQDpzExIfUzQQxOVbf()
def xgJpLiiAijigXcvaLLjR():
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	char=JzLZxXwzKEnKOuUNolBu[_B];all_skills=ECxMEYCbpCwFIMDSlqlZ();cure=[]
	for item in all_skills.values():
		if item[_B].startswith('Force Cure')or item[_B]=='Innocent':cure.append(item[_B])
	if not cure:
		try:
			_dirgame=OlFpZxSIOWOxoYIYEJhM[_F][JzLZxXwzKEnKOuUNolBu[_B]][_P]
			if _dirgame:
				_db_name=_dirgame[1];_names=bYWruMFCbnILrQgGEOwX(_db_name,_type=_O)
				for item in all_skills.values():
					if item[_B]in _names:cure.append(item[_B])
		except:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(66,hhtizdLRxJDclVvtcTSo))
	RcgxmwdulXbFqNCcXalf(gui,WuXhwEFIEohufmZUxgjj)
	if cure:
		qqiewGGMbbypNfVFpsFt(gui,WuXhwEFIEohufmZUxgjj,'')
		for i in cure:qqiewGGMbbypNfVFpsFt(gui,WuXhwEFIEohufmZUxgjj,i)
		uTjWQRuHkfUwHqUKBXer(gui,lhuFqKwfevOIMzWLQOeP,''if char not in list(OlFpZxSIOWOxoYIYEJhM[_O].keys())else OlFpZxSIOWOxoYIYEJhM[_O][char]);uTjWQRuHkfUwHqUKBXer(gui,WuXhwEFIEohufmZUxgjj,''if char not in list(OlFpZxSIOWOxoYIYEJhM[_O].keys())else OlFpZxSIOWOxoYIYEJhM[_O][char]);shield=['',0];blade=['',0]
		try:shield=OlFpZxSIOWOxoYIYEJhM[_F][char][_Q];blade=OlFpZxSIOWOxoYIYEJhM[_F][char][_c]
		except:pass
		uTjWQRuHkfUwHqUKBXer(gui,MiRHljGgsnxqjYQFfVTq,shield[0]);uTjWQRuHkfUwHqUKBXer(gui,WfOcwmECUeINZeCNdtwB,str(shield[1]));uTjWQRuHkfUwHqUKBXer(gui,qIwTCEJInMETihfCcCYj,blade[0]);uTjWQRuHkfUwHqUKBXer(gui,JDKzUOgiBIFImtbIyFup,str(blade[1]));FKErQpKRMOMgGqMZMIwo(gui,QBXulHlQUJUheqdMJtXM,jtqqlrcdJdycWCJclYFK());FKErQpKRMOMgGqMZMIwo(gui,ldNVjfcUprgCAoZASMvK,qeSHgTeenzrgLpkqqbiF());FKErQpKRMOMgGqMZMIwo(gui,FrWAyKuxtqkghGMICYdV,OzJHAptlLucPhmLGNHnK());return FudbnvReIPieRucoAuaD
	return BXxnPGdFgiHeQuztmsNz
def jMIRyIZJPZLLuAoBLtTJ():
	res=xgJpLiiAijigXcvaLLjR()
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:tGbRwQhbAErYotZZkeSf(gui,WUfTqRfilBcWmSCtYnAn,BXxnPGdFgiHeQuztmsNz)
	else:
		check=JzLZxXwzKEnKOuUNolBu[_B]in list(OlFpZxSIOWOxoYIYEJhM[_O].keys())
		if check:tGbRwQhbAErYotZZkeSf(gui,WUfTqRfilBcWmSCtYnAn,BXxnPGdFgiHeQuztmsNz)
		else:
			tGbRwQhbAErYotZZkeSf(gui,WUfTqRfilBcWmSCtYnAn,BXxnPGdFgiHeQuztmsNz)
			if res:tGbRwQhbAErYotZZkeSf(gui,WUfTqRfilBcWmSCtYnAn,FudbnvReIPieRucoAuaD)
def bIyDTlokEwrKWtBOSwvL():
	global OlFpZxSIOWOxoYIYEJhM
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	name=JzLZxXwzKEnKOuUNolBu[_B]
	if name in list(OlFpZxSIOWOxoYIYEJhM[_O].keys()):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(30,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	qqiewGGMbbypNfVFpsFt(gui,lGBQRLBXffAIHdxXVSYJ,name);OlFpZxSIOWOxoYIYEJhM[_O][name]='';uTjWQRuHkfUwHqUKBXer(gui,lGBQRLBXffAIHdxXVSYJ,name);jMIRyIZJPZLLuAoBLtTJ();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);return FudbnvReIPieRucoAuaD
def FlSXYAjkXvMRFpQrvjSl():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,lGBQRLBXffAIHdxXVSYJ)
	if not name:return BXxnPGdFgiHeQuztmsNz
	lywbvBarobpigBBffFVQ(gui,lGBQRLBXffAIHdxXVSYJ,name);del OlFpZxSIOWOxoYIYEJhM[_O][name];jMIRyIZJPZLLuAoBLtTJ();oujkHlJFzuhPZIUoNIIu();BfXfXRnxqNIRoDCoKvFj(_B3);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def wbUknIUyaTwpXewYUgHd():
	global OlFpZxSIOWOxoYIYEJhM
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return BXxnPGdFgiHeQuztmsNz
	char=PRptGTFSeNBhCFUPbbfz(gui,lGBQRLBXffAIHdxXVSYJ);name=JzLZxXwzKEnKOuUNolBu[_B]
	if name!=char:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(45,hhtizdLRxJDclVvtcTSo,char));return BXxnPGdFgiHeQuztmsNz
	if name not in list(OlFpZxSIOWOxoYIYEJhM[_O].keys()):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(41,hhtizdLRxJDclVvtcTSo,name));return BXxnPGdFgiHeQuztmsNz
	skill=PRptGTFSeNBhCFUPbbfz(gui,WuXhwEFIEohufmZUxgjj);OlFpZxSIOWOxoYIYEJhM[_O][name]=skill;uTjWQRuHkfUwHqUKBXer(gui,lhuFqKwfevOIMzWLQOeP,skill);name_blade=PRptGTFSeNBhCFUPbbfz(gui,qIwTCEJInMETihfCcCYj);plus_blade=PRptGTFSeNBhCFUPbbfz(gui,JDKzUOgiBIFImtbIyFup);name_shield=PRptGTFSeNBhCFUPbbfz(gui,MiRHljGgsnxqjYQFfVTq);plus_shield=PRptGTFSeNBhCFUPbbfz(gui,WfOcwmECUeINZeCNdtwB)
	if not plus_shield.isdigit()or not plus_blade.isdigit():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,'Plus'));return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_F][char][_Q]=[name_shield,int(plus_shield)];OlFpZxSIOWOxoYIYEJhM[_F][char][_c]=[name_blade,int(plus_blade)];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);sjWCVCmnutNMYBPDQZbf(skill,_B3,'xSetDisableCure');dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));ftXQDpzExIfUzQQxOVbf()
	if not name_blade:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(74,hhtizdLRxJDclVvtcTSo))
	return FudbnvReIPieRucoAuaD
def YWLeOhfVNIrwVjvpoFjO(e):rGYCzMDlRlmwULXIQkRk(e)
def UkkxjMIsMncuAEbWYlSU(e):aMhbFYGJEMhLWsGaEBYU(e)
def qcyKfxyEUDIcQxQFTTGq(e):IRWhnjfIvnNrSsnGATVy(e)
RglArglccJJVkKnSTgxr=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
zoMICLUzgkgOQyDHCPsf=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
zKRnvtnfWvISrXUwaMsK=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
jGjYOVhJaXCWJgrRkXBs=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
KYycPyTxSSkxhNQevXtf=omskgOqYICjokgtwBAis(gui,'MUUTxqWmHnQtSWCnjYle',_A0,X,Y)
aTqawvpLbjcFuJQLRUcN=omskgOqYICjokgtwBAis(gui,'RIAMczmKYAVVGRTzeVmD',_AV,X,Y)
bdJLXHCAtzCjRBBxKPwr=omskgOqYICjokgtwBAis(gui,'laWEfTiqOjTalIoiuwYc',_AM,X,Y)
uuBVEYiwPIGGyPmiReVm=sNOKqVOQPcbIohrgrUAk(gui,'Config F(1-4):',X,Y)
gCoQauneWgYneDxakLdU=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
MlvCpjqmgVwZfjuloUSN=MTbiymEMtofPpUnLhCKE(gui,'natpzkxyUaqetsQEAhyd','Imbue',X,Y)
AjnQmXRAOlzKNzmliVED=MTbiymEMtofPpUnLhCKE(gui,'OobyvzgbHyfXeoEASdqT',_B4,X,Y)
pMiuAEqIjBvGVwSmOqbV=omskgOqYICjokgtwBAis(gui,'ldVQMcFavBiOIuuJAOsn','Save F1-F4',X,Y)
kfDcvJsHrxudYljVdKKw=omskgOqYICjokgtwBAis(gui,'cbFPFeWKCEWRuXyVSYjb','Print skills',X,Y)
rXNJnPxOEphrAujPcOJz=MTbiymEMtofPpUnLhCKE(gui,'YCCAvrHTsIWCahCxYQaj','Re click',X,Y)
scRRktjODHghRvCupJJt=sNOKqVOQPcbIohrgrUAk(gui,'Skill to Ghost:',X,Y)
JVGHTSlctEFxZKAJWNBz=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
aJPscppptvaHgRrGBAvv=omskgOqYICjokgtwBAis(gui,'cEPscPaptvaHgLlGBAuK','Search skill',X,Y)
cUSTjmqyCAgMNOFvRqFy=omskgOqYICjokgtwBAis(gui,'HSuKmjdBnoijeawNuako','Add skill',X,Y)
uKzTznnvntFtBDNHaUoD=omskgOqYICjokgtwBAis(gui,'vwhGfIcmywKMGjKnfUjk','Remove skill',X,Y)
GFOtzraUCjUMayLwUAMo=sNOKqVOQPcbIohrgrUAk(gui,'Cut(ms)',X,Y)
qRZTSYysZEdrwynUnDWb=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,25)
zcEfuyrsPqlEHxLvkNHA=sNOKqVOQPcbIohrgrUAk(gui,'Next key',X,Y)
rqgLROQglXtqpburmEtj=cicZNGijwHyNUpQUUWrF(gui,X,Y,50,25)
bVQNJaKfHHilGzXwzzSz=sNOKqVOQPcbIohrgrUAk(gui,'Wait key',X,Y)
FNvfmSrgQZzkDaCteqCm=cicZNGijwHyNUpQUUWrF(gui,X,Y,50,25)
FaPpEVCioitqXHTOIiOs=fNfddKvwFWUTSfLOPZiL(gui,X,Y,220,100)
ncjFUlFpNXZXWOMsqDhz=omskgOqYICjokgtwBAis(gui,'YmzsUThboPMNeyLvreMO',_l,X,Y)
clKOznvQpRcxBHpwSVVz=omskgOqYICjokgtwBAis(gui,'QzkHpbsyfanAFSUuhUeM',_m,X,Y)
xCheckAudioGhost=MTbiymEMtofPpUnLhCKE(gui,'BvLNxXkHnOeeUvwKGygW',_Ar,X,Y)
def BvLNxXkHnOeeUvwKGygW(e):aRIRuUTVIUYCKEdvHMdR(e)
def natpzkxyUaqetsQEAhyd(e):pTwSuoiMTULoeJqWEpxB(e)
def UkgVLmhyLzQBXpNJTQkV():
	if XHutdYTebhNytzkxsqHB and not HkbgUnqkPodJtewqRPnE:
		char=JzLZxXwzKEnKOuUNolBu;names=eVgCyKIrycDTuQqfdcWP(gui,jGjYOVhJaXCWJgrRkXBs);_state=aaEUAaIyvohAGARUagnq()
		if not char or char[_B]not in names and not _state:WvZHbCVTxTJBCgjShmye(gui,ncjFUlFpNXZXWOMsqDhz,600,75);WvZHbCVTxTJBCgjShmye(gui,clKOznvQpRcxBHpwSVVz,X,Y);tGbRwQhbAErYotZZkeSf(gui,ncjFUlFpNXZXWOMsqDhz,BXxnPGdFgiHeQuztmsNz);return
		if _state:WvZHbCVTxTJBCgjShmye(gui,ncjFUlFpNXZXWOMsqDhz,X,Y);WvZHbCVTxTJBCgjShmye(gui,clKOznvQpRcxBHpwSVVz,600,75)
		else:WvZHbCVTxTJBCgjShmye(gui,ncjFUlFpNXZXWOMsqDhz,600,75);WvZHbCVTxTJBCgjShmye(gui,clKOznvQpRcxBHpwSVVz,X,Y);tGbRwQhbAErYotZZkeSf(gui,ncjFUlFpNXZXWOMsqDhz,FudbnvReIPieRucoAuaD)
	elif XHutdYTebhNytzkxsqHB and HkbgUnqkPodJtewqRPnE:WvZHbCVTxTJBCgjShmye(gui,ncjFUlFpNXZXWOMsqDhz,X,Y);WvZHbCVTxTJBCgjShmye(gui,clKOznvQpRcxBHpwSVVz,X,Y)
def YmzsUThboPMNeyLvreMO():
	name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs);_state=aaEUAaIyvohAGARUagnq()
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return
	if _state or JzLZxXwzKEnKOuUNolBu[_B]!=name:return
	if not dXHBvgAlKNXoAQQAvRnn():return
	if not MgBELXNmBCXlKACcxQtT():return
	_data=OlFpZxSIOWOxoYIYEJhM[_M][JzLZxXwzKEnKOuUNolBu[_B]];fCode=SkxaQNxKDdSJFnsfsdzB(_data.get(_AW,''));_data_skills=_data[_q].keys();skills=ECxMEYCbpCwFIMDSlqlZ().items();_IdsSkillGhost=[];imbue=dZXoHFUyHwMNBqKIohzA()
	if imbue:jcldtoYGcRdJGWVJpQHF()
	for(key,skill)in skills:
		for i in _data_skills:
			if i==skill[_B]:_IdsSkillGhost.append(key)
	if _IdsSkillGhost:
		if fCode:hCawZAIqjIvSiejHrEdl(fCode)
		wVjtrcwwriMQDKQmXPvT(_IdsSkillGhost);AIcpfFSeCGHDMlJdLlsx(time());xBtvkWltTepDermyPxih(FudbnvReIPieRucoAuaD);tIeHXVSztjqZvJvjjwCO(FudbnvReIPieRucoAuaD);UkgVLmhyLzQBXpNJTQkV()
def QzkHpbsyfanAFSUuhUeM():
	xBtvkWltTepDermyPxih(BXxnPGdFgiHeQuztmsNz);AIcpfFSeCGHDMlJdLlsx(_f);dobtCotahjTrPyDhbYdc(0);tIeHXVSztjqZvJvjjwCO(BXxnPGdFgiHeQuztmsNz);UkgVLmhyLzQBXpNJTQkV();fCode=DkgNbbZrpZkhHsQTJPvI()
	if fCode:sXUBkDpHLLraiJRjIJTc(fCode)
def MUUTxqWmHnQtSWCnjYle():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,zoMICLUzgkgOQyDHCPsf);names=list(OlFpZxSIOWOxoYIYEJhM[_M].keys());check=name and sXkMGiiYfTCJYksKpBKb(name)and CXmyKqeqvrjquzBvrliF(name,names)
	if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_M][name]={_q:{},'slot':0,_AW:''};qqiewGGMbbypNfVFpsFt(gui,jGjYOVhJaXCWJgrRkXBs,name);uTjWQRuHkfUwHqUKBXer(gui,jGjYOVhJaXCWJgrRkXBs,name);uTjWQRuHkfUwHqUKBXer(gui,zoMICLUzgkgOQyDHCPsf,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));vzcmAJwOoeDLUduoFKsf();byBrrdjnmtOeUUvNqMbZ()
def RIAMczmKYAVVGRTzeVmD():
	name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs)
	if name:vzcmAJwOoeDLUduoFKsf();byBrrdjnmtOeUUvNqMbZ()
def laWEfTiqOjTalIoiuwYc():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs)
	if name:lywbvBarobpigBBffFVQ(gui,jGjYOVhJaXCWJgrRkXBs,name);del OlFpZxSIOWOxoYIYEJhM[_M][name];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);BfXfXRnxqNIRoDCoKvFj('xGetEnableConGhost');dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def YCCAvrHTsIWCahCxYQaj(e):QEzMMskgBgNAYgKndhay(e)
def OobyvzgbHyfXeoEASdqT(e):
	if e:
		if not QtqpbuuVFwAthrEpFvey():FKErQpKRMOMgGqMZMIwo(gui,AjnQmXRAOlzKNzmliVED,BXxnPGdFgiHeQuztmsNz);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(102,hhtizdLRxJDclVvtcTSo,_B4,''));return
	wkwoyEwCSfBEJJNtdBbn(e)
def rFiMHYVBdNYLpZAxlvhj(str=''):
	if not str:return FudbnvReIPieRucoAuaD
	if len(str)<4:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(89,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	l=['f','F','1','2','3','4','8','9',' ']
	for i in str:
		if i not in l:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(89,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	return FudbnvReIPieRucoAuaD
def ldVQMcFavBiOIuuJAOsn():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs);fCode=PRptGTFSeNBhCFUPbbfz(gui,gCoQauneWgYneDxakLdU);check=rFiMHYVBdNYLpZAxlvhj(fCode)
	if not check:return
	OlFpZxSIOWOxoYIYEJhM[_M][name][_AW]=fCode;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def cbFPFeWKCEWRuXyVSYjb():
	name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs)
	if name:
		skills=OlFpZxSIOWOxoYIYEJhM[_M][name][_q];result=''
		for(k,v)in skills.items():result+=f"[{k}]{v}\n"
		dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Bảng cấu hình skills của nhân vật [%s]:\n%s'%(hhtizdLRxJDclVvtcTSo,name,result))
def cEPscPaptvaHgLlGBAuK():skill=PRptGTFSeNBhCFUPbbfz(gui,JVGHTSlctEFxZKAJWNBz);aiTaJqHuqviUdWEjGNJS(_B0,skill)
def HSuKmjdBnoijeawNuako():
	global OlFpZxSIOWOxoYIYEJhM;skill=PRptGTFSeNBhCFUPbbfz(gui,JVGHTSlctEFxZKAJWNBz);delay=PRptGTFSeNBhCFUPbbfz(gui,qRZTSYysZEdrwynUnDWb);name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs);nextKey=PRptGTFSeNBhCFUPbbfz(gui,rqgLROQglXtqpburmEtj);reKey=PRptGTFSeNBhCFUPbbfz(gui,FNvfmSrgQZzkDaCteqCm);new_format=skill.count('[')
	if new_format==2:
		try:skill1=skill;idx0=skill1.find('[');idx1=skill1.find(']');skill=skill1[idx0+1:idx1];value=skill1[idx1+2:-1].split(',');delay=str(value[0].strip());nextKey=str(value[1].strip()[1:-1]);reKey=str(value[2].strip()[1:-1])
		except Exception as e:dRBzRDsZDulhsFtoVKPh(str(e));return
	if not delay or not delay.isdigit()or int(delay)<=0:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,'Ghost delay'));return
	skills=ECxMEYCbpCwFIMDSlqlZ()
	if skill and skills:
		check=BXxnPGdFgiHeQuztmsNz;skills=skills.values()
		for i in skills:
			if i[_B]==skill:check=FudbnvReIPieRucoAuaD;break
		if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,skill));return
		tGbRwQhbAErYotZZkeSf(gui,ncjFUlFpNXZXWOMsqDhz,FudbnvReIPieRucoAuaD);OlFpZxSIOWOxoYIYEJhM[_M][name][_q][skill]=[int(delay),nextKey,reKey];RcgxmwdulXbFqNCcXalf(gui,FaPpEVCioitqXHTOIiOs)
		for(key,value)in OlFpZxSIOWOxoYIYEJhM[_M][name][_q].items():
			if len(value)==2:value=[value[0],value[1],'']
			_text='%s%s'%(key,tuple(value));qqiewGGMbbypNfVFpsFt(gui,FaPpEVCioitqXHTOIiOs,_text)
		uTjWQRuHkfUwHqUKBXer(gui,rqgLROQglXtqpburmEtj,'');uTjWQRuHkfUwHqUKBXer(gui,FNvfmSrgQZzkDaCteqCm,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
	else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(36,hhtizdLRxJDclVvtcTSo,'skill'))
def vwhGfIcmywKMGjKnfUjk():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs);skill=PRptGTFSeNBhCFUPbbfz(gui,FaPpEVCioitqXHTOIiOs);lywbvBarobpigBBffFVQ(gui,FaPpEVCioitqXHTOIiOs,skill)
	if not skill:return
	idx=skill.find(_V,len(skill)-20);del OlFpZxSIOWOxoYIYEJhM[_M][name][_q][skill[:idx]];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def vzcmAJwOoeDLUduoFKsf():WvZHbCVTxTJBCgjShmye(gui,scRRktjODHghRvCupJJt,210,115);WvZHbCVTxTJBCgjShmye(gui,JVGHTSlctEFxZKAJWNBz,210,135);WvZHbCVTxTJBCgjShmye(gui,aJPscppptvaHgRrGBAvv,385,125);WvZHbCVTxTJBCgjShmye(gui,cUSTjmqyCAgMNOFvRqFy,385,150);WvZHbCVTxTJBCgjShmye(gui,uKzTznnvntFtBDNHaUoD,385,175);WvZHbCVTxTJBCgjShmye(gui,FaPpEVCioitqXHTOIiOs,480,125);WvZHbCVTxTJBCgjShmye(gui,GFOtzraUCjUMayLwUAMo,210,180);WvZHbCVTxTJBCgjShmye(gui,qRZTSYysZEdrwynUnDWb,210,200);WvZHbCVTxTJBCgjShmye(gui,zcEfuyrsPqlEHxLvkNHA,270,180);WvZHbCVTxTJBCgjShmye(gui,rqgLROQglXtqpburmEtj,270,200);WvZHbCVTxTJBCgjShmye(gui,bVQNJaKfHHilGzXwzzSz,325,180);WvZHbCVTxTJBCgjShmye(gui,FNvfmSrgQZzkDaCteqCm,325,200);WvZHbCVTxTJBCgjShmye(gui,uuBVEYiwPIGGyPmiReVm,210,240);WvZHbCVTxTJBCgjShmye(gui,gCoQauneWgYneDxakLdU,210,260);WvZHbCVTxTJBCgjShmye(gui,pMiuAEqIjBvGVwSmOqbV,400,238);WvZHbCVTxTJBCgjShmye(gui,kfDcvJsHrxudYljVdKKw,400,262);WvZHbCVTxTJBCgjShmye(gui,rXNJnPxOEphrAujPcOJz,520,240);WvZHbCVTxTJBCgjShmye(gui,xCheckAudioGhost,520,265);WvZHbCVTxTJBCgjShmye(gui,AjnQmXRAOlzKNzmliVED,600,240);WvZHbCVTxTJBCgjShmye(gui,MlvCpjqmgVwZfjuloUSN,600,265);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,220)
def byBrrdjnmtOeUUvNqMbZ():
	name=PRptGTFSeNBhCFUPbbfz(gui,jGjYOVhJaXCWJgrRkXBs);RcgxmwdulXbFqNCcXalf(gui,FaPpEVCioitqXHTOIiOs)
	for(key,value)in OlFpZxSIOWOxoYIYEJhM[_M][name][_q].items():
		if len(value)==2:value=[value[0],value[1],'']
		_text='%s%s'%(key,tuple(value));qqiewGGMbbypNfVFpsFt(gui,FaPpEVCioitqXHTOIiOs,_text)
	data=OlFpZxSIOWOxoYIYEJhM[_M][name];uTjWQRuHkfUwHqUKBXer(gui,gCoQauneWgYneDxakLdU,data.get(_AW,''));FKErQpKRMOMgGqMZMIwo(gui,rXNJnPxOEphrAujPcOJz,HVRrCGGyaZfpiVGPdXVs());FKErQpKRMOMgGqMZMIwo(gui,AjnQmXRAOlzKNzmliVED,HceohIdfJCXaWsFgnpCL());FKErQpKRMOMgGqMZMIwo(gui,MlvCpjqmgVwZfjuloUSN,dZXoHFUyHwMNBqKIohzA());FKErQpKRMOMgGqMZMIwo(gui,xCheckAudioGhost,iiMqfZTglmTicGcDbRTi());RcgxmwdulXbFqNCcXalf(gui,rqgLROQglXtqpburmEtj);qqiewGGMbbypNfVFpsFt(gui,rqgLROQglXtqpburmEtj,'');RcgxmwdulXbFqNCcXalf(gui,FNvfmSrgQZzkDaCteqCm);qqiewGGMbbypNfVFpsFt(gui,FNvfmSrgQZzkDaCteqCm,'')
	for i in range(1,10):qqiewGGMbbypNfVFpsFt(gui,rqgLROQglXtqpburmEtj,str(i));qqiewGGMbbypNfVFpsFt(gui,FNvfmSrgQZzkDaCteqCm,str(i))
	uTjWQRuHkfUwHqUKBXer(gui,rqgLROQglXtqpburmEtj,'');uTjWQRuHkfUwHqUKBXer(gui,FNvfmSrgQZzkDaCteqCm,'')
def VpTpwmfzgbsRRTMgfrPB():
	RcgxmwdulXbFqNCcXalf(gui,jGjYOVhJaXCWJgrRkXBs);qqiewGGMbbypNfVFpsFt(gui,jGjYOVhJaXCWJgrRkXBs,'');names=list(OlFpZxSIOWOxoYIYEJhM[_M].keys())
	for i in names:qqiewGGMbbypNfVFpsFt(gui,jGjYOVhJaXCWJgrRkXBs,i)
	if JzLZxXwzKEnKOuUNolBu and JzLZxXwzKEnKOuUNolBu[_B]in names:uTjWQRuHkfUwHqUKBXer(gui,jGjYOVhJaXCWJgrRkXBs,JzLZxXwzKEnKOuUNolBu[_B])
	else:uTjWQRuHkfUwHqUKBXer(gui,jGjYOVhJaXCWJgrRkXBs,'');uTjWQRuHkfUwHqUKBXer(gui,zoMICLUzgkgOQyDHCPsf,JzLZxXwzKEnKOuUNolBu[_B])
	UkgVLmhyLzQBXpNJTQkV()
ElXjOmBgdYoKHNrpXedh=_f
JRRIoawLWKiRPsglMIei=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
okrzVlfAykyiQMtGCliZ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
LfMfuuUVsewlnmxhfOnw=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
UkzJDWaHTXeTeLwCZiAP=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
ZUYvYrvNAKQWogrGLzJf=omskgOqYICjokgtwBAis(gui,'wusNhmxTjSgRhuinPbYs',_A0,X,Y)
LzcCmLbLidQhONENsKLr=omskgOqYICjokgtwBAis(gui,'bpLTFwYIIDoOlKPPRPJS',_AV,X,Y)
YLcSVnCSTHZjCFlltrnD=omskgOqYICjokgtwBAis(gui,'DpcoGbQWxToFmiwortob',_AM,X,Y)
gCkCOzjINDmWxoMzmyXj=sNOKqVOQPcbIohrgrUAk(gui,'Enemy Skill:',X,Y)
dzYwNtPQVjBxtVZbvbIH=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
fRZBJeHRQOQUqkJRofoO=omskgOqYICjokgtwBAis(gui,'FTupHJfHHuaSyOPRweol','Add Skill',X,Y)
MPaooSpPOxNaHTeIIjIJ=omskgOqYICjokgtwBAis(gui,'PzuDYdjBtNmSMHixxPvs','Del Skill',X,Y)
bDZSXxYnWLFmqcozpqgz=fNfddKvwFWUTSfLOPZiL(gui,X,Y,220,100)
SdemRjwXduadsEiIGWWz=sNOKqVOQPcbIohrgrUAk(gui,'|\n|\n|\n|\n|\n|\n|\n|\n|\n|\n|',X,Y)
pDJGQuDIsClJMhnUJHLr=sNOKqVOQPcbIohrgrUAk(gui,'Guard when %HP lower:',X,Y)
LkAXixcfzPYaGtmzdDow=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,45,25)
rsDqYXQvLiPpXYhzmICC=sNOKqVOQPcbIohrgrUAk(gui,'Delay(ms) for Guard:',X,Y)
yzeUhiGnhBcXiYKZplsy=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,45,25)
gmleXkddfpHaTUVnHLAF=omskgOqYICjokgtwBAis(gui,'qrpsNXfDqjMILbkwAgLx',_Z,X,Y)
TMWTDYcWtJMirlpRHogI=omskgOqYICjokgtwBAis(gui,'EnatxPQfYMUGySUhONzh','Next Page',X,Y)
fxlWKrjhlamlWpKXYAkG=omskgOqYICjokgtwBAis(gui,'XQncAWgDKZUgthIcxllu','Previous Page',X,Y)
RFAbSlpABRbOkugYbUDc=sNOKqVOQPcbIohrgrUAk(gui,'Key to Add:',X,Y)
RanuaRmrwSvKEXOiaqJj=sNOKqVOQPcbIohrgrUAk(gui,'Keys to Del:',X,Y)
vpoTAdzksjXEBXQSjxEl=cicZNGijwHyNUpQUUWrF(gui,X,Y,50,25)
zGURepYVlMhdFixUDOfF=cicZNGijwHyNUpQUUWrF(gui,X,Y,50,25)
abbCmiNMNDuygtoGgoxK=omskgOqYICjokgtwBAis(gui,'SZuWDyGruwCGkwJfxqtg','Add Lock Key',X,Y)
HxmBmQwiGzkQMXCjYYSL=omskgOqYICjokgtwBAis(gui,'GrwnuyDvaHTBNMnTSgZV','Del Lock Key',X,Y)
rhpTavztjcnNTXhEeuPx=sNOKqVOQPcbIohrgrUAk(gui,'Lock Until Over(ms):',X,Y)
CDzamxCmyLozRBMSzNGQ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,60,25)
HtPSfQikuMDBswVfQMGC=omskgOqYICjokgtwBAis(gui,'HIUfCGRzIBkoHfIYboHN','Scan Dir Game',X,Y)
pmRdFgiWWTgMmHIkOnNn=fNfddKvwFWUTSfLOPZiL(gui,X,Y,220,95)
SSwVdoPcpMjxWKmayfbh=omskgOqYICjokgtwBAis(gui,'zyKStRasvEaqfGLHpqGP','Add Dir Game',X,Y)
MxePSbFVGMYFuSDgwIOY=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,220,25)
tGbRwQhbAErYotZZkeSf(gui,MxePSbFVGMYFuSDgwIOY,BXxnPGdFgiHeQuztmsNz)
bSJTNaKWzgTAGtDdAuYJ=omskgOqYICjokgtwBAis(gui,'hvLeUzyxyWKtLVUyMUti',_l,X,Y)
vpWmKBBTEflJNDZcdaCu=omskgOqYICjokgtwBAis(gui,'LCPYOgsWOWRODKFMUNdR',_m,X,Y)
xCheckAudioGuard=MTbiymEMtofPpUnLhCKE(gui,'pudTeVycVaJTkXvnpBCR',_Ar,X,Y)
def pudTeVycVaJTkXvnpBCR(e):fyyUdVanLaLtVRVKrfMr(e)
def lpsoShHeoGwKssQAiZWg():
	if AikJGYbVxICEhnCEmMtM and not HkbgUnqkPodJtewqRPnE:
		char=JzLZxXwzKEnKOuUNolBu;names=eVgCyKIrycDTuQqfdcWP(gui,UkzJDWaHTXeTeLwCZiAP);_state=jUrGrJoLiUWJppoSrSBW()
		if not char or char[_B]not in names and not _state:WvZHbCVTxTJBCgjShmye(gui,bSJTNaKWzgTAGtDdAuYJ,600,75);WvZHbCVTxTJBCgjShmye(gui,vpWmKBBTEflJNDZcdaCu,X,Y);tGbRwQhbAErYotZZkeSf(gui,bSJTNaKWzgTAGtDdAuYJ,BXxnPGdFgiHeQuztmsNz);return
		if _state:WvZHbCVTxTJBCgjShmye(gui,bSJTNaKWzgTAGtDdAuYJ,X,Y);WvZHbCVTxTJBCgjShmye(gui,vpWmKBBTEflJNDZcdaCu,600,75)
		else:WvZHbCVTxTJBCgjShmye(gui,bSJTNaKWzgTAGtDdAuYJ,600,75);WvZHbCVTxTJBCgjShmye(gui,vpWmKBBTEflJNDZcdaCu,X,Y);tGbRwQhbAErYotZZkeSf(gui,bSJTNaKWzgTAGtDdAuYJ,FudbnvReIPieRucoAuaD)
	elif AikJGYbVxICEhnCEmMtM and HkbgUnqkPodJtewqRPnE:WvZHbCVTxTJBCgjShmye(gui,bSJTNaKWzgTAGtDdAuYJ,X,Y);WvZHbCVTxTJBCgjShmye(gui,vpWmKBBTEflJNDZcdaCu,X,Y)
def hvLeUzyxyWKtLVUyMUti():
	name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);_state=jUrGrJoLiUWJppoSrSBW()
	if not JzLZxXwzKEnKOuUNolBu or not JzLZxXwzKEnKOuUNolBu[_B]:return
	if _state or JzLZxXwzKEnKOuUNolBu[_B]!=name:return
	if not dXHBvgAlKNXoAQQAvRnn():return
	if not MgBELXNmBCXlKACcxQtT():return
	_data_skills=OlFpZxSIOWOxoYIYEJhM[_F][JzLZxXwzKEnKOuUNolBu[_B]][_b];_dirgame=OlFpZxSIOWOxoYIYEJhM[_F][JzLZxXwzKEnKOuUNolBu[_B]][_P]
	if not _dirgame:return
	_db_name=_dirgame[1];_IdsSkillGuard=[];_error_skill=[]
	for _skill in _data_skills:
		ids=NRShXDDOwSIcLhcoNQtv(_db_name,_skill)
		if not ids:_error_skill.append(_skill);continue
		_IdsSkillGuard+=ids
	if _error_skill:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(133,hhtizdLRxJDclVvtcTSo,_error_skill))
	if not _IdsSkillGuard:return
	JFxYyFAgjatrXZqxRrfV(_IdsSkillGuard);XCuFQPSRNGozpeCWSRHk(time());EGYPwxYxafykiRQHFYhH(FudbnvReIPieRucoAuaD);CkUMFCjcVhViUftMDrhc(FudbnvReIPieRucoAuaD);lpsoShHeoGwKssQAiZWg();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(159,hhtizdLRxJDclVvtcTSo))
def LCPYOgsWOWRODKFMUNdR():EGYPwxYxafykiRQHFYhH(BXxnPGdFgiHeQuztmsNz);XCuFQPSRNGozpeCWSRHk(_f);EfZrprCtAxjxqZlSjAMf(0);CkUMFCjcVhViUftMDrhc(BXxnPGdFgiHeQuztmsNz);lpsoShHeoGwKssQAiZWg()
def TCMtroCNUkxTYImujCIT():EhfJilTwFSXpewHcgaaS();TpREhcnoiUhuwfwwMuAr();faKXQYHBrghXXKjNVoPi()
def EhfJilTwFSXpewHcgaaS():WvZHbCVTxTJBCgjShmye(gui,SdemRjwXduadsEiIGWWz,435,110)
def MUnPGGlhXdfHMyxkuhCL():WvZHbCVTxTJBCgjShmye(gui,SdemRjwXduadsEiIGWWz,X,Y);WvZHbCVTxTJBCgjShmye(gui,gmleXkddfpHaTUVnHLAF,X,Y)
def EnatxPQfYMUGySUhONzh():NJRKYzxOXQpdoqPvnQcZ();slWWShmouvybxFkXTqqi()
def XQncAWgDKZUgthIcxllu():TpREhcnoiUhuwfwwMuAr();faKXQYHBrghXXKjNVoPi()
def faKXQYHBrghXXKjNVoPi():WvZHbCVTxTJBCgjShmye(gui,pDJGQuDIsClJMhnUJHLr,445,120);WvZHbCVTxTJBCgjShmye(gui,LkAXixcfzPYaGtmzdDow,600,115);WvZHbCVTxTJBCgjShmye(gui,rsDqYXQvLiPpXYhzmICC,445,150);WvZHbCVTxTJBCgjShmye(gui,yzeUhiGnhBcXiYKZplsy,600,145);WvZHbCVTxTJBCgjShmye(gui,ScKiNoagbHNcgOLZTVdl,445,180);WvZHbCVTxTJBCgjShmye(gui,MiRHljGgsnxqjYQFfVTq,510,180);WvZHbCVTxTJBCgjShmye(gui,WfOcwmECUeINZeCNdtwB,665,180);WvZHbCVTxTJBCgjShmye(gui,zbhvdlVsAXfbOSqTABmU,445,210);WvZHbCVTxTJBCgjShmye(gui,qIwTCEJInMETihfCcCYj,510,210);WvZHbCVTxTJBCgjShmye(gui,JDKzUOgiBIFImtbIyFup,665,210);WvZHbCVTxTJBCgjShmye(gui,TMWTDYcWtJMirlpRHogI,580,250);WvZHbCVTxTJBCgjShmye(gui,gCkCOzjINDmWxoMzmyXj,210,120);WvZHbCVTxTJBCgjShmye(gui,dzYwNtPQVjBxtVZbvbIH,280,115);WvZHbCVTxTJBCgjShmye(gui,fRZBJeHRQOQUqkJRofoO,210,150);WvZHbCVTxTJBCgjShmye(gui,MPaooSpPOxNaHTeIIjIJ,320,150);WvZHbCVTxTJBCgjShmye(gui,bDZSXxYnWLFmqcozpqgz,210,180);WvZHbCVTxTJBCgjShmye(gui,gmleXkddfpHaTUVnHLAF,445,250)
def NJRKYzxOXQpdoqPvnQcZ():
	WvZHbCVTxTJBCgjShmye(gui,pDJGQuDIsClJMhnUJHLr,X,Y);WvZHbCVTxTJBCgjShmye(gui,LkAXixcfzPYaGtmzdDow,X,Y);WvZHbCVTxTJBCgjShmye(gui,rsDqYXQvLiPpXYhzmICC,X,Y);WvZHbCVTxTJBCgjShmye(gui,yzeUhiGnhBcXiYKZplsy,X,Y);WvZHbCVTxTJBCgjShmye(gui,ScKiNoagbHNcgOLZTVdl,X,Y);WvZHbCVTxTJBCgjShmye(gui,MiRHljGgsnxqjYQFfVTq,X,Y);WvZHbCVTxTJBCgjShmye(gui,WfOcwmECUeINZeCNdtwB,X,Y);WvZHbCVTxTJBCgjShmye(gui,zbhvdlVsAXfbOSqTABmU,X,Y);WvZHbCVTxTJBCgjShmye(gui,qIwTCEJInMETihfCcCYj,X,Y);WvZHbCVTxTJBCgjShmye(gui,JDKzUOgiBIFImtbIyFup,X,Y);WvZHbCVTxTJBCgjShmye(gui,TMWTDYcWtJMirlpRHogI,X,Y)
	for widget in(gCkCOzjINDmWxoMzmyXj,dzYwNtPQVjBxtVZbvbIH,fRZBJeHRQOQUqkJRofoO,MPaooSpPOxNaHTeIIjIJ,bDZSXxYnWLFmqcozpqgz):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def TpREhcnoiUhuwfwwMuAr():WvZHbCVTxTJBCgjShmye(gui,RFAbSlpABRbOkugYbUDc,X,Y);WvZHbCVTxTJBCgjShmye(gui,vpoTAdzksjXEBXQSjxEl,X,Y);WvZHbCVTxTJBCgjShmye(gui,RanuaRmrwSvKEXOiaqJj,X,Y);WvZHbCVTxTJBCgjShmye(gui,abbCmiNMNDuygtoGgoxK,X,Y);WvZHbCVTxTJBCgjShmye(gui,HxmBmQwiGzkQMXCjYYSL,X,Y);WvZHbCVTxTJBCgjShmye(gui,zGURepYVlMhdFixUDOfF,X,Y);WvZHbCVTxTJBCgjShmye(gui,rhpTavztjcnNTXhEeuPx,X,Y);WvZHbCVTxTJBCgjShmye(gui,CDzamxCmyLozRBMSzNGQ,X,Y);WvZHbCVTxTJBCgjShmye(gui,xCheckAudioGuard,X,Y);WvZHbCVTxTJBCgjShmye(gui,fxlWKrjhlamlWpKXYAkG,X,Y);WvZHbCVTxTJBCgjShmye(gui,pmRdFgiWWTgMmHIkOnNn,X,Y);WvZHbCVTxTJBCgjShmye(gui,HtPSfQikuMDBswVfQMGC,X,Y);WvZHbCVTxTJBCgjShmye(gui,SSwVdoPcpMjxWKmayfbh,X,Y);WvZHbCVTxTJBCgjShmye(gui,MxePSbFVGMYFuSDgwIOY,X,Y)
def slWWShmouvybxFkXTqqi():WvZHbCVTxTJBCgjShmye(gui,RFAbSlpABRbOkugYbUDc,445,120);WvZHbCVTxTJBCgjShmye(gui,vpoTAdzksjXEBXQSjxEl,520,115);WvZHbCVTxTJBCgjShmye(gui,abbCmiNMNDuygtoGgoxK,590,115);WvZHbCVTxTJBCgjShmye(gui,RanuaRmrwSvKEXOiaqJj,445,150);WvZHbCVTxTJBCgjShmye(gui,HxmBmQwiGzkQMXCjYYSL,590,150);WvZHbCVTxTJBCgjShmye(gui,zGURepYVlMhdFixUDOfF,520,150);WvZHbCVTxTJBCgjShmye(gui,rhpTavztjcnNTXhEeuPx,445,190);WvZHbCVTxTJBCgjShmye(gui,CDzamxCmyLozRBMSzNGQ,570,190);WvZHbCVTxTJBCgjShmye(gui,xCheckAudioGuard,445,220);WvZHbCVTxTJBCgjShmye(gui,fxlWKrjhlamlWpKXYAkG,580,250);WvZHbCVTxTJBCgjShmye(gui,pmRdFgiWWTgMmHIkOnNn,210,115);WvZHbCVTxTJBCgjShmye(gui,HtPSfQikuMDBswVfQMGC,210,220);WvZHbCVTxTJBCgjShmye(gui,SSwVdoPcpMjxWKmayfbh,320,220);WvZHbCVTxTJBCgjShmye(gui,MxePSbFVGMYFuSDgwIOY,210,250);FKErQpKRMOMgGqMZMIwo(gui,xCheckAudioGuard,DzNIgOYuhEsMtXgzSpjn())
def wusNhmxTjSgRhuinPbYs():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,okrzVlfAykyiQMtGCliZ);names=list(OlFpZxSIOWOxoYIYEJhM[_F].keys());check=name and sXkMGiiYfTCJYksKpBKb(name)and CXmyKqeqvrjquzBvrliF(name,names)
	if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_F][name]={_b:[],_AJ:80,_Q:['',0],_c:['',0],_z:[],_AK:300,_Ap:'',_P:[],_AL:700};qqiewGGMbbypNfVFpsFt(gui,UkzJDWaHTXeTeLwCZiAP,name);uTjWQRuHkfUwHqUKBXer(gui,UkzJDWaHTXeTeLwCZiAP,name);uTjWQRuHkfUwHqUKBXer(gui,okrzVlfAykyiQMtGCliZ,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));TCMtroCNUkxTYImujCIT();DZRLJoXpPyWaPxcCFGFi()
def bpLTFwYIIDoOlKPPRPJS():TCMtroCNUkxTYImujCIT();DZRLJoXpPyWaPxcCFGFi()
def anAwRCenqbmRVlRRDqnQ():
	RcgxmwdulXbFqNCcXalf(gui,UkzJDWaHTXeTeLwCZiAP);qqiewGGMbbypNfVFpsFt(gui,UkzJDWaHTXeTeLwCZiAP,'')
	for i in OlFpZxSIOWOxoYIYEJhM[_F].keys():qqiewGGMbbypNfVFpsFt(gui,UkzJDWaHTXeTeLwCZiAP,i)
	if JzLZxXwzKEnKOuUNolBu and JzLZxXwzKEnKOuUNolBu[_B]in list(OlFpZxSIOWOxoYIYEJhM[_F].keys()):uTjWQRuHkfUwHqUKBXer(gui,UkzJDWaHTXeTeLwCZiAP,JzLZxXwzKEnKOuUNolBu[_B])
	else:uTjWQRuHkfUwHqUKBXer(gui,UkzJDWaHTXeTeLwCZiAP,'');uTjWQRuHkfUwHqUKBXer(gui,okrzVlfAykyiQMtGCliZ,JzLZxXwzKEnKOuUNolBu[_B])
	lpsoShHeoGwKssQAiZWg()
def DZRLJoXpPyWaPxcCFGFi():
	name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);_data=OlFpZxSIOWOxoYIYEJhM[_F]
	if name in list(_data.keys()):
		_data=_data[name];RcgxmwdulXbFqNCcXalf(gui,bDZSXxYnWLFmqcozpqgz)
		for i in _data[_b]:qqiewGGMbbypNfVFpsFt(gui,bDZSXxYnWLFmqcozpqgz,i)
		uTjWQRuHkfUwHqUKBXer(gui,LkAXixcfzPYaGtmzdDow,str(_data[_AJ]));uTjWQRuHkfUwHqUKBXer(gui,yzeUhiGnhBcXiYKZplsy,str(_data[_AL]));uTjWQRuHkfUwHqUKBXer(gui,MiRHljGgsnxqjYQFfVTq,_data[_Q][0]);uTjWQRuHkfUwHqUKBXer(gui,WfOcwmECUeINZeCNdtwB,str(_data[_Q][1]));uTjWQRuHkfUwHqUKBXer(gui,qIwTCEJInMETihfCcCYj,_data[_c][0]);uTjWQRuHkfUwHqUKBXer(gui,JDKzUOgiBIFImtbIyFup,str(_data[_c][1]));RcgxmwdulXbFqNCcXalf(gui,zGURepYVlMhdFixUDOfF);RcgxmwdulXbFqNCcXalf(gui,vpoTAdzksjXEBXQSjxEl)
		for i in range(10):qqiewGGMbbypNfVFpsFt(gui,vpoTAdzksjXEBXQSjxEl,str(i))
		for i in _data[_z]:qqiewGGMbbypNfVFpsFt(gui,zGURepYVlMhdFixUDOfF,i)
		uTjWQRuHkfUwHqUKBXer(gui,CDzamxCmyLozRBMSzNGQ,str(_data[_AK]));uTjWQRuHkfUwHqUKBXer(gui,MxePSbFVGMYFuSDgwIOY,''if not _data[_P]else _data[_P][0])
def DpcoGbQWxToFmiwortob():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP)
	if name:lywbvBarobpigBBffFVQ(gui,UkzJDWaHTXeTeLwCZiAP,name);del OlFpZxSIOWOxoYIYEJhM[_F][name];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));MUnPGGlhXdfHMyxkuhCL();NJRKYzxOXQpdoqPvnQcZ();TpREhcnoiUhuwfwwMuAr()
def FTupHJfHHuaSyOPRweol():
	global OlFpZxSIOWOxoYIYEJhM;char_name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);skill=PRptGTFSeNBhCFUPbbfz(gui,dzYwNtPQVjBxtVZbvbIH)
	if char_name and skill:qqiewGGMbbypNfVFpsFt(gui,bDZSXxYnWLFmqcozpqgz,skill);OlFpZxSIOWOxoYIYEJhM[_F][char_name][_b].append(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def PzuDYdjBtNmSMHixxPvs():
	global OlFpZxSIOWOxoYIYEJhM;char_name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);skill=PRptGTFSeNBhCFUPbbfz(gui,bDZSXxYnWLFmqcozpqgz)
	if char_name and skill:lywbvBarobpigBBffFVQ(gui,bDZSXxYnWLFmqcozpqgz,skill);OlFpZxSIOWOxoYIYEJhM[_F][char_name][_b].remove(skill);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def oluyRhodlFvYYYTIdpDW(e):0
def lBdWABXCYYnwYTggSJoB(e):0
def qrpsNXfDqjMILbkwAgLx():
	global OlFpZxSIOWOxoYIYEJhM;_dirgame=PRptGTFSeNBhCFUPbbfz(gui,MxePSbFVGMYFuSDgwIOY)
	if not _dirgame:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(51,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	_hpPercent=PRptGTFSeNBhCFUPbbfz(gui,LkAXixcfzPYaGtmzdDow);_delay=PRptGTFSeNBhCFUPbbfz(gui,yzeUhiGnhBcXiYKZplsy);_myshield=PRptGTFSeNBhCFUPbbfz(gui,MiRHljGgsnxqjYQFfVTq);_plusmyshield=PRptGTFSeNBhCFUPbbfz(gui,WfOcwmECUeINZeCNdtwB);_myblade=PRptGTFSeNBhCFUPbbfz(gui,qIwTCEJInMETihfCcCYj);_plusmyblade=PRptGTFSeNBhCFUPbbfz(gui,JDKzUOgiBIFImtbIyFup);_time=PRptGTFSeNBhCFUPbbfz(gui,CDzamxCmyLozRBMSzNGQ);char_name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);ZABqcMudSCSkxJZnjkgA=jgToXycDXrngTAkWJuVA(_myshield,7)and jgToXycDXrngTAkWJuVA(_myblade,6)
	if not ZABqcMudSCSkxJZnjkgA:return
	if char_name:
		if _hpPercent and _hpPercent.isdigit():OlFpZxSIOWOxoYIYEJhM[_F][char_name][_AJ]=int(_hpPercent)
		if _delay.isdigit():OlFpZxSIOWOxoYIYEJhM[_F][char_name][_AL]=int(_delay)
		if _plusmyshield.isdigit():OlFpZxSIOWOxoYIYEJhM[_F][char_name][_Q][1]=int(_plusmyshield)
		if _plusmyblade.isdigit():OlFpZxSIOWOxoYIYEJhM[_F][char_name][_c][1]=int(_plusmyblade)
		if _time and _time.isdigit():OlFpZxSIOWOxoYIYEJhM[_F][char_name][_AK]=int(_time)
		OlFpZxSIOWOxoYIYEJhM[_F][char_name][_Q][0]=_myshield;OlFpZxSIOWOxoYIYEJhM[_F][char_name][_c][0]=_myblade
		if _myshield:
			for i in['Soul Cut Blade','Evil Cut Blade','Devil Cut Blade','Demon Cut Blade','Ghost Cut Blade','Emperor Blade','Heaven Cut Blade','Ghost Hell Cut Blade']:
				if i not in OlFpZxSIOWOxoYIYEJhM[_F][char_name][_b]:OlFpZxSIOWOxoYIYEJhM[_F][char_name][_b].append(i)
		if ElXjOmBgdYoKHNrpXedh:OlFpZxSIOWOxoYIYEJhM[_F][char_name][_P]=[];OlFpZxSIOWOxoYIYEJhM[_F][char_name][_P].append(_dirgame);OlFpZxSIOWOxoYIYEJhM[_F][char_name][_P].append(ElXjOmBgdYoKHNrpXedh[_dirgame])
		YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def HIUfCGRzIBkoHfIYboHN():
	global ElXjOmBgdYoKHNrpXedh;ElXjOmBgdYoKHNrpXedh=LztAXnhiKGgHUhZAOKPm()
	if ElXjOmBgdYoKHNrpXedh:
		RcgxmwdulXbFqNCcXalf(gui,pmRdFgiWWTgMmHIkOnNn)
		for key in ElXjOmBgdYoKHNrpXedh.keys():qqiewGGMbbypNfVFpsFt(gui,pmRdFgiWWTgMmHIkOnNn,key)
def zyKStRasvEaqfGLHpqGP():
	_dirgame=PRptGTFSeNBhCFUPbbfz(gui,pmRdFgiWWTgMmHIkOnNn)
	if _dirgame:uTjWQRuHkfUwHqUKBXer(gui,MxePSbFVGMYFuSDgwIOY,_dirgame)
def SZuWDyGruwCGkwJfxqtg():
	global OlFpZxSIOWOxoYIYEJhM;char_name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);key=PRptGTFSeNBhCFUPbbfz(gui,vpoTAdzksjXEBXQSjxEl)
	if char_name:
		if key not in eVgCyKIrycDTuQqfdcWP(gui,zGURepYVlMhdFixUDOfF):qqiewGGMbbypNfVFpsFt(gui,zGURepYVlMhdFixUDOfF,key);OlFpZxSIOWOxoYIYEJhM[_F][char_name][_z].append(key);uTjWQRuHkfUwHqUKBXer(gui,zGURepYVlMhdFixUDOfF,key);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def GrwnuyDvaHTBNMnTSgZV():
	global OlFpZxSIOWOxoYIYEJhM;char_name=PRptGTFSeNBhCFUPbbfz(gui,UkzJDWaHTXeTeLwCZiAP);key=PRptGTFSeNBhCFUPbbfz(gui,zGURepYVlMhdFixUDOfF)
	if char_name and key:lywbvBarobpigBBffFVQ(gui,zGURepYVlMhdFixUDOfF,key);OlFpZxSIOWOxoYIYEJhM[_F][char_name][_z].remove(key);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
etZxsUGaZLJsueozRioa=sNOKqVOQPcbIohrgrUAk(gui,gOihekBFXcHYPnEWvRby,X,Y)
nXlrKLbPDJlhpFVUMPsL=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
zCLwrPnpnYspBWmDDJfP=omskgOqYICjokgtwBAis(gui,'wmEsnZbMIlpvqvrKIgdH',cGXrZAPKGLDhdlNKjCqi,X,Y)
gDFTFSiItMtJaMxVONcM=omskgOqYICjokgtwBAis(gui,'kAxQeKDsPsCTFvPhUyBG',hwkcJwWNZpwfwGZipALG,X,Y)
def kAxQeKDsPsCTFvPhUyBG():ggvmUMrbdrlLcjeNiZfv()
def wmEsnZbMIlpvqvrKIgdH():0
cLvyYlgPieWyFJHxVrne()
def mZivyhrtCmFlnjosfjJD(_state):
	if not HJdVyyMWCyRWFELbqmXn():
		WvZHbCVTxTJBCgjShmye(gui,xDaEEvpcoVSKCUvKhGFA,10,15);WvZHbCVTxTJBCgjShmye(gui,jEHwoYvtOlbVjNhLKYti,130,10);WvZHbCVTxTJBCgjShmye(gui,evOwxJrsOZvaGUYoKqpb,300,10);WvZHbCVTxTJBCgjShmye(gui,HrhrMrFKhXEbhdFeWNSk,480,10);WvZHbCVTxTJBCgjShmye(gui,vVuWMtEcHQQPjdIUnXnM,610,10)
		if not OlFpZxSIOWOxoYIYEJhM.get(_t,[]):uTjWQRuHkfUwHqUKBXer(gui,HrhrMrFKhXEbhdFeWNSk,'No Update');tGbRwQhbAErYotZZkeSf(gui,HrhrMrFKhXEbhdFeWNSk,BXxnPGdFgiHeQuztmsNz)
		else:uTjWQRuHkfUwHqUKBXer(gui,HrhrMrFKhXEbhdFeWNSk,'Update v'+OlFpZxSIOWOxoYIYEJhM[_t][0]);tGbRwQhbAErYotZZkeSf(gui,HrhrMrFKhXEbhdFeWNSk,FudbnvReIPieRucoAuaD)
	else:WvZHbCVTxTJBCgjShmye(gui,xDaEEvpcoVSKCUvKhGFA,10,15);WvZHbCVTxTJBCgjShmye(gui,jEHwoYvtOlbVjNhLKYti,130,10);WvZHbCVTxTJBCgjShmye(gui,evOwxJrsOZvaGUYoKqpb,250,10);WvZHbCVTxTJBCgjShmye(gui,HrhrMrFKhXEbhdFeWNSk,X,Y);WvZHbCVTxTJBCgjShmye(gui,vVuWMtEcHQQPjdIUnXnM,X,Y)
	_listM=[UadeXYTTjsnHZgbjglBF,pOqhqjahTChffUmvYNpV,LRpdqDEzxIiYuvRgmPQv,ueRlwYOgYMOANNGltjlM,gWdKbUSpeAxLBsFpKEoh,uxEEKQBahJEZmcaIYvwz,TQIGWOCWIwQiiaAiZuoh,eOtvjPpLCvYJLAcmGmWE,RXLhvOUUgCoAWtoSabHd,LABGrwxIiQmJiCamnppg,UOeyomueyHdkSVmrxcuU,gchiMbbqpxaRcgMTnhMD,ZDfyCJwrIyzereZbIFbZ,ynMQpjqQNdICJcJRoSKz,rLUdvylZXYXGFgnnQxpR,JETeNgvirUhkMZGnFCCC,xBtnShowBuyF10,xBtnShowChangePt]
	if NEuxUqpaygzzghskZNYg():
		for i in _listM:tGbRwQhbAErYotZZkeSf(gui,i,BXxnPGdFgiHeQuztmsNz)
		return
	result=_state()
	for i in _listM:tGbRwQhbAErYotZZkeSf(gui,i,result)
mZivyhrtCmFlnjosfjJD(MgBELXNmBCXlKACcxQtT)
MQgXEHAiouCmhiegvKSP=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
qeXpNIYMibteftHLjPGv=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
YpVacNrGcyWllzeHEjfV=sNOKqVOQPcbIohrgrUAk(gui,'List Chars',X,Y)
DloQAPkbAFvsWHtXKQnT=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
HslWWZxlSKsKUmFKXSJl=omskgOqYICjokgtwBAis(gui,'NGLaLtoImrokspOHMHSg',_A0,X,Y)
pwIcWppRrmipUWGWeMYK=omskgOqYICjokgtwBAis(gui,'wFSGlnSRuWPQUdnkLkFj',_AV,X,Y)
UjsCERByfVIARjIoPvfp=omskgOqYICjokgtwBAis(gui,'sGFOMJDdGERgMugatbZs','Info Char',X,Y)
IBFCtvjRlDoprxNRvLqn=omskgOqYICjokgtwBAis(gui,'usOvXkAiMrapEqEBdwci',_Aq,X,Y)
dnbbkTYgCrhJpfvgRfHo=sNOKqVOQPcbIohrgrUAk(gui,'Item/id:',X,Y)
FWoDdxxNmpAhykdIcqgH=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
YTwSaKOkYrAZtebaVeiw=sNOKqVOQPcbIohrgrUAk(gui,_n,X,Y)
vHMfDCIaCutsJlEXFWGt=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,25,25)
FlxJOkkfqNoojXNLRvvU=MTbiymEMtofPpUnLhCKE(gui,'mrrSaTegMdmjqftJIsVS','GuildStore',X,Y)
OYdmsQSKHzPHogiTfIMf=cicZNGijwHyNUpQUUWrF(gui,X,Y,90,25)
ezrhrqYpjPHyGmsiZWwm=omskgOqYICjokgtwBAis(gui,'xCbsngdmWBledmvYvhBx',_Z,X,Y)
MJTkQVeQbnTINLchheMF=omskgOqYICjokgtwBAis(gui,'VoALfzBIvQnTcMYqZtXw','Update to Head',X,Y)
OOmKQSwVZESkNMVMggNY=omskgOqYICjokgtwBAis(gui,'YItAayhesFDXQiVPckub','Update to Shirt',X,Y)
klXxxtPsviBtOuezzAaA=omskgOqYICjokgtwBAis(gui,'KAYxDdnqdYBHdzjTApLi','Update to Shoulder',X,Y)
yRrlWZOlmevQQdBLnpYx=omskgOqYICjokgtwBAis(gui,'rjzcHwBDrwAFuUNOSVZo','Update to Hand',X,Y)
pXMXbnMSlBhWTutLdkIL=omskgOqYICjokgtwBAis(gui,'rjWIaAOdmzECMwjTdEtY','Update to Trousers',X,Y)
lksJmGNAUofrIBYeqUwX=omskgOqYICjokgtwBAis(gui,'mDoHiEYdEqzaJTnDVSZz','Update to Foot',X,Y)
IuqwSFuqiDxVmdWUQLIT=omskgOqYICjokgtwBAis(gui,'ZdZthTqxaMjcXNilOQBU','Update to Weapon',X,Y)
gSIQZfxPlKMlgwbIRsIe=omskgOqYICjokgtwBAis(gui,'AflVgjUKnrrXVmpEZwix','Update to Shield',X,Y)
LyQinWrTxEJOEBkvcBwj=omskgOqYICjokgtwBAis(gui,'VaqtSLhqMKeScKLILoPZ','Update to Earring',X,Y)
oxQREMVcGTGPsYyUhojt=omskgOqYICjokgtwBAis(gui,'mMNrECWfSHfkYMfLPUJu','Update to Necklace',X,Y)
BrCfegpSNSvOthnLvCUx=omskgOqYICjokgtwBAis(gui,'BPdyGOhhwthEjHPMgVZi','Update to Ring A',X,Y)
eucMclLOyCjsfARhXhgI=omskgOqYICjokgtwBAis(gui,'aZLaHLEppgcViCgEJiAr','Update to Ring B',X,Y)
lfTqcPXaoeBOjnXAZqpa=sNOKqVOQPcbIohrgrUAk(gui,'Head:',X,Y)
gucTukjVesnmltAqYNsa=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
MVJGMRKFdJeyWrdUhpIO=sNOKqVOQPcbIohrgrUAk(gui,'Shirt:',X,Y)
bvegEQjeLqEBNockbtwY=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
EnSnGgQdVrlxXYodFQXU=sNOKqVOQPcbIohrgrUAk(gui,'Shoulder:',X,Y)
tCkxWnGyFUQerUMLxVtw=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
fRJZafFJKvgaWQUEedhV=sNOKqVOQPcbIohrgrUAk(gui,'Hand:',X,Y)
OmpYHYLGOpZWCyZwyhKa=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
RBbaKEYBzaaDWFujtJkz=sNOKqVOQPcbIohrgrUAk(gui,'Trousers:',X,Y)
ixeDsMELRdgtBzwlbqCq=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
lxnqePAwSnMvdgyqLNlc=sNOKqVOQPcbIohrgrUAk(gui,'Foot:',X,Y)
eGOXndeHTsyAPIJDTYli=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
LRzdeMQWCHFXPdAMsauf=sNOKqVOQPcbIohrgrUAk(gui,'Weapon:',X,Y)
CqRPNEPzPxwZHYlvUDvn=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
gSEtJMCxPEPLnqTrFFkw=sNOKqVOQPcbIohrgrUAk(gui,_Ao,X,Y)
nLAlbRRPjDijABMJojXG=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
eMPXSBCkaEefOvcJuUgi=sNOKqVOQPcbIohrgrUAk(gui,'Earring:',X,Y)
DyfyJcOXqPMttIVOenJD=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
simMUnAsNTTvgTrwwPSw=sNOKqVOQPcbIohrgrUAk(gui,'Necklace:',X,Y)
kNSAdLyMBqdhnyKDbDbl=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
jyuUJeiaLuirNcKjhEMI=sNOKqVOQPcbIohrgrUAk(gui,'Ring A:',X,Y)
SztvRfknYKmyidcbHdZo=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
KCzUYTZjhwhmQTtctbYp=sNOKqVOQPcbIohrgrUAk(gui,'Ring B:',X,Y)
TpKDLCgVVUIvdzQWHlFr=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
def RJnKmwdpiMudiYfsBVjg():WvZHbCVTxTJBCgjShmye(gui,dnbbkTYgCrhJpfvgRfHo,210,115);WvZHbCVTxTJBCgjShmye(gui,FWoDdxxNmpAhykdIcqgH,260,110);WvZHbCVTxTJBCgjShmye(gui,YTwSaKOkYrAZtebaVeiw,380,115);WvZHbCVTxTJBCgjShmye(gui,vHMfDCIaCutsJlEXFWGt,390,110);WvZHbCVTxTJBCgjShmye(gui,FlxJOkkfqNoojXNLRvvU,425,115);WvZHbCVTxTJBCgjShmye(gui,OYdmsQSKHzPHogiTfIMf,510,110);WvZHbCVTxTJBCgjShmye(gui,ezrhrqYpjPHyGmsiZWwm,610,110);WvZHbCVTxTJBCgjShmye(gui,MJTkQVeQbnTINLchheMF,210,140);WvZHbCVTxTJBCgjShmye(gui,OOmKQSwVZESkNMVMggNY,210,175);WvZHbCVTxTJBCgjShmye(gui,klXxxtPsviBtOuezzAaA,210,210);WvZHbCVTxTJBCgjShmye(gui,yRrlWZOlmevQQdBLnpYx,210,245);WvZHbCVTxTJBCgjShmye(gui,pXMXbnMSlBhWTutLdkIL,380,140);WvZHbCVTxTJBCgjShmye(gui,lksJmGNAUofrIBYeqUwX,380,175);WvZHbCVTxTJBCgjShmye(gui,IuqwSFuqiDxVmdWUQLIT,380,210);WvZHbCVTxTJBCgjShmye(gui,gSIQZfxPlKMlgwbIRsIe,380,245);WvZHbCVTxTJBCgjShmye(gui,LyQinWrTxEJOEBkvcBwj,550,140);WvZHbCVTxTJBCgjShmye(gui,oxQREMVcGTGPsYyUhojt,550,175);WvZHbCVTxTJBCgjShmye(gui,BrCfegpSNSvOthnLvCUx,550,210);WvZHbCVTxTJBCgjShmye(gui,eucMclLOyCjsfARhXhgI,550,245);uTjWQRuHkfUwHqUKBXer(gui,vHMfDCIaCutsJlEXFWGt,'0');miHkBVWBHTuNunFAdZPE()
def nuieBsZYNWtSZWUWIKHf():WvZHbCVTxTJBCgjShmye(gui,lfTqcPXaoeBOjnXAZqpa,210,110);WvZHbCVTxTJBCgjShmye(gui,gucTukjVesnmltAqYNsa,260,110);WvZHbCVTxTJBCgjShmye(gui,MVJGMRKFdJeyWrdUhpIO,210,140);WvZHbCVTxTJBCgjShmye(gui,bvegEQjeLqEBNockbtwY,260,140);WvZHbCVTxTJBCgjShmye(gui,EnSnGgQdVrlxXYodFQXU,210,170);WvZHbCVTxTJBCgjShmye(gui,tCkxWnGyFUQerUMLxVtw,270,170);WvZHbCVTxTJBCgjShmye(gui,fRJZafFJKvgaWQUEedhV,210,200);WvZHbCVTxTJBCgjShmye(gui,OmpYHYLGOpZWCyZwyhKa,260,200);WvZHbCVTxTJBCgjShmye(gui,RBbaKEYBzaaDWFujtJkz,210,230);WvZHbCVTxTJBCgjShmye(gui,ixeDsMELRdgtBzwlbqCq,270,230);WvZHbCVTxTJBCgjShmye(gui,lxnqePAwSnMvdgyqLNlc,210,260);WvZHbCVTxTJBCgjShmye(gui,eGOXndeHTsyAPIJDTYli,260,260);WvZHbCVTxTJBCgjShmye(gui,LRzdeMQWCHFXPdAMsauf,450,110);WvZHbCVTxTJBCgjShmye(gui,CqRPNEPzPxwZHYlvUDvn,510,110);WvZHbCVTxTJBCgjShmye(gui,gSEtJMCxPEPLnqTrFFkw,450,140);WvZHbCVTxTJBCgjShmye(gui,nLAlbRRPjDijABMJojXG,510,140);WvZHbCVTxTJBCgjShmye(gui,eMPXSBCkaEefOvcJuUgi,450,170);WvZHbCVTxTJBCgjShmye(gui,DyfyJcOXqPMttIVOenJD,510,170);WvZHbCVTxTJBCgjShmye(gui,simMUnAsNTTvgTrwwPSw,450,200);WvZHbCVTxTJBCgjShmye(gui,kNSAdLyMBqdhnyKDbDbl,510,200);WvZHbCVTxTJBCgjShmye(gui,jyuUJeiaLuirNcKjhEMI,450,230);WvZHbCVTxTJBCgjShmye(gui,SztvRfknYKmyidcbHdZo,510,230);WvZHbCVTxTJBCgjShmye(gui,KCzUYTZjhwhmQTtctbYp,450,260);WvZHbCVTxTJBCgjShmye(gui,TpKDLCgVVUIvdzQWHlFr,510,260)
def JPvYTWZxMZbMgRQpVbPe():
	for widget in(dnbbkTYgCrhJpfvgRfHo,FWoDdxxNmpAhykdIcqgH,YTwSaKOkYrAZtebaVeiw,vHMfDCIaCutsJlEXFWGt,MJTkQVeQbnTINLchheMF,OOmKQSwVZESkNMVMggNY,klXxxtPsviBtOuezzAaA,yRrlWZOlmevQQdBLnpYx,pXMXbnMSlBhWTutLdkIL,lksJmGNAUofrIBYeqUwX,IuqwSFuqiDxVmdWUQLIT,gSIQZfxPlKMlgwbIRsIe,LyQinWrTxEJOEBkvcBwj,oxQREMVcGTGPsYyUhojt,BrCfegpSNSvOthnLvCUx,eucMclLOyCjsfARhXhgI,FlxJOkkfqNoojXNLRvvU,OYdmsQSKHzPHogiTfIMf,ezrhrqYpjPHyGmsiZWwm):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def ivIuoZFbuOvrszZFgCtN():
	for widget in(lfTqcPXaoeBOjnXAZqpa,gucTukjVesnmltAqYNsa,MVJGMRKFdJeyWrdUhpIO,bvegEQjeLqEBNockbtwY,EnSnGgQdVrlxXYodFQXU,tCkxWnGyFUQerUMLxVtw,fRJZafFJKvgaWQUEedhV,OmpYHYLGOpZWCyZwyhKa,RBbaKEYBzaaDWFujtJkz,ixeDsMELRdgtBzwlbqCq,lxnqePAwSnMvdgyqLNlc,eGOXndeHTsyAPIJDTYli,LRzdeMQWCHFXPdAMsauf,CqRPNEPzPxwZHYlvUDvn,gSEtJMCxPEPLnqTrFFkw,nLAlbRRPjDijABMJojXG,eMPXSBCkaEefOvcJuUgi,DyfyJcOXqPMttIVOenJD,simMUnAsNTTvgTrwwPSw,kNSAdLyMBqdhnyKDbDbl,jyuUJeiaLuirNcKjhEMI,SztvRfknYKmyidcbHdZo,KCzUYTZjhwhmQTtctbYp,TpKDLCgVVUIvdzQWHlFr):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def NGLaLtoImrokspOHMHSg():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,qeXpNIYMibteftHLjPGv);l=list(OlFpZxSIOWOxoYIYEJhM[_S].keys());check=name and CXmyKqeqvrjquzBvrliF(name,l)and sXkMGiiYfTCJYksKpBKb(name)
	if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_S][name]=qvgswFvOQZgNvXhZexCn();qqiewGGMbbypNfVFpsFt(gui,DloQAPkbAFvsWHtXKQnT,name);uTjWQRuHkfUwHqUKBXer(gui,DloQAPkbAFvsWHtXKQnT,name);uTjWQRuHkfUwHqUKBXer(gui,qeXpNIYMibteftHLjPGv,'');YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));JPvYTWZxMZbMgRQpVbPe();ivIuoZFbuOvrszZFgCtN()
def usOvXkAiMrapEqEBdwci():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,DloQAPkbAFvsWHtXKQnT)
	if not name:return BXxnPGdFgiHeQuztmsNz
	lywbvBarobpigBBffFVQ(gui,DloQAPkbAFvsWHtXKQnT,name);del OlFpZxSIOWOxoYIYEJhM[_S][name];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));JPvYTWZxMZbMgRQpVbPe();ivIuoZFbuOvrszZFgCtN()
def wFSGlnSRuWPQUdnkLkFj():ivIuoZFbuOvrszZFgCtN();RJnKmwdpiMudiYfsBVjg()
def sGFOMJDdGERgMugatbZs():JPvYTWZxMZbMgRQpVbPe();nuieBsZYNWtSZWUWIKHf();YIKZKuSqKKLPEvfOPMVq()
def fXdngHUMGfdmCsQtzyKg():
	RcgxmwdulXbFqNCcXalf(gui,DloQAPkbAFvsWHtXKQnT);qqiewGGMbbypNfVFpsFt(gui,DloQAPkbAFvsWHtXKQnT,'');names=list(OlFpZxSIOWOxoYIYEJhM[_S].keys())
	for i in names:qqiewGGMbbypNfVFpsFt(gui,DloQAPkbAFvsWHtXKQnT,i)
	name=''if not JzLZxXwzKEnKOuUNolBu else JzLZxXwzKEnKOuUNolBu[_B]
	if name in names:uTjWQRuHkfUwHqUKBXer(gui,DloQAPkbAFvsWHtXKQnT,name)
	else:uTjWQRuHkfUwHqUKBXer(gui,DloQAPkbAFvsWHtXKQnT,'');uTjWQRuHkfUwHqUKBXer(gui,qeXpNIYMibteftHLjPGv,''if not JzLZxXwzKEnKOuUNolBu else JzLZxXwzKEnKOuUNolBu[_B])
def YIKZKuSqKKLPEvfOPMVq():
	name=PRptGTFSeNBhCFUPbbfz(gui,DloQAPkbAFvsWHtXKQnT)
	if not name:return BXxnPGdFgiHeQuztmsNz
	data=OlFpZxSIOWOxoYIYEJhM[_S][name].copy();uTjWQRuHkfUwHqUKBXer(gui,gucTukjVesnmltAqYNsa,lbUTBYHdkHomdLvvBFKQ(data['00'][0],data['00'][1]));uTjWQRuHkfUwHqUKBXer(gui,bvegEQjeLqEBNockbtwY,lbUTBYHdkHomdLvvBFKQ(data['01'][0],data['01'][1]));uTjWQRuHkfUwHqUKBXer(gui,tCkxWnGyFUQerUMLxVtw,lbUTBYHdkHomdLvvBFKQ(data['02'][0],data['02'][1]));uTjWQRuHkfUwHqUKBXer(gui,OmpYHYLGOpZWCyZwyhKa,lbUTBYHdkHomdLvvBFKQ(data['03'][0],data['03'][1]));uTjWQRuHkfUwHqUKBXer(gui,ixeDsMELRdgtBzwlbqCq,lbUTBYHdkHomdLvvBFKQ(data['04'][0],data['04'][1]));uTjWQRuHkfUwHqUKBXer(gui,eGOXndeHTsyAPIJDTYli,lbUTBYHdkHomdLvvBFKQ(data['05'][0],data['05'][1]));uTjWQRuHkfUwHqUKBXer(gui,CqRPNEPzPxwZHYlvUDvn,lbUTBYHdkHomdLvvBFKQ(data['06'][0],data['06'][1]));uTjWQRuHkfUwHqUKBXer(gui,nLAlbRRPjDijABMJojXG,lbUTBYHdkHomdLvvBFKQ(data['07'][0],data['07'][1]));uTjWQRuHkfUwHqUKBXer(gui,DyfyJcOXqPMttIVOenJD,lbUTBYHdkHomdLvvBFKQ(data['09'][0],data['09'][1]));uTjWQRuHkfUwHqUKBXer(gui,kNSAdLyMBqdhnyKDbDbl,lbUTBYHdkHomdLvvBFKQ(data['10'][0],data['10'][1]));uTjWQRuHkfUwHqUKBXer(gui,SztvRfknYKmyidcbHdZo,lbUTBYHdkHomdLvvBFKQ(data['11'][0],data['11'][1]));uTjWQRuHkfUwHqUKBXer(gui,TpKDLCgVVUIvdzQWHlFr,lbUTBYHdkHomdLvvBFKQ(data['12'][0],data['12'][1]))
def lbUTBYHdkHomdLvvBFKQ(name,plus):
	if not name:return NweMXVypQZSXaVSCagqM(49)
	if name and not plus:return f"[{name}]"
	else:return'[%s][+%s]'%(name,plus)
def qvgswFvOQZgNvXhZexCn():result={'00':['',0],'01':['',0],'02':['',0],'03':['',0],'04':['',0],'05':['',0],'06':['',0],'07':['',0],'08':['',0],'09':['',0],'10':['',0],'11':['',0],'12':['',0],'13':[FudbnvReIPieRucoAuaD,_AX]};return result
def VoALfzBIvQnTcMYqZtXw():tByUiECbSYVnbrrIJast('00')
def YItAayhesFDXQiVPckub():tByUiECbSYVnbrrIJast('01')
def KAYxDdnqdYBHdzjTApLi():tByUiECbSYVnbrrIJast('02')
def rjzcHwBDrwAFuUNOSVZo():tByUiECbSYVnbrrIJast('03')
def rjWIaAOdmzECMwjTdEtY():tByUiECbSYVnbrrIJast('04')
def mDoHiEYdEqzaJTnDVSZz():tByUiECbSYVnbrrIJast('05')
def ZdZthTqxaMjcXNilOQBU():tByUiECbSYVnbrrIJast('06')
def AflVgjUKnrrXVmpEZwix():tByUiECbSYVnbrrIJast('07')
def VaqtSLhqMKeScKLILoPZ():tByUiECbSYVnbrrIJast('09')
def mMNrECWfSHfkYMfLPUJu():tByUiECbSYVnbrrIJast('10')
def BPdyGOhhwthEjHPMgVZi():tByUiECbSYVnbrrIJast('11')
def aZLaHLEppgcViCgEJiAr():tByUiECbSYVnbrrIJast('12')
def tByUiECbSYVnbrrIJast(key):
	global OlFpZxSIOWOxoYIYEJhM;item=PRptGTFSeNBhCFUPbbfz(gui,FWoDdxxNmpAhykdIcqgH);plus=PRptGTFSeNBhCFUPbbfz(gui,vHMfDCIaCutsJlEXFWGt);name=PRptGTFSeNBhCFUPbbfz(gui,DloQAPkbAFvsWHtXKQnT)
	if not plus.isdigit():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,'Name/plus'));return BXxnPGdFgiHeQuztmsNz
	if not name:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(50,hhtizdLRxJDclVvtcTSo));return BXxnPGdFgiHeQuztmsNz
	if item==OlFpZxSIOWOxoYIYEJhM[_S][name][key][0]and int(plus)==OlFpZxSIOWOxoYIYEJhM[_S][name][key][1]:return BXxnPGdFgiHeQuztmsNz
	ZABqcMudSCSkxJZnjkgA=jgToXycDXrngTAkWJuVA(item,int(key))
	if not ZABqcMudSCSkxJZnjkgA:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,item));return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_S][name][key][0]=item;OlFpZxSIOWOxoYIYEJhM[_S][name][key][1]=int(plus);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);uTjWQRuHkfUwHqUKBXer(gui,FWoDdxxNmpAhykdIcqgH,'');dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def mrrSaTegMdmjqftJIsVS(e):
	global OlFpZxSIOWOxoYIYEJhM
	if e:tGbRwQhbAErYotZZkeSf(gui,OYdmsQSKHzPHogiTfIMf,BXxnPGdFgiHeQuztmsNz)
	else:tGbRwQhbAErYotZZkeSf(gui,OYdmsQSKHzPHogiTfIMf,FudbnvReIPieRucoAuaD)
def xCbsngdmWBledmvYvhBx():
	guildStore=LBRexqqDJqawZRqWrNZr(gui,FlxJOkkfqNoojXNLRvvU);pet=PRptGTFSeNBhCFUPbbfz(gui,OYdmsQSKHzPHogiTfIMf);myChar=PRptGTFSeNBhCFUPbbfz(gui,DloQAPkbAFvsWHtXKQnT)
	if not myChar:dRBzRDsZDulhsFtoVKPh(_B5%hhtizdLRxJDclVvtcTSo);return
	if not guildStore:
		checkPet=BXxnPGdFgiHeQuztmsNz;id_pet=ktBDDWFTZcCRFnLfJUrr(pet);items=LDlkmjOOgaGCsuHjpvOt()[_W]
		for i in items:
			if i and i['model']==id_pet:checkPet=FudbnvReIPieRucoAuaD;break
		if not checkPet:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(88,hhtizdLRxJDclVvtcTSo,pet));return
	OlFpZxSIOWOxoYIYEJhM[_S][myChar]['13']=[guildStore,pet];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(87,hhtizdLRxJDclVvtcTSo))
def miHkBVWBHTuNunFAdZPE():
	global OlFpZxSIOWOxoYIYEJhM;char=PRptGTFSeNBhCFUPbbfz(gui,DloQAPkbAFvsWHtXKQnT)
	if not char:dRBzRDsZDulhsFtoVKPh(_B5%hhtizdLRxJDclVvtcTSo);return
	option=OlFpZxSIOWOxoYIYEJhM[_S][char];option=option.get('13',{})
	if not option:option=OlFpZxSIOWOxoYIYEJhM[_S][char]['13']=[FudbnvReIPieRucoAuaD,_AX]
	_pets=[_AX,'Rabbit','Spotted Rabbit','Squirrel','Monkey','Raccoon dog','Cat','Sylph','Great Glider','Gold Pig','Pink Pig'];RcgxmwdulXbFqNCcXalf(gui,OYdmsQSKHzPHogiTfIMf)
	for pet in _pets:qqiewGGMbbypNfVFpsFt(gui,OYdmsQSKHzPHogiTfIMf,pet)
	uTjWQRuHkfUwHqUKBXer(gui,OYdmsQSKHzPHogiTfIMf,option[1]);guildStore=option[0]
	if guildStore:FKErQpKRMOMgGqMZMIwo(gui,FlxJOkkfqNoojXNLRvvU,FudbnvReIPieRucoAuaD);tGbRwQhbAErYotZZkeSf(gui,OYdmsQSKHzPHogiTfIMf,BXxnPGdFgiHeQuztmsNz)
	else:FKErQpKRMOMgGqMZMIwo(gui,FlxJOkkfqNoojXNLRvvU,BXxnPGdFgiHeQuztmsNz);tGbRwQhbAErYotZZkeSf(gui,OYdmsQSKHzPHogiTfIMf,FudbnvReIPieRucoAuaD)
FnrHhZocsHkYJWteJqKt=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
viEDPlfMTniBwXCFMjKb=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
ADGxjZwXdDKjfsTVmsJY=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
FHiihcDteaNbnvlnioXs=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
VbVSBQTqePXzoVwpUiQm=omskgOqYICjokgtwBAis(gui,'EwZOHIaxExXUtHICVxKy',_A0,X,Y)
kBINHWjHmIUqbinvQybt=omskgOqYICjokgtwBAis(gui,'kWxCKMlYfZiZCuwMZdxW',_AM,X,Y)
dMcCNRIIctjHrEJiGOBG=omskgOqYICjokgtwBAis(gui,'EhTFRVeSuAdOIvoITMqu','Check State',X,Y)
ZchCyBnnGCkhwEDbMBWi=omskgOqYICjokgtwBAis(gui,'tsJFmMtepaSNIjazWBvN',_l,X,Y)
gGQWDPsKtZMXFnbMusDg=omskgOqYICjokgtwBAis(gui,'RxjUpBxsOmfwyAKDvuVM',_m,X,Y)
RNlHJwzCfwHMHAssLcuM=sNOKqVOQPcbIohrgrUAk(gui,'Select to Buy:',X,Y)
BDvULMWHKEFTPBRfvzkd=sNOKqVOQPcbIohrgrUAk(gui,'Qty(pack):',X,Y)
jUBnWgbKtMHlmKrNQfQO=sNOKqVOQPcbIohrgrUAk(gui,'If(unit) <:',X,Y)
cYtPjLEsLVVEkREiYVCd=omskgOqYICjokgtwBAis(gui,'KFzjcANBvxXjCiXSmUnK','Begin sample',X,Y)
FYSUaVzvPDqlxfnMxZYf=omskgOqYICjokgtwBAis(gui,'VVWPcEprpxanjprMYFSk','End sample',X,Y)
UPruSejFNfznfEbNuGbk=omskgOqYICjokgtwBAis(gui,'LpgixOKnIYNLWySbEtwf','Del sample',X,Y)
wcPxcWRXcigrQwkplDDo=cicZNGijwHyNUpQUUWrF(gui,X,Y,275,25)
IyNDuGraslfIZDgwBrkM=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,25)
IMmIthmLIYmpcjvWkdEB=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,25)
ZnNmoYlQaYBViYyybPiM=omskgOqYICjokgtwBAis(gui,'BksJLkaiHASjaPlWpwMp','Add Item',X,Y)
GppLLXrLmQhCuXhdxShl=cicZNGijwHyNUpQUUWrF(gui,X,Y,275,25)
BzcfrdidXLLPeaZKFEfY=omskgOqYICjokgtwBAis(gui,'rtQnWHYhDbUKgRdZyvqp','Del Item',X,Y)
EycwjCvtwipdkyIpBgHf=MTbiymEMtofPpUnLhCKE(gui,'IBhCaNwAXCgkAYUthYHX','Extension Pet',X,Y)
fMHConstndliwMODiJyw=MTbiymEMtofPpUnLhCKE(gui,'KaxXcmbnnsHPDsDUUiip','Buy GoldTime Ticket',X,Y)
yDskoFdWOJAXmnPHYebJ=MTbiymEMtofPpUnLhCKE(gui,'xPIIbPqiWEuCgSRIHsiH','Relogin',X,Y)
rnzCACbSNTyQrlDumNjs=cicZNGijwHyNUpQUUWrF(gui,X,Y,100,25)
xCheckboxNotifyBuyF10=MTbiymEMtofPpUnLhCKE(gui,'xCallBackNotifyBuyF10',_AN,X,Y)
kwwOSWNYIgaiXsWEWpMb=sNOKqVOQPcbIohrgrUAk(gui,'Cycle(minutes):',X,Y)
urItYGeSPfpVoTNCDHaj=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,40,25)
VlIjBmBwakfdrxElwVbg=omskgOqYICjokgtwBAis(gui,'johCXNVVkIMAzQsahTlo',_Z,X,Y)
def dFhCUuUfSXVyjtidmZiy():
	global OlFpZxSIOWOxoYIYEJhM
	if not OlFpZxSIOWOxoYIYEJhM.get(_I):OlFpZxSIOWOxoYIYEJhM[_I]={_J:{},_AO:{},_W:{},_X:{_Au:BXxnPGdFgiHeQuztmsNz,_Av:BXxnPGdFgiHeQuztmsNz,_AY:BXxnPGdFgiHeQuztmsNz,'dcn':_AZ},_As:30,_At:FudbnvReIPieRucoAuaD};YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
	return OlFpZxSIOWOxoYIYEJhM[_I]
def aBzHrPzOqZVJzhtYkYXg(_dic):
	RcgxmwdulXbFqNCcXalf(gui,FHiihcDteaNbnvlnioXs);name=KRsJzeKTYFIlLTuRSRiR()[_B];_active=BXxnPGdFgiHeQuztmsNz
	for char in _dic.keys():
		if char==name:_active=FudbnvReIPieRucoAuaD
		qqiewGGMbbypNfVFpsFt(gui,FHiihcDteaNbnvlnioXs,char)
	if _active:uTjWQRuHkfUwHqUKBXer(gui,FHiihcDteaNbnvlnioXs,name)
def taracIImTdaeahuJljox():
	data=dFhCUuUfSXVyjtidmZiy()
	if data[_J]:aBzHrPzOqZVJzhtYkYXg(data[_J])
	RcgxmwdulXbFqNCcXalf(gui,wcPxcWRXcigrQwkplDDo);RcgxmwdulXbFqNCcXalf(gui,GppLLXrLmQhCuXhdxShl);FKErQpKRMOMgGqMZMIwo(gui,yDskoFdWOJAXmnPHYebJ,data[_X][_AY]);FKErQpKRMOMgGqMZMIwo(gui,EycwjCvtwipdkyIpBgHf,data[_X][_Au]);FKErQpKRMOMgGqMZMIwo(gui,fMHConstndliwMODiJyw,data[_X][_Av]);FKErQpKRMOMgGqMZMIwo(gui,xCheckboxNotifyBuyF10,data.get(_At,BXxnPGdFgiHeQuztmsNz));qqiewGGMbbypNfVFpsFt(gui,wcPxcWRXcigrQwkplDDo,'');_samples=data[_AO].keys()
	for i in _samples:qqiewGGMbbypNfVFpsFt(gui,wcPxcWRXcigrQwkplDDo,i)
	if data[_W]:
		for(_name,_val)in data[_W].items():_value=_name+str(_val);qqiewGGMbbypNfVFpsFt(gui,GppLLXrLmQhCuXhdxShl,_value)
	uTjWQRuHkfUwHqUKBXer(gui,IyNDuGraslfIZDgwBrkM,'1');uTjWQRuHkfUwHqUKBXer(gui,IMmIthmLIYmpcjvWkdEB,'5');uTjWQRuHkfUwHqUKBXer(gui,urItYGeSPfpVoTNCDHaj,str(data[_As]));_locale=[_AZ,_AT,_h,'member',_AS];RcgxmwdulXbFqNCcXalf(gui,rnzCACbSNTyQrlDumNjs)
	for i in _locale:qqiewGGMbbypNfVFpsFt(gui,rnzCACbSNTyQrlDumNjs,i)
	dcn=data[_X].get('dcn',_AZ);uTjWQRuHkfUwHqUKBXer(gui,rnzCACbSNTyQrlDumNjs,dcn);tGbRwQhbAErYotZZkeSf(gui,rnzCACbSNTyQrlDumNjs,not data[_X][_AY])
	if not JzLZxXwzKEnKOuUNolBu:return
	uTjWQRuHkfUwHqUKBXer(gui,viEDPlfMTniBwXCFMjKb,JzLZxXwzKEnKOuUNolBu[_B])
def EwZOHIaxExXUtHICVxKy():
	global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();_name=PRptGTFSeNBhCFUPbbfz(gui,viEDPlfMTniBwXCFMjKb);_l=list(OlFpZxSIOWOxoYIYEJhM[_I][_J].keys());check=_name and CXmyKqeqvrjquzBvrliF(_name,_l)and sXkMGiiYfTCJYksKpBKb(_name)
	if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_I][_J][_name]=BXxnPGdFgiHeQuztmsNz;qqiewGGMbbypNfVFpsFt(gui,FHiihcDteaNbnvlnioXs,_name);uTjWQRuHkfUwHqUKBXer(gui,FHiihcDteaNbnvlnioXs,_name);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));FBDleWFBsQRLSQFIiGAE();qjbXQXJWLiCUIxWLiVfZ();OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
def kWxCKMlYfZiZCuwMZdxW():
	global OlFpZxSIOWOxoYIYEJhM;_name=PRptGTFSeNBhCFUPbbfz(gui,FHiihcDteaNbnvlnioXs)
	if not _name:return
	lywbvBarobpigBBffFVQ(gui,FHiihcDteaNbnvlnioXs,_name);del OlFpZxSIOWOxoYIYEJhM[_I][_J][_name];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));FBDleWFBsQRLSQFIiGAE();qjbXQXJWLiCUIxWLiVfZ()
def EhTFRVeSuAdOIvoITMqu():
	TR098hhadfveaaaaNm2Jwywg();data=OlFpZxSIOWOxoYIYEJhM[_I][_J].items()
	if data:
		msg='';count=1
		for(name,state)in data:_state='Starting...'if state else'Stopped';_msg='Char %s [%s]: %s\n'%(count,name,_state);msg+=_msg;count+=1
		dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Info Start-Stop buy in F10:\n%s'%(hhtizdLRxJDclVvtcTSo,msg))
def BksJLkaiHASjaPlWpwMp():
	global OlFpZxSIOWOxoYIYEJhM;_item=PRptGTFSeNBhCFUPbbfz(gui,wcPxcWRXcigrQwkplDDo);_amount=PRptGTFSeNBhCFUPbbfz(gui,IyNDuGraslfIZDgwBrkM);_when=PRptGTFSeNBhCFUPbbfz(gui,IMmIthmLIYmpcjvWkdEB)
	if not _item or _item.find('EXTENSION')!=-1 or _item.find('GOLDTIME')!=-1:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,_item));return
	if _amount.isdigit()and _when.isdigit():
		OlFpZxSIOWOxoYIYEJhM[_I][_W][_item]=[int(_amount),int(_when)];_name=_item+str([int(_amount),int(_when)]);RcgxmwdulXbFqNCcXalf(gui,GppLLXrLmQhCuXhdxShl);data=OlFpZxSIOWOxoYIYEJhM[_I][_W]
		for(_name,_val)in data.items():_value=_name+str(_val);qqiewGGMbbypNfVFpsFt(gui,GppLLXrLmQhCuXhdxShl,_value)
		uTjWQRuHkfUwHqUKBXer(gui,wcPxcWRXcigrQwkplDDo,'');uTjWQRuHkfUwHqUKBXer(gui,GppLLXrLmQhCuXhdxShl,_name);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
	else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,'Item, Qty or when'))
def rtQnWHYhDbUKgRdZyvqp():
	global OlFpZxSIOWOxoYIYEJhM;_item=PRptGTFSeNBhCFUPbbfz(gui,GppLLXrLmQhCuXhdxShl)
	if _item:_idx=_item.find('[',len(_item)-13);lywbvBarobpigBBffFVQ(gui,GppLLXrLmQhCuXhdxShl,_item);_val=_item[:_idx];del OlFpZxSIOWOxoYIYEJhM[_I][_W][_val];YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def IBhCaNwAXCgkAYUthYHX(_state):
	global OlFpZxSIOWOxoYIYEJhM
	if _state:
		sv=KRsJzeKTYFIlLTuRSRiR()[_d];name='(%s)ITEM_COS_P_EXTENSION'%sv;check=OlFpZxSIOWOxoYIYEJhM[_I][_AO].get(name)
		if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(67,hhtizdLRxJDclVvtcTSo));FKErQpKRMOMgGqMZMIwo(gui,EycwjCvtwipdkyIpBgHf,BXxnPGdFgiHeQuztmsNz);return
		dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(70,hhtizdLRxJDclVvtcTSo,name))
	OlFpZxSIOWOxoYIYEJhM[_I][_X][_Au]=_state;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def KaxXcmbnnsHPDsDUUiip(_state):
	global OlFpZxSIOWOxoYIYEJhM
	if _state:
		name='GOLDTIME';check=BXxnPGdFgiHeQuztmsNz;_data=OlFpZxSIOWOxoYIYEJhM[_I][_AO];sv=KRsJzeKTYFIlLTuRSRiR()[_d]
		for key in _data.keys():
			if key.find(name)!=-1 and key.find(sv)!=-1:check=FudbnvReIPieRucoAuaD;break
		if not check:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(67,hhtizdLRxJDclVvtcTSo));FKErQpKRMOMgGqMZMIwo(gui,fMHConstndliwMODiJyw,BXxnPGdFgiHeQuztmsNz);return
		dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(70,hhtizdLRxJDclVvtcTSo,name))
	OlFpZxSIOWOxoYIYEJhM[_I][_X][_Av]=_state;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def xCallBackNotifyBuyF10(_state):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_I][_At]=_state;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def xPIIbPqiWEuCgSRIHsiH(_state):
	global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_I][_X][_AY]=_state
	if _state:tGbRwQhbAErYotZZkeSf(gui,rnzCACbSNTyQrlDumNjs,BXxnPGdFgiHeQuztmsNz)
	else:tGbRwQhbAErYotZZkeSf(gui,rnzCACbSNTyQrlDumNjs,FudbnvReIPieRucoAuaD)
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def FBDleWFBsQRLSQFIiGAE():
	if xBuyF10Var and not HkbgUnqkPodJtewqRPnE:
		char=KRsJzeKTYFIlLTuRSRiR();names=eVgCyKIrycDTuQqfdcWP(gui,FHiihcDteaNbnvlnioXs);_state=OlFpZxSIOWOxoYIYEJhM[_I][_J].get(char[_B])
		if not char or char[_B]not in names:WvZHbCVTxTJBCgjShmye(gui,ZchCyBnnGCkhwEDbMBWi,600,75);WvZHbCVTxTJBCgjShmye(gui,gGQWDPsKtZMXFnbMusDg,X,Y);tGbRwQhbAErYotZZkeSf(gui,ZchCyBnnGCkhwEDbMBWi,BXxnPGdFgiHeQuztmsNz);return
		if _state:WvZHbCVTxTJBCgjShmye(gui,ZchCyBnnGCkhwEDbMBWi,X,Y);WvZHbCVTxTJBCgjShmye(gui,gGQWDPsKtZMXFnbMusDg,600,75)
		else:WvZHbCVTxTJBCgjShmye(gui,ZchCyBnnGCkhwEDbMBWi,600,75);WvZHbCVTxTJBCgjShmye(gui,gGQWDPsKtZMXFnbMusDg,X,Y);tGbRwQhbAErYotZZkeSf(gui,ZchCyBnnGCkhwEDbMBWi,FudbnvReIPieRucoAuaD)
	else:WvZHbCVTxTJBCgjShmye(gui,ZchCyBnnGCkhwEDbMBWi,X,Y);WvZHbCVTxTJBCgjShmye(gui,gGQWDPsKtZMXFnbMusDg,X,Y)
def qjbXQXJWLiCUIxWLiVfZ():
	if xBuyF10Var and not HkbgUnqkPodJtewqRPnE:
		char=KRsJzeKTYFIlLTuRSRiR();names=eVgCyKIrycDTuQqfdcWP(gui,FHiihcDteaNbnvlnioXs);_state=OlFpZxSIOWOxoYIYEJhM[_I][_J].get(char[_B])
		if not char or char[_B]not in names:WvZHbCVTxTJBCgjShmye(gui,cYtPjLEsLVVEkREiYVCd,290,115);WvZHbCVTxTJBCgjShmye(gui,FYSUaVzvPDqlxfnMxZYf,X,Y);tGbRwQhbAErYotZZkeSf(gui,cYtPjLEsLVVEkREiYVCd,BXxnPGdFgiHeQuztmsNz);return
		if char[_B]in names:
			if aehcJhshMnfDvGMfmteP():WvZHbCVTxTJBCgjShmye(gui,cYtPjLEsLVVEkREiYVCd,X,Y);WvZHbCVTxTJBCgjShmye(gui,FYSUaVzvPDqlxfnMxZYf,290,115)
			else:WvZHbCVTxTJBCgjShmye(gui,cYtPjLEsLVVEkREiYVCd,290,115);WvZHbCVTxTJBCgjShmye(gui,FYSUaVzvPDqlxfnMxZYf,X,Y);tGbRwQhbAErYotZZkeSf(gui,cYtPjLEsLVVEkREiYVCd,FudbnvReIPieRucoAuaD)
	else:WvZHbCVTxTJBCgjShmye(gui,cYtPjLEsLVVEkREiYVCd,X,Y);WvZHbCVTxTJBCgjShmye(gui,FYSUaVzvPDqlxfnMxZYf,X,Y)
def tsJFmMtepaSNIjazWBvN():
	global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();char=KRsJzeKTYFIlLTuRSRiR()[_B]
	if not char:return
	_state=OlFpZxSIOWOxoYIYEJhM[_I][_J]
	if not _state:return
	_state=_state.get(char)
	if not _state:OlFpZxSIOWOxoYIYEJhM[_I][_J][char]=FudbnvReIPieRucoAuaD;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);FBDleWFBsQRLSQFIiGAE();OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD);Timer(3.2,ChSlozxVuBDjPTUsewsE,(FudbnvReIPieRucoAuaD,)).start()
def RxjUpBxsOmfwyAKDvuVM():
	global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();char=KRsJzeKTYFIlLTuRSRiR()[_B]
	if not char:return
	_state=OlFpZxSIOWOxoYIYEJhM[_I][_J][char]
	if _state:OlFpZxSIOWOxoYIYEJhM[_I][_J][char]=BXxnPGdFgiHeQuztmsNz;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);FBDleWFBsQRLSQFIiGAE();ChSlozxVuBDjPTUsewsE(BXxnPGdFgiHeQuztmsNz);SKDJmjNuOZOvNhbWZwPV();PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD);OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
def KFzjcANBvxXjCiXSmUnK():
	if not aehcJhshMnfDvGMfmteP():IVKGBdFSdPIKJPGXWNBM();qjbXQXJWLiCUIxWLiVfZ();Timer(300,VVWPcEprpxanjprMYFSk).start();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(68,hhtizdLRxJDclVvtcTSo))
def VVWPcEprpxanjprMYFSk():
	global OlFpZxSIOWOxoYIYEJhM
	if aehcJhshMnfDvGMfmteP():IVKGBdFSdPIKJPGXWNBM();qjbXQXJWLiCUIxWLiVfZ();tEENeBQViuZpuApWOvHq(gui,wcPxcWRXcigrQwkplDDo);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(69,hhtizdLRxJDclVvtcTSo));OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg()
def LpgixOKnIYNLWySbEtwf():
	global OlFpZxSIOWOxoYIYEJhM;_item=PRptGTFSeNBhCFUPbbfz(gui,wcPxcWRXcigrQwkplDDo)
	if _item:
		lywbvBarobpigBBffFVQ(gui,wcPxcWRXcigrQwkplDDo,_item);_idx=_item.find('[',len(_item)-15);_name=_item[:_idx];del OlFpZxSIOWOxoYIYEJhM[_I][_AO][_item]
		if OlFpZxSIOWOxoYIYEJhM[_I][_W].get(_item):del OlFpZxSIOWOxoYIYEJhM[_I][_W][_item];lywbvBarobpigBBffFVQ(gui,GppLLXrLmQhCuXhdxShl,_name)
		YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def johCXNVVkIMAzQsahTlo():
	global OlFpZxSIOWOxoYIYEJhM;_min=PRptGTFSeNBhCFUPbbfz(gui,urItYGeSPfpVoTNCDHaj)
	if not _min or not _min.isdigit():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,_min));return
	if int(_min)<5:_min='5';uTjWQRuHkfUwHqUKBXer(gui,urItYGeSPfpVoTNCDHaj,_min)
	OlFpZxSIOWOxoYIYEJhM[_I][_As]=int(_min);relog=LBRexqqDJqawZRqWrNZr(gui,yDskoFdWOJAXmnPHYebJ)
	if not relog:
		dcn=PRptGTFSeNBhCFUPbbfz(gui,rnzCACbSNTyQrlDumNjs)
		if dcn==_AZ:dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Bạn cần chọn dịch chuyển ngược hoặc khởi động lại(Relogin) sau mỗi lần mua hàng'%hhtizdLRxJDclVvtcTSo);return
		OlFpZxSIOWOxoYIYEJhM[_I][_X]['dcn']=dcn
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
mdsgHxsyJwTLdoCHjkWv=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
fNLHihvlAplBnwwOHmoz=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
cMPwjyyceVvOeQWouWiB=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
ZIYBPYIItTunbqtCYDnq=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
fhHQRTwCbVXrrFAcCbZf=omskgOqYICjokgtwBAis(gui,'KaNqQzISyzMZGBrRQvkm',_A0,X,Y)
fZBJVJiqvCqbXuVZibUf=omskgOqYICjokgtwBAis(gui,'wlIUbdfrAZkelAlaoxau',_AM,X,Y)
vVOmlHBnHgIEEnnMSTpW=omskgOqYICjokgtwBAis(gui,'HsgWhiAZtYrqvilOrdDm',_Z,X,Y)
WPLyUxShHPzjBnSjRCMy=omskgOqYICjokgtwBAis(gui,'QAEpCZrwftRICwPjjylP',_l,X,Y)
lPKWOaDounzzeCOoUSeT=omskgOqYICjokgtwBAis(gui,'cypTTKWKBbjEWbOtQYDf',_m,X,Y)
kvMLyjpwNwwVYhGnhbPA=omskgOqYICjokgtwBAis(gui,'UfsxdYrVdcackPqmcSri','Get Time',X,Y)
hJpEgClDKDETvAUnmyFO=omskgOqYICjokgtwBAis(gui,'BMsKLwbgokpdLqMnxuJo','Get Name',X,Y)
iDNuQiNLLLOqFMZapGbX=omskgOqYICjokgtwBAis(gui,'nwtXGfsXwfSgehIdepNM','Get Locale',X,Y)
NjScQGYFQdmCBfrmqFrj=omskgOqYICjokgtwBAis(gui,'gMELfRFXLqMAHJPKxJkp','Get Position',X,Y)
ASnAnxPnMrQUnvtyvYKx=sNOKqVOQPcbIohrgrUAk(gui,'Notify:',X,Y)
CsTRNSOxlvtrmckEPgku=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,300,25)
GnWLIVLWjuwTjGtPfHZs=sNOKqVOQPcbIohrgrUAk(gui,'Re Notify:',X,Y)
YxFEuqJbFwfqRYIFhrKf=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,300,25)
EYgGvZkhcMWuLUMJxCPB=sNOKqVOQPcbIohrgrUAk(gui,'Wait(min)',X,Y)
HuxeWIxgVHmWsQoBnHOu=cicZNGijwHyNUpQUUWrF(gui,X,Y,40,25)
zpwXpQKESTkDSgdYMcen=sNOKqVOQPcbIohrgrUAk(gui,'Downtime(sec)',X,Y)
LXggMOolzfvNCUdIRpqU=cicZNGijwHyNUpQUUWrF(gui,X,Y,40,25)
yXROEoEJmtzPkkWRMjFn=MTbiymEMtofPpUnLhCKE(gui,'yxujLvipDGlnXlgBoCTf','To Guild',X,Y)
IEpTwPEeEpMlTsHQtLnN=MTbiymEMtofPpUnLhCKE(gui,'QavWHUnSBOjhNhQKYtoK','To Party',X,Y)
gZOUENEWnWlAsEggSegL=MTbiymEMtofPpUnLhCKE(gui,'tqcOjUElqKcPHZxAoSgn','To Union',X,Y)
FNcREDWMkZbogKNIuAzH=MTbiymEMtofPpUnLhCKE(gui,'GYmmIEuczlVYKNjlWDIn','To me',X,Y)
auWcFxDyTcDFRmgEKYhu=MTbiymEMtofPpUnLhCKE(gui,'ohWfsahNGHuZRWkLturT','From Team',X,Y)
QxbpEBsnZBkuswEreNUC=MTbiymEMtofPpUnLhCKE(gui,'tvcgLAbFLxvnTqLNrQKa','Scan Thieves',X,Y)
QxzzqltCRtScUlSNGaWu=MTbiymEMtofPpUnLhCKE(gui,'XKszaWAVgUTVOPzLlvzh','Scan Traders/Hunters',X,Y)
bZmQEwKBHkmcjQvgCvTK=omskgOqYICjokgtwBAis(gui,'hzJDIXsSQEKxdOHmoWep','Get Zone name',X,Y)
uxbdJptkHWIRYkXnCKAE=omskgOqYICjokgtwBAis(gui,'ninvDxPNgCgDVUegvWdN','Convert',X,Y)
unZSYijyPrioZySDRIUJ=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,300,25)
vZaKeuAaoZkxGwYPNjbi=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,300,25)
VTAniopTrhokxYsdzzVm=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
ZgrdPAuIvoXZymkPTeeh=omskgOqYICjokgtwBAis(gui,'zdFAErUgzMhAXKyNGhkL','Add Silent Zone',X,Y)
iXnhErQKYveDaeclJTTl=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
KMNaIYZOJNlcHvyOBzvI=omskgOqYICjokgtwBAis(gui,'UawudtfztNDZkGoGVDns','Del Silent Zone',X,Y)
mVQHsfGAIdVyaJwqreGd=omskgOqYICjokgtwBAis(gui,'WkQOPkItoOfjHEtXyVCb','Page 1',X,Y)
IFDGuAibxcGgrLKflhFP=omskgOqYICjokgtwBAis(gui,'KTaRHWfbMgXpRpukjqLC','Page 2',X,Y)
lSOzBWFIhezsjWESJFhL=sNOKqVOQPcbIohrgrUAk(gui,'Original name:',X,Y)
wRytSMnbdEMnVgudFfJZ=sNOKqVOQPcbIohrgrUAk(gui,'Destination name:',X,Y)
OPVthwlxiQbZvBLHITrd=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
NZdnYAvFwnjxopIHqHCH=omskgOqYICjokgtwBAis(gui,'xAddSilentPlayersJobRada','Add Silent Player',X,Y)
brttDknPElnjSHSfhnme=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
PnhGToxqgfwVkqtzghab=omskgOqYICjokgtwBAis(gui,'xDelSilentPlayersJobRada','Del Silent Player',X,Y)
def lvHIFjZbHFLrkqbsbFsH():
	global OlFpZxSIOWOxoYIYEJhM
	if not OlFpZxSIOWOxoYIYEJhM.get(_G):OlFpZxSIOWOxoYIYEJhM[_G]={_J:{},_H:{_AN:'{t}: AE chu y, da phat hien ten {n} tai {l}, toa do ({p}).',_AP:'AE dang ngu het roi a?, toi thong bao thay {n} tai {l} da duoc {t} phut roi ma sao ae chua ai len vay?',_AQ:5,_Aa:30,_A1:FudbnvReIPieRucoAuaD,_Ab:BXxnPGdFgiHeQuztmsNz,_Ac:BXxnPGdFgiHeQuztmsNz,_Ad:BXxnPGdFgiHeQuztmsNz,_Ae:FudbnvReIPieRucoAuaD},_r:[],_s:[]};YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
	return OlFpZxSIOWOxoYIYEJhM[_G]
def HjDrZmbhwRcwJJYrroYE():
	char=KRsJzeKTYFIlLTuRSRiR();Rada=lvHIFjZbHFLrkqbsbFsH();uTjWQRuHkfUwHqUKBXer(gui,fNLHihvlAplBnwwOHmoz,char[_B])
	if Rada[_J]:
		RcgxmwdulXbFqNCcXalf(gui,ZIYBPYIItTunbqtCYDnq)
		for i in Rada[_J]:qqiewGGMbbypNfVFpsFt(gui,ZIYBPYIItTunbqtCYDnq,i)
	uTjWQRuHkfUwHqUKBXer(gui,CsTRNSOxlvtrmckEPgku,Rada[_H][_AN]);uTjWQRuHkfUwHqUKBXer(gui,YxFEuqJbFwfqRYIFhrKf,Rada[_H][_AP]);RcgxmwdulXbFqNCcXalf(gui,HuxeWIxgVHmWsQoBnHOu)
	for i in['1','3','5','7','9']:qqiewGGMbbypNfVFpsFt(gui,HuxeWIxgVHmWsQoBnHOu,i)
	uTjWQRuHkfUwHqUKBXer(gui,HuxeWIxgVHmWsQoBnHOu,str(Rada[_H][_AQ]));RcgxmwdulXbFqNCcXalf(gui,LXggMOolzfvNCUdIRpqU)
	for i in['0','30','60','300','900']:qqiewGGMbbypNfVFpsFt(gui,LXggMOolzfvNCUdIRpqU,i)
	uTjWQRuHkfUwHqUKBXer(gui,LXggMOolzfvNCUdIRpqU,str(Rada[_H].get(_Aa,30)));FKErQpKRMOMgGqMZMIwo(gui,yXROEoEJmtzPkkWRMjFn,Rada[_H][_Ab]);FKErQpKRMOMgGqMZMIwo(gui,IEpTwPEeEpMlTsHQtLnN,Rada[_H][_Ac]);FKErQpKRMOMgGqMZMIwo(gui,gZOUENEWnWlAsEggSegL,Rada[_H][_Ad]);FKErQpKRMOMgGqMZMIwo(gui,FNcREDWMkZbogKNIuAzH,Rada[_H][_Ae]);FKErQpKRMOMgGqMZMIwo(gui,auWcFxDyTcDFRmgEKYhu,xiUkafLFtMKWxbjlEHzK());FKErQpKRMOMgGqMZMIwo(gui,QxbpEBsnZBkuswEreNUC,not Rada[_H][_A1]);FKErQpKRMOMgGqMZMIwo(gui,QxzzqltCRtScUlSNGaWu,Rada[_H][_A1])
	if char[_B]:zone_id=char[_AU];zone_name=MbSEKuSVcVLElKscCaEe(zone_id);uTjWQRuHkfUwHqUKBXer(gui,unZSYijyPrioZySDRIUJ,zone_name);uTjWQRuHkfUwHqUKBXer(gui,VTAniopTrhokxYsdzzVm,zone_name)
	RcgxmwdulXbFqNCcXalf(gui,iXnhErQKYveDaeclJTTl)
	for i in Rada[_r]:qqiewGGMbbypNfVFpsFt(gui,iXnhErQKYveDaeclJTTl,i)
	RcgxmwdulXbFqNCcXalf(gui,brttDknPElnjSHSfhnme)
	for i in Rada.get(_s,[]):qqiewGGMbbypNfVFpsFt(gui,brttDknPElnjSHSfhnme,i)
	NdHzqvtFmuJWCvLkOTDw()
def KaNqQzISyzMZGBrRQvkm():
	global OlFpZxSIOWOxoYIYEJhM;_name=PRptGTFSeNBhCFUPbbfz(gui,fNLHihvlAplBnwwOHmoz);_l=list(OlFpZxSIOWOxoYIYEJhM[_G][_J].keys());check=_name and CXmyKqeqvrjquzBvrliF(_name,_l)and sXkMGiiYfTCJYksKpBKb(_name)
	if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_G][_J][_name]=BXxnPGdFgiHeQuztmsNz;qqiewGGMbbypNfVFpsFt(gui,ZIYBPYIItTunbqtCYDnq,_name);uTjWQRuHkfUwHqUKBXer(gui,ZIYBPYIItTunbqtCYDnq,_name);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);NdHzqvtFmuJWCvLkOTDw()
def NdHzqvtFmuJWCvLkOTDw():
	if ATQXujoMxxZtrVjfMcKz and not HkbgUnqkPodJtewqRPnE:
		_starting=BXxnPGdFgiHeQuztmsNz
		for state in OlFpZxSIOWOxoYIYEJhM[_G][_J].values():
			if state:_starting=FudbnvReIPieRucoAuaD;break
		if not _starting:WvZHbCVTxTJBCgjShmye(gui,WPLyUxShHPzjBnSjRCMy,600,75);WvZHbCVTxTJBCgjShmye(gui,lPKWOaDounzzeCOoUSeT,X,Y)
		else:WvZHbCVTxTJBCgjShmye(gui,lPKWOaDounzzeCOoUSeT,600,75);WvZHbCVTxTJBCgjShmye(gui,WPLyUxShHPzjBnSjRCMy,X,Y)
	else:WvZHbCVTxTJBCgjShmye(gui,WPLyUxShHPzjBnSjRCMy,X,Y);WvZHbCVTxTJBCgjShmye(gui,lPKWOaDounzzeCOoUSeT,X,Y)
def wlIUbdfrAZkelAlaoxau():
	global OlFpZxSIOWOxoYIYEJhM;_name=PRptGTFSeNBhCFUPbbfz(gui,ZIYBPYIItTunbqtCYDnq)
	if not _name:return
	lywbvBarobpigBBffFVQ(gui,ZIYBPYIItTunbqtCYDnq,_name);del OlFpZxSIOWOxoYIYEJhM[_G][_J][_name]
def HsgWhiAZtYrqvilOrdDm():global OlFpZxSIOWOxoYIYEJhM;_main=PRptGTFSeNBhCFUPbbfz(gui,CsTRNSOxlvtrmckEPgku);_sub=PRptGTFSeNBhCFUPbbfz(gui,YxFEuqJbFwfqRYIFhrKf);_wait=PRptGTFSeNBhCFUPbbfz(gui,HuxeWIxgVHmWsQoBnHOu);_downtime=PRptGTFSeNBhCFUPbbfz(gui,LXggMOolzfvNCUdIRpqU);OlFpZxSIOWOxoYIYEJhM[_G][_H][_AN]=_main;OlFpZxSIOWOxoYIYEJhM[_G][_H][_AP]=_sub;OlFpZxSIOWOxoYIYEJhM[_G][_H][_AQ]=int(_wait);OlFpZxSIOWOxoYIYEJhM[_G][_H][_Aa]=int(_downtime);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def QAEpCZrwftRICwPjjylP():
	global OlFpZxSIOWOxoYIYEJhM
	for char in OlFpZxSIOWOxoYIYEJhM[_G][_J].keys():OlFpZxSIOWOxoYIYEJhM[_G][_J][char]=FudbnvReIPieRucoAuaD
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);NdHzqvtFmuJWCvLkOTDw()
def cypTTKWKBbjEWbOtQYDf():
	global OlFpZxSIOWOxoYIYEJhM
	for char in OlFpZxSIOWOxoYIYEJhM[_G][_J].keys():OlFpZxSIOWOxoYIYEJhM[_G][_J][char]=BXxnPGdFgiHeQuztmsNz
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);NdHzqvtFmuJWCvLkOTDw()
def UfsxdYrVdcackPqmcSri():dRBzRDsZDulhsFtoVKPh('{t}')
def BMsKLwbgokpdLqMnxuJo():dRBzRDsZDulhsFtoVKPh('{n}')
def nwtXGfsXwfSgehIdepNM():dRBzRDsZDulhsFtoVKPh('{l}')
def gMELfRFXLqMAHJPKxJkp():dRBzRDsZDulhsFtoVKPh('{p}')
def tvcgLAbFLxvnTqLNrQKa(e):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_G][_H][_A1]=not e;FKErQpKRMOMgGqMZMIwo(gui,QxzzqltCRtScUlSNGaWu,not e)
def XKszaWAVgUTVOPzLlvzh(e):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_G][_H][_A1]=e;FKErQpKRMOMgGqMZMIwo(gui,QxbpEBsnZBkuswEreNUC,not e)
def hzJDIXsSQEKxdOHmoWep():
	char=KRsJzeKTYFIlLTuRSRiR()
	if char[_B]:zone_id=char[_AU];zone_name=MbSEKuSVcVLElKscCaEe(zone_id);dRBzRDsZDulhsFtoVKPh(zone_name)
def ninvDxPNgCgDVUegvWdN():
	ori=PRptGTFSeNBhCFUPbbfz(gui,unZSYijyPrioZySDRIUJ);des=PRptGTFSeNBhCFUPbbfz(gui,vZaKeuAaoZkxGwYPNjbi)
	if not ori or not des:return
	AFPhQlxrzWNBUZTIKhln=COBGimFIVLjWnnJrrBsJ();AFPhQlxrzWNBUZTIKhln[ori]=des;aediaembTTGMGqcgAdqf(AFPhQlxrzWNBUZTIKhln);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(33,hhtizdLRxJDclVvtcTSo,'Zone names'))
def yxujLvipDGlnXlgBoCTf(e):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_G][_H][_Ab]=e
def QavWHUnSBOjhNhQKYtoK(e):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_G][_H][_Ac]=e
def tqcOjUElqKcPHZxAoSgn(e):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_G][_H][_Ad]=e
def GYmmIEuczlVYKNjlWDIn(e):global OlFpZxSIOWOxoYIYEJhM;OlFpZxSIOWOxoYIYEJhM[_G][_H][_Ae]=e
def ohWfsahNGHuZRWkLturT(e):EEeVRcTbmvaZSUvERzKI(e)
def WkQOPkItoOfjHEtXyVCb():qAilHclPdWbfDRQWfSpd();XOujawntPsoIbuXqxpGK()
def zdFAErUgzMhAXKyNGhkL():
	global OlFpZxSIOWOxoYIYEJhM;sil=PRptGTFSeNBhCFUPbbfz(gui,VTAniopTrhokxYsdzzVm)
	if sil and sil not in OlFpZxSIOWOxoYIYEJhM[_G][_r]:qqiewGGMbbypNfVFpsFt(gui,iXnhErQKYveDaeclJTTl,sil);OlFpZxSIOWOxoYIYEJhM[_G][_r].append(sil);uTjWQRuHkfUwHqUKBXer(gui,iXnhErQKYveDaeclJTTl,sil);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
def xAddSilentPlayersJobRada():
	global OlFpZxSIOWOxoYIYEJhM;sil=PRptGTFSeNBhCFUPbbfz(gui,OPVthwlxiQbZvBLHITrd)
	if sil and sil not in OlFpZxSIOWOxoYIYEJhM[_G].get(_s,[]):qqiewGGMbbypNfVFpsFt(gui,brttDknPElnjSHSfhnme,sil);OlFpZxSIOWOxoYIYEJhM[_G].get(_s,[]).append(sil);uTjWQRuHkfUwHqUKBXer(gui,brttDknPElnjSHSfhnme,sil);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
def UawudtfztNDZkGoGVDns():
	global OlFpZxSIOWOxoYIYEJhM;sil=PRptGTFSeNBhCFUPbbfz(gui,iXnhErQKYveDaeclJTTl)
	if sil and sil in OlFpZxSIOWOxoYIYEJhM[_G][_r]:lywbvBarobpigBBffFVQ(gui,iXnhErQKYveDaeclJTTl,sil);OlFpZxSIOWOxoYIYEJhM[_G][_r].remove(sil);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
def xDelSilentPlayersJobRada():
	global OlFpZxSIOWOxoYIYEJhM;sil=PRptGTFSeNBhCFUPbbfz(gui,brttDknPElnjSHSfhnme)
	if sil and sil in OlFpZxSIOWOxoYIYEJhM[_G].get(_s,[]):lywbvBarobpigBBffFVQ(gui,brttDknPElnjSHSfhnme,sil);OlFpZxSIOWOxoYIYEJhM[_G][_s].remove(sil);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
def KTaRHWfbMgXpRpukjqLC():LGOBobjyifkoieVgkczS();saxAmHOhESanfGQoqkbg()
def XOujawntPsoIbuXqxpGK():WvZHbCVTxTJBCgjShmye(gui,kvMLyjpwNwwVYhGnhbPA,210,115);WvZHbCVTxTJBCgjShmye(gui,hJpEgClDKDETvAUnmyFO,330,115);WvZHbCVTxTJBCgjShmye(gui,iDNuQiNLLLOqFMZapGbX,460,115);WvZHbCVTxTJBCgjShmye(gui,NjScQGYFQdmCBfrmqFrj,590,115);WvZHbCVTxTJBCgjShmye(gui,ASnAnxPnMrQUnvtyvYKx,210,153);WvZHbCVTxTJBCgjShmye(gui,CsTRNSOxlvtrmckEPgku,270,150);WvZHbCVTxTJBCgjShmye(gui,GnWLIVLWjuwTjGtPfHZs,210,183);WvZHbCVTxTJBCgjShmye(gui,YxFEuqJbFwfqRYIFhrKf,270,180);WvZHbCVTxTJBCgjShmye(gui,EYgGvZkhcMWuLUMJxCPB,580,183);WvZHbCVTxTJBCgjShmye(gui,HuxeWIxgVHmWsQoBnHOu,650,180);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,200);WvZHbCVTxTJBCgjShmye(gui,QxzzqltCRtScUlSNGaWu,210,220);WvZHbCVTxTJBCgjShmye(gui,QxbpEBsnZBkuswEreNUC,400,220);WvZHbCVTxTJBCgjShmye(gui,zpwXpQKESTkDSgdYMcen,550,223);WvZHbCVTxTJBCgjShmye(gui,LXggMOolzfvNCUdIRpqU,650,220);WvZHbCVTxTJBCgjShmye(gui,ZGAdNwFfCWRTWAlpuWBs,201,240);WvZHbCVTxTJBCgjShmye(gui,yXROEoEJmtzPkkWRMjFn,210,260);WvZHbCVTxTJBCgjShmye(gui,IEpTwPEeEpMlTsHQtLnN,290,260);WvZHbCVTxTJBCgjShmye(gui,gZOUENEWnWlAsEggSegL,370,260);WvZHbCVTxTJBCgjShmye(gui,FNcREDWMkZbogKNIuAzH,450,260);WvZHbCVTxTJBCgjShmye(gui,auWcFxDyTcDFRmgEKYhu,530,260);WvZHbCVTxTJBCgjShmye(gui,IFDGuAibxcGgrLKflhFP,615,260)
def LGOBobjyifkoieVgkczS():
	for widget in(kvMLyjpwNwwVYhGnhbPA,hJpEgClDKDETvAUnmyFO,iDNuQiNLLLOqFMZapGbX,NjScQGYFQdmCBfrmqFrj,ASnAnxPnMrQUnvtyvYKx,CsTRNSOxlvtrmckEPgku,GnWLIVLWjuwTjGtPfHZs,YxFEuqJbFwfqRYIFhrKf,EYgGvZkhcMWuLUMJxCPB,HuxeWIxgVHmWsQoBnHOu,QxbpEBsnZBkuswEreNUC,QxzzqltCRtScUlSNGaWu,VdunfnMGuQDmiYrhJqnj,yXROEoEJmtzPkkWRMjFn,IEpTwPEeEpMlTsHQtLnN,gZOUENEWnWlAsEggSegL,FNcREDWMkZbogKNIuAzH,IFDGuAibxcGgrLKflhFP,zpwXpQKESTkDSgdYMcen,LXggMOolzfvNCUdIRpqU,auWcFxDyTcDFRmgEKYhu):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def saxAmHOhESanfGQoqkbg():WvZHbCVTxTJBCgjShmye(gui,lSOzBWFIhezsjWESJFhL,210,118);WvZHbCVTxTJBCgjShmye(gui,wRytSMnbdEMnVgudFfJZ,210,148);WvZHbCVTxTJBCgjShmye(gui,unZSYijyPrioZySDRIUJ,320,115);WvZHbCVTxTJBCgjShmye(gui,vZaKeuAaoZkxGwYPNjbi,320,145);WvZHbCVTxTJBCgjShmye(gui,uxbdJptkHWIRYkXnCKAE,210,175);WvZHbCVTxTJBCgjShmye(gui,bZmQEwKBHkmcjQvgCvTK,400,175);WvZHbCVTxTJBCgjShmye(gui,ZGAdNwFfCWRTWAlpuWBs,201,195);WvZHbCVTxTJBCgjShmye(gui,VTAniopTrhokxYsdzzVm,210,215);WvZHbCVTxTJBCgjShmye(gui,ZgrdPAuIvoXZymkPTeeh,340,215);WvZHbCVTxTJBCgjShmye(gui,iXnhErQKYveDaeclJTTl,450,215);WvZHbCVTxTJBCgjShmye(gui,KMNaIYZOJNlcHvyOBzvI,580,215);WvZHbCVTxTJBCgjShmye(gui,OPVthwlxiQbZvBLHITrd,210,245);WvZHbCVTxTJBCgjShmye(gui,NZdnYAvFwnjxopIHqHCH,340,245);WvZHbCVTxTJBCgjShmye(gui,brttDknPElnjSHSfhnme,450,245);WvZHbCVTxTJBCgjShmye(gui,PnhGToxqgfwVkqtzghab,580,245);WvZHbCVTxTJBCgjShmye(gui,mVQHsfGAIdVyaJwqreGd,600,175)
def qAilHclPdWbfDRQWfSpd():
	for widget in(unZSYijyPrioZySDRIUJ,vZaKeuAaoZkxGwYPNjbi,uxbdJptkHWIRYkXnCKAE,bZmQEwKBHkmcjQvgCvTK,ZGAdNwFfCWRTWAlpuWBs,VTAniopTrhokxYsdzzVm,ZgrdPAuIvoXZymkPTeeh,iXnhErQKYveDaeclJTTl,KMNaIYZOJNlcHvyOBzvI,mVQHsfGAIdVyaJwqreGd,lSOzBWFIhezsjWESJFhL,wRytSMnbdEMnVgudFfJZ,OPVthwlxiQbZvBLHITrd,NZdnYAvFwnjxopIHqHCH,brttDknPElnjSHSfhnme,PnhGToxqgfwVkqtzghab):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
GfBPTEWLwHLpkLvKEWxx=_f
COIBAQcfQVZWcVfSaoMl=BXxnPGdFgiHeQuztmsNz
xOTADuXdwhmHtXAsLnIH=_f
def YgcECcsHGtzjRdreOwco(text,tome=FudbnvReIPieRucoAuaD,_type=FudbnvReIPieRucoAuaD):
	global xOTADuXdwhmHtXAsLnIH;data=OlFpZxSIOWOxoYIYEJhM[_G][_H]
	if data[_Ad]:phBotChat.Union(text)
	if data[_Ab]:phBotChat.Guild(text)
	if data[_Ac]:phBotChat.Party(text)
	if data[_Ae]and tome:_path=os.getcwd();_path+='\\Plugins\\_lib\\audio\\';_file='scantrader.wav'if _type else'scanthieft.wav';_path+=_file;CTXaLVRTnIBXrFVccRKM(_path)
	xOTADuXdwhmHtXAsLnIH=time()
def khqkioOhioEziQglIikE(text):
	global COIBAQcfQVZWcVfSaoMl,GfBPTEWLwHLpkLvKEWxx
	if not COIBAQcfQVZWcVfSaoMl:YgcECcsHGtzjRdreOwco(text,tome=BXxnPGdFgiHeQuztmsNz)
	else:COIBAQcfQVZWcVfSaoMl=BXxnPGdFgiHeQuztmsNz
	GfBPTEWLwHLpkLvKEWxx=_f
def handle_event(t,data):
	if t in[1,2]:
		if not MgBELXNmBCXlKACcxQtT():return
		if NEuxUqpaygzzghskZNYg():return
		char=KRsJzeKTYFIlLTuRSRiR();rada=OlFpZxSIOWOxoYIYEJhM[_G];scanMainJob=1 if rada[_H][_A1]else 2;ScanSubJob=1 if scanMainJob==2 else 2
		if char[_B]in rada[_J]and OlFpZxSIOWOxoYIYEJhM[_G][_J][char[_B]]:
			global GfBPTEWLwHLpkLvKEWxx,COIBAQcfQVZWcVfSaoMl,xOTADuXdwhmHtXAsLnIH;today=datetime.datetime.now();_timeVar='%sh%s'%(today.hour,today.minute)
			if t==scanMainJob:
				if xOTADuXdwhmHtXAsLnIH:
					check=time()-xOTADuXdwhmHtXAsLnIH
					if check<rada[_H].get(_Aa,30):return
				_jobName=data;_regionName=MbSEKuSVcVLElKscCaEe(char[_AU])
				if _regionName in rada[_r]:return
				if _jobName in rada.get(_s,[]):return
				AFPhQlxrzWNBUZTIKhln=COBGimFIVLjWnnJrrBsJ()
				if not MmzIXEdZSRjOAAIYlWJF():_regionName=AFPhQlxrzWNBUZTIKhln.get(_regionName,_regionName)
				_posVar='%s, %s'%(round(char['x']),round(char['y']));main=rada[_H][_AN];main=main.format(t=_timeVar,n=_jobName,l=_regionName,p=_posVar);_type=FudbnvReIPieRucoAuaD if t==1 else BXxnPGdFgiHeQuztmsNz;YgcECcsHGtzjRdreOwco(main,_type=_type)
				if rada[_H][_AP]:GfBPTEWLwHLpkLvKEWxx=today.hour*60+today.minute;wait=rada[_H][_AQ];sub=rada[_H][_AP];sub=sub.format(t=wait,n=_jobName,l=_regionName,p=_posVar);Timer(wait*60,khqkioOhioEziQglIikE,(sub,)).start()
			elif t==ScanSubJob:
				if GfBPTEWLwHLpkLvKEWxx:
					_timeNow=today.hour*60+today.minute;res=_timeNow-GfBPTEWLwHLpkLvKEWxx
					if res<rada[_H][_AQ]:COIBAQcfQVZWcVfSaoMl=FudbnvReIPieRucoAuaD
SZyEmvdUsZOGUIwyIjyI=sNOKqVOQPcbIohrgrUAk(gui,_k,X,Y)
YuizTbgHycWBzpsQpCFS=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,120,25)
nxUovqYpcySMZrrvZyXD=sNOKqVOQPcbIohrgrUAk(gui,_p,X,Y)
ivsYhoRNplrmzwVrFtTz=cicZNGijwHyNUpQUUWrF(gui,X,Y,120,25)
KpsNtyltAwFgtWHQfVsJ=omskgOqYICjokgtwBAis(gui,'HCfwXiLnAmWrvVCwuBFm',_A0,X,Y)
fLkYnmuWDtlmtiDmrToF=omskgOqYICjokgtwBAis(gui,'pmmMiovnuGaMzApLNYuN',_AM,X,Y)
RDVHwMaLLvSiXvKhfTXV=omskgOqYICjokgtwBAis(gui,'qQrrqaccHVOlbVhSqGHR',_AV,X,Y)
ebeZukBdFvozSdyrqobm=omskgOqYICjokgtwBAis(gui,'NgeuGHcOSlEZhZWfgVyo',_l,X,Y)
UbleoaYmDtuPgHtVQONt=omskgOqYICjokgtwBAis(gui,'dPLmHjatdlwyyTxKdJXU',_m,X,Y)
jYtGuqcwlzDdYRFEoqDA=sNOKqVOQPcbIohrgrUAk(gui,'From:',X,Y)
NnrBSwCOHwqebcyIgNPb=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,25)
SzdAcfgNWPtwJHRkJCep=sNOKqVOQPcbIohrgrUAk(gui,'To:',X,Y)
vaKkieOApRNShuIaTvtw=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,50,25)
xemYmovAxWFBvjbStiUN=omskgOqYICjokgtwBAis(gui,'aXxGHmtsorTfyJhKSNad','State',X,Y)
ZtaMictDBePSndQArJXv=omskgOqYICjokgtwBAis(gui,'NSFvPtmXwJulVSuULAAm','Disconnect',X,Y)
kryPPFDEdgDuetwsdHXp=omskgOqYICjokgtwBAis(gui,'dqwshuYbUUcBRuGbwJvk','Reconnect',X,Y)
EAedRvLFWROljcynLYLw=MTbiymEMtofPpUnLhCKE(gui,'QUldwtvvEyQhFlPTxvBi','Dead/Last',X,Y)
pgGvGNIcaBYKFkCkHDKe=MTbiymEMtofPpUnLhCKE(gui,'wGidofsWTkIoxEYzNbXS','Items Store',X,Y)
ijnOrKqrycBMswPhjApk=MTbiymEMtofPpUnLhCKE(gui,'OYKqhwEBCbrDUjTrmlxr','Fully equip',X,Y)
EbTGYSJSfuzHLzxGjhcK=MTbiymEMtofPpUnLhCKE(gui,'UzwbcjNyHaUHqLahYnQl','Hide Client',X,Y)
TDEEQgyJDYqiKGZCgXCs=sNOKqVOQPcbIohrgrUAk(gui,'Pt Mems:',X,Y)
UKmDimKpTLtAKzwIxEFC=cicZNGijwHyNUpQUUWrF(gui,X,Y,35,25)
bbfPlczPUiCJVRXfIaBY=sNOKqVOQPcbIohrgrUAk(gui,'Town script:',X,Y)
bEdDsnbBcqLbMuXRNSog=cicZNGijwHyNUpQUUWrF(gui,X,Y,110,25)
eZGjFIHCIXJDFITZSUvb=omskgOqYICjokgtwBAis(gui,'iOTDpZXCvSrnTCWUoJqn',_Z,X,Y)
NshhSQubaXWrRicudFDI=sNOKqVOQPcbIohrgrUAk(gui,'From:',X,Y)
NuXhsxQUugRrQxaDUrBh=cicZNGijwHyNUpQUUWrF(gui,X,Y,80,22)
RPPInSsbGxPhyOvtMgVW=omskgOqYICjokgtwBAis(gui,'iZnneBhXajdTCmkiBkre','Copy',X,Y)
def aXxGHmtsorTfyJhKSNad():vwskiQodHpvLZQWOUhkj()
def HCfwXiLnAmWrvVCwuBFm():
	dfRDGqRhmmuotlMipoue();global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,YuizTbgHycWBzpsQpCFS);_data=OlFpZxSIOWOxoYIYEJhM.get(_K)
	if not _data:OlFpZxSIOWOxoYIYEJhM[_K]={}
	names=list(OlFpZxSIOWOxoYIYEJhM[_K].keys());check=name and sXkMGiiYfTCJYksKpBKb(name)and CXmyKqeqvrjquzBvrliF(name,names)
	if not check:return BXxnPGdFgiHeQuztmsNz
	OlFpZxSIOWOxoYIYEJhM[_K][name]={_Y:BXxnPGdFgiHeQuztmsNz,_Af:['00:00','23:59'],_h:BXxnPGdFgiHeQuztmsNz,_Ag:BXxnPGdFgiHeQuztmsNz,_Aw:FudbnvReIPieRucoAuaD,'pt':0,_R:'Donwhang',_AR:BXxnPGdFgiHeQuztmsNz};qqiewGGMbbypNfVFpsFt(gui,ivsYhoRNplrmzwVrFtTz,name);uTjWQRuHkfUwHqUKBXer(gui,ivsYhoRNplrmzwVrFtTz,name);YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);ZsakXHqqtnBRTBKTKzhq();KyMTfckCniYQMCrnFmAF()
def pmmMiovnuGaMzApLNYuN():
	global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,ivsYhoRNplrmzwVrFtTz)
	if name:del OlFpZxSIOWOxoYIYEJhM[_K][name];siKzOlMeldZyVPPewFTK(BXxnPGdFgiHeQuztmsNz);YFukmxaUPxAeINdxfnlI()
	YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);lywbvBarobpigBBffFVQ(gui,ivsYhoRNplrmzwVrFtTz,name);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo));MmZmuEyExNdbFQkAcFik();KyMTfckCniYQMCrnFmAF()
def qQrrqaccHVOlbVhSqGHR():ZsakXHqqtnBRTBKTKzhq()
def NgeuGHcOSlEZhZWfgVyo():
	dfRDGqRhmmuotlMipoue();global OlFpZxSIOWOxoYIYEJhM;name=KRsJzeKTYFIlLTuRSRiR()[_B]
	if not name:return
	name_data=OlFpZxSIOWOxoYIYEJhM[_K].get(name)
	if not name_data:return
	_state=name_data[_Y]
	if not _state:OlFpZxSIOWOxoYIYEJhM[_K][name][_Y]=FudbnvReIPieRucoAuaD;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);KyMTfckCniYQMCrnFmAF();siKzOlMeldZyVPPewFTK(FudbnvReIPieRucoAuaD);xSetFlagEnableAutoLogoutCTFunc(BXxnPGdFgiHeQuztmsNz);Thread(target=tobWMVztmmrJfmgqaJug).start();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(181,hhtizdLRxJDclVvtcTSo))
def dPLmHjatdlwyyTxKdJXU():
	global OlFpZxSIOWOxoYIYEJhM;name=KRsJzeKTYFIlLTuRSRiR()[_B]
	if not name:return
	name_data=OlFpZxSIOWOxoYIYEJhM[_K].get(name)
	if not name_data:return
	_state=name_data[_Y]
	if _state:OlFpZxSIOWOxoYIYEJhM[_K][name][_Y]=BXxnPGdFgiHeQuztmsNz;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);KyMTfckCniYQMCrnFmAF();siKzOlMeldZyVPPewFTK(BXxnPGdFgiHeQuztmsNz);YFukmxaUPxAeINdxfnlI();beMktYuIQjIzJQuMCEmm(BXxnPGdFgiHeQuztmsNz);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(182,hhtizdLRxJDclVvtcTSo))
def NSFvPtmXwJulVSuULAAm():
	names=eVgCyKIrycDTuQqfdcWP(gui,ivsYhoRNplrmzwVrFtTz);name=KRsJzeKTYFIlLTuRSRiR()[_B]
	if name not in names:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(184,hhtizdLRxJDclVvtcTSo));return
	if RtWDIYsnYAIjHnlQmeys():rebeoDRNutkBlSvUAzEB();ouGUZgyQDeexxUHBaqEC(1);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(183,hhtizdLRxJDclVvtcTSo,'Disable'))
def dqwshuYbUUcBRuGbwJvk():
	names=eVgCyKIrycDTuQqfdcWP(gui,ivsYhoRNplrmzwVrFtTz);name=KRsJzeKTYFIlLTuRSRiR()[_B]
	if name not in names:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(184,hhtizdLRxJDclVvtcTSo));return
	if not RtWDIYsnYAIjHnlQmeys():KLcZMlqFMghznYxLnDmS(FudbnvReIPieRucoAuaD);ouGUZgyQDeexxUHBaqEC(2);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(183,hhtizdLRxJDclVvtcTSo,'Enable'))
def QUldwtvvEyQhFlPTxvBi(e):0
def UzwbcjNyHaUHqLahYnQl(e):uHMSPGUVvFhtnAYJZIlM(e)
def wGidofsWTkIoxEYzNbXS(e):
	if not e:FKErQpKRMOMgGqMZMIwo(gui,ijnOrKqrycBMswPhjApk,BXxnPGdFgiHeQuztmsNz);tGbRwQhbAErYotZZkeSf(gui,ijnOrKqrycBMswPhjApk,BXxnPGdFgiHeQuztmsNz);FKErQpKRMOMgGqMZMIwo(gui,EAedRvLFWROljcynLYLw,BXxnPGdFgiHeQuztmsNz);tGbRwQhbAErYotZZkeSf(gui,EAedRvLFWROljcynLYLw,BXxnPGdFgiHeQuztmsNz)
	else:tGbRwQhbAErYotZZkeSf(gui,ijnOrKqrycBMswPhjApk,FudbnvReIPieRucoAuaD);tGbRwQhbAErYotZZkeSf(gui,EAedRvLFWROljcynLYLw,FudbnvReIPieRucoAuaD)
def OYKqhwEBCbrDUjTrmlxr(e):0
def iOTDpZXCvSrnTCWUoJqn():
	A='From or To';dfRDGqRhmmuotlMipoue();global OlFpZxSIOWOxoYIYEJhM;name=PRptGTFSeNBhCFUPbbfz(gui,ivsYhoRNplrmzwVrFtTz)
	if not name:return
	_from=PRptGTFSeNBhCFUPbbfz(gui,NnrBSwCOHwqebcyIgNPb);_to=PRptGTFSeNBhCFUPbbfz(gui,vaKkieOApRNShuIaTvtw);_script=PRptGTFSeNBhCFUPbbfz(gui,bEdDsnbBcqLbMuXRNSog);_last=LBRexqqDJqawZRqWrNZr(gui,EAedRvLFWROljcynLYLw);_fully=LBRexqqDJqawZRqWrNZr(gui,ijnOrKqrycBMswPhjApk);_storage=LBRexqqDJqawZRqWrNZr(gui,pgGvGNIcaBYKFkCkHDKe);_hide=LBRexqqDJqawZRqWrNZr(gui,EbTGYSJSfuzHLzxGjhcK);_pt=PRptGTFSeNBhCFUPbbfz(gui,UKmDimKpTLtAKzwIxEFC)
	if not _from or not _to:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,A));return
	if len(_from)not in[3,5]or len(_to)not in[3,5]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,A));return
	OlFpZxSIOWOxoYIYEJhM[_K][name]={_Y:BXxnPGdFgiHeQuztmsNz,_Af:[_from,_to],_h:_last,_Ag:_storage,_Aw:_fully,'pt':int(_pt),_R:_script,_AR:_hide};YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(37,hhtizdLRxJDclVvtcTSo))
def ZsakXHqqtnBRTBKTKzhq():WvZHbCVTxTJBCgjShmye(gui,xemYmovAxWFBvjbStiUN,210,115);WvZHbCVTxTJBCgjShmye(gui,ZtaMictDBePSndQArJXv,300,115);WvZHbCVTxTJBCgjShmye(gui,kryPPFDEdgDuetwsdHXp,390,115);WvZHbCVTxTJBCgjShmye(gui,NshhSQubaXWrRicudFDI,490,118);WvZHbCVTxTJBCgjShmye(gui,NuXhsxQUugRrQxaDUrBh,520,115);WvZHbCVTxTJBCgjShmye(gui,RPPInSsbGxPhyOvtMgVW,600,115);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,135);WvZHbCVTxTJBCgjShmye(gui,jYtGuqcwlzDdYRFEoqDA,210,158);WvZHbCVTxTJBCgjShmye(gui,NnrBSwCOHwqebcyIgNPb,250,155);WvZHbCVTxTJBCgjShmye(gui,SzdAcfgNWPtwJHRkJCep,320,158);WvZHbCVTxTJBCgjShmye(gui,vaKkieOApRNShuIaTvtw,355,155);WvZHbCVTxTJBCgjShmye(gui,bbfPlczPUiCJVRXfIaBY,500,158);WvZHbCVTxTJBCgjShmye(gui,bEdDsnbBcqLbMuXRNSog,580,155);WvZHbCVTxTJBCgjShmye(gui,EAedRvLFWROljcynLYLw,210,190);WvZHbCVTxTJBCgjShmye(gui,pgGvGNIcaBYKFkCkHDKe,310,190);WvZHbCVTxTJBCgjShmye(gui,ijnOrKqrycBMswPhjApk,410,190);WvZHbCVTxTJBCgjShmye(gui,EbTGYSJSfuzHLzxGjhcK,510,190);WvZHbCVTxTJBCgjShmye(gui,TDEEQgyJDYqiKGZCgXCs,600,193);WvZHbCVTxTJBCgjShmye(gui,UKmDimKpTLtAKzwIxEFC,655,190);WvZHbCVTxTJBCgjShmye(gui,ZGAdNwFfCWRTWAlpuWBs,201,215);WvZHbCVTxTJBCgjShmye(gui,eZGjFIHCIXJDFITZSUvb,210,245);MmZmuEyExNdbFQkAcFik()
def MmZmuEyExNdbFQkAcFik():
	name=PRptGTFSeNBhCFUPbbfz(gui,ivsYhoRNplrmzwVrFtTz)
	if not name:return
	data=OlFpZxSIOWOxoYIYEJhM[_K][name];uTjWQRuHkfUwHqUKBXer(gui,NnrBSwCOHwqebcyIgNPb,data[_Af][0]);uTjWQRuHkfUwHqUKBXer(gui,vaKkieOApRNShuIaTvtw,data[_Af][1]);FKErQpKRMOMgGqMZMIwo(gui,EAedRvLFWROljcynLYLw,data[_h]);FKErQpKRMOMgGqMZMIwo(gui,pgGvGNIcaBYKFkCkHDKe,data[_Ag]);FKErQpKRMOMgGqMZMIwo(gui,ijnOrKqrycBMswPhjApk,data[_Aw]);FKErQpKRMOMgGqMZMIwo(gui,EbTGYSJSfuzHLzxGjhcK,data.get(_AR,BXxnPGdFgiHeQuztmsNz))
	if not data[_Ag]:tGbRwQhbAErYotZZkeSf(gui,ijnOrKqrycBMswPhjApk,BXxnPGdFgiHeQuztmsNz)
	RcgxmwdulXbFqNCcXalf(gui,UKmDimKpTLtAKzwIxEFC)
	for i in range(9):qqiewGGMbbypNfVFpsFt(gui,UKmDimKpTLtAKzwIxEFC,str(i))
	uTjWQRuHkfUwHqUKBXer(gui,UKmDimKpTLtAKzwIxEFC,str(data['pt']));RcgxmwdulXbFqNCcXalf(gui,bEdDsnbBcqLbMuXRNSog)
	for i in['Jangan','Donwhang','Hotan','Samarkand']:qqiewGGMbbypNfVFpsFt(gui,bEdDsnbBcqLbMuXRNSog,i)
	uTjWQRuHkfUwHqUKBXer(gui,bEdDsnbBcqLbMuXRNSog,data[_R]);names=eVgCyKIrycDTuQqfdcWP(gui,ivsYhoRNplrmzwVrFtTz);RcgxmwdulXbFqNCcXalf(gui,NuXhsxQUugRrQxaDUrBh)
	for i in names:
		if i and i!=name:qqiewGGMbbypNfVFpsFt(gui,NuXhsxQUugRrQxaDUrBh,i)
def iZnneBhXajdTCmkiBkre():
	global OlFpZxSIOWOxoYIYEJhM;myChar=PRptGTFSeNBhCFUPbbfz(gui,ivsYhoRNplrmzwVrFtTz);fromChar=PRptGTFSeNBhCFUPbbfz(gui,NuXhsxQUugRrQxaDUrBh)
	if not myChar or not fromChar:return
	OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();data=OlFpZxSIOWOxoYIYEJhM[_K][fromChar];OlFpZxSIOWOxoYIYEJhM[_K][myChar]=data;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);MmZmuEyExNdbFQkAcFik();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(71,hhtizdLRxJDclVvtcTSo,fromChar,myChar))
def KyMTfckCniYQMCrnFmAF():
	if xChangePtVar and not HkbgUnqkPodJtewqRPnE:
		data=OlFpZxSIOWOxoYIYEJhM.get(_K)
		if not data:OlFpZxSIOWOxoYIYEJhM[_K]={}
		name=KRsJzeKTYFIlLTuRSRiR()[_B];data=OlFpZxSIOWOxoYIYEJhM[_K].get(name)
		if data and not data[_Y]:WvZHbCVTxTJBCgjShmye(gui,ebeZukBdFvozSdyrqobm,600,75);WvZHbCVTxTJBCgjShmye(gui,UbleoaYmDtuPgHtVQONt,X,Y)
		elif data and data[_Y]:WvZHbCVTxTJBCgjShmye(gui,UbleoaYmDtuPgHtVQONt,600,75);WvZHbCVTxTJBCgjShmye(gui,ebeZukBdFvozSdyrqobm,X,Y)
		else:WvZHbCVTxTJBCgjShmye(gui,ebeZukBdFvozSdyrqobm,600,75);WvZHbCVTxTJBCgjShmye(gui,UbleoaYmDtuPgHtVQONt,X,Y)
	else:WvZHbCVTxTJBCgjShmye(gui,ebeZukBdFvozSdyrqobm,X,Y);WvZHbCVTxTJBCgjShmye(gui,UbleoaYmDtuPgHtVQONt,X,Y)
def TdiaNtumFPYrSGLLINan():
	data=OlFpZxSIOWOxoYIYEJhM.get(_K)
	if not data:OlFpZxSIOWOxoYIYEJhM[_K]={}
	RcgxmwdulXbFqNCcXalf(gui,ivsYhoRNplrmzwVrFtTz);qqiewGGMbbypNfVFpsFt(gui,ivsYhoRNplrmzwVrFtTz,'');names=list(OlFpZxSIOWOxoYIYEJhM[_K].keys())
	for i in names:qqiewGGMbbypNfVFpsFt(gui,ivsYhoRNplrmzwVrFtTz,i)
	if JzLZxXwzKEnKOuUNolBu and JzLZxXwzKEnKOuUNolBu[_B]in names:uTjWQRuHkfUwHqUKBXer(gui,ivsYhoRNplrmzwVrFtTz,JzLZxXwzKEnKOuUNolBu[_B])
	else:uTjWQRuHkfUwHqUKBXer(gui,ivsYhoRNplrmzwVrFtTz,'');uTjWQRuHkfUwHqUKBXer(gui,YuizTbgHycWBzpsQpCFS,JzLZxXwzKEnKOuUNolBu[_B])
EjtoNUtLxFtKIEOMvhtX=sNOKqVOQPcbIohrgrUAk(gui,'From server:',X,Y)
FrgxHvNIBJJxuBVeacXR=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
LBahQqbQRxTXMhOqrwWM=omskgOqYICjokgtwBAis(gui,'KPfbIXJZACJcFaUIjXZT','Reload Chars',X,Y)
OHxVFPKGvDBxwsiYZKos=sNOKqVOQPcbIohrgrUAk(gui,_B6,X,Y)
EZcFMGpakmltXclnQeny=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
tQNpQoHifgapETqLIHVR=sNOKqVOQPcbIohrgrUAk(gui,'Menu copy:',X,Y)
CZVTlGvyFRsGWIPJjHSG=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
PkpaklmYJIXUFxenJOQb=sNOKqVOQPcbIohrgrUAk(gui,'To server:',X,Y)
nPchGkQdqGYgyAJziARM=cicZNGijwHyNUpQUUWrF(gui,X,Y,150,25)
mwtlrGSMDJkRHRosifTS=sNOKqVOQPcbIohrgrUAk(gui,_B6,X,Y)
PlIMjcuvdxRJAMxrqDBm=FeDRalZYwLwiBJwVubBM(gui,'',X,Y,150,25)
XuWkAbuLLUAMbEkGJGsA=omskgOqYICjokgtwBAis(gui,'pqveGmMnBVWdokwlMDFY','Start Copy',X,Y)
OplRKNGutNdWoVejIvNK=MTbiymEMtofPpUnLhCKE(gui,'TepUHTOEgfqKOuRVtABW','Chat Reload',X,Y)
ajgZOfHwMfnjLKiATTCf=omskgOqYICjokgtwBAis(gui,'SwewafnuTMRVLkxEkYAA','Restore',X,Y)
def TepUHTOEgfqKOuRVtABW(e):NKWYyRwkxDpGlQIpkYpQ(e)
def NpAZrpWShLtniUVHJLyQ():
	A='Notifications';char=KRsJzeKTYFIlLTuRSRiR();getDt=qCKbnanzUyBspsQmcKIj();RcgxmwdulXbFqNCcXalf(gui,FrgxHvNIBJJxuBVeacXR);RcgxmwdulXbFqNCcXalf(gui,nPchGkQdqGYgyAJziARM)
	for key in getDt:qqiewGGMbbypNfVFpsFt(gui,FrgxHvNIBJJxuBVeacXR,key);qqiewGGMbbypNfVFpsFt(gui,nPchGkQdqGYgyAJziARM,key)
	if char[_d]:uTjWQRuHkfUwHqUKBXer(gui,FrgxHvNIBJJxuBVeacXR,char[_d]);uTjWQRuHkfUwHqUKBXer(gui,nPchGkQdqGYgyAJziARM,char[_d])
	_sv=PRptGTFSeNBhCFUPbbfz(gui,FrgxHvNIBJJxuBVeacXR)
	if _sv:
		RcgxmwdulXbFqNCcXalf(gui,EZcFMGpakmltXclnQeny)
		for value in getDt[_sv]:qqiewGGMbbypNfVFpsFt(gui,EZcFMGpakmltXclnQeny,value)
	if(_sv and char[_d]==_sv)and char[_B]in getDt[_sv]:uTjWQRuHkfUwHqUKBXer(gui,EZcFMGpakmltXclnQeny,char[_B])
	RcgxmwdulXbFqNCcXalf(gui,CZVTlGvyFRsGWIPJjHSG)
	for i in['All menu',_Ax,_Ay,A,'Protection','Town and Pick Filter','Training Area','Attack','Pet','Party','Masteries',_Ar,'Key Bindings','Conditions']:qqiewGGMbbypNfVFpsFt(gui,CZVTlGvyFRsGWIPJjHSG,i)
	uTjWQRuHkfUwHqUKBXer(gui,CZVTlGvyFRsGWIPJjHSG,A);FKErQpKRMOMgGqMZMIwo(gui,OplRKNGutNdWoVejIvNK,SaXaqwFCDNbqgKzDmnSi())
def KPfbIXJZACJcFaUIjXZT():
	dt=cgLXqiYvrLnIHlYmMNDp()
	if dt:
		_sv=PRptGTFSeNBhCFUPbbfz(gui,FrgxHvNIBJJxuBVeacXR);RcgxmwdulXbFqNCcXalf(gui,EZcFMGpakmltXclnQeny)
		if _sv:
			for name in dt[_sv]:qqiewGGMbbypNfVFpsFt(gui,EZcFMGpakmltXclnQeny,name)
			dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(79,hhtizdLRxJDclVvtcTSo,_sv))
def pqveGmMnBVWdokwlMDFY():
	global yZRMpjKCfgdkXpdLjJkV,OlFpZxSIOWOxoYIYEJhM;_fromSV=PRptGTFSeNBhCFUPbbfz(gui,FrgxHvNIBJJxuBVeacXR);_fromChar=PRptGTFSeNBhCFUPbbfz(gui,EZcFMGpakmltXclnQeny);_fromMenu=PRptGTFSeNBhCFUPbbfz(gui,CZVTlGvyFRsGWIPJjHSG);_toSV=PRptGTFSeNBhCFUPbbfz(gui,nPchGkQdqGYgyAJziARM);_toChars=PRptGTFSeNBhCFUPbbfz(gui,PlIMjcuvdxRJAMxrqDBm)
	if not(_fromSV and _fromChar and _fromMenu and _toChars and _toSV):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(75,hhtizdLRxJDclVvtcTSo));return
	if _fromMenu==_Ax:
		OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();data=OlFpZxSIOWOxoYIYEJhM[_S].get(_fromChar)
		if data:
			data['13']=[FudbnvReIPieRucoAuaD,_AX];_toChars=_toChars.replace(' ','');_list_to_chars=_toChars.split(',')
			for c in _list_to_chars:
				if not c:continue
				OlFpZxSIOWOxoYIYEJhM[_S][c]=data;dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(71,hhtizdLRxJDclVvtcTSo,_fromChar,c))
			YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM)
		return
	elif _fromMenu==_Ay:
		OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();data=OlFpZxSIOWOxoYIYEJhM[_K].get(_fromChar)
		if data:
			_toChars=_toChars.replace(' ','');_list_to_chars=_toChars.split(',')
			for c in _list_to_chars:
				if not c:continue
				OlFpZxSIOWOxoYIYEJhM[_K][c]=data;dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(71,hhtizdLRxJDclVvtcTSo,_fromChar,c))
			YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);MmZmuEyExNdbFQkAcFik()
		return
	_from=_fromSV+_U+_fromChar;_toChars=_toChars.replace(' ','');_list_to_chars=_toChars.split(',')
	for c in _list_to_chars:
		if not c:continue
		_to=_toSV+_U+c
		if _fromSV!=_toSV:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(77,hhtizdLRxJDclVvtcTSo))
		lHpZIpUXYZdnLXTLTZrY(_from,_to,_fromMenu)
		if SaXaqwFCDNbqgKzDmnSi():
			server=dVtbYiQwNejzohuHTgyt()
			if not server==_fromSV==_toSV:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(80,hhtizdLRxJDclVvtcTSo,c))
			else:_pm=_B7%(OlFpZxSIOWOxoYIYEJhM[_C][_L],OlFpZxSIOWOxoYIYEJhM[_C][_A][_A9],c);phBotChat.Private(c,_pm)
def SwewafnuTMRVLkxEkYAA():
	_fromSV=PRptGTFSeNBhCFUPbbfz(gui,FrgxHvNIBJJxuBVeacXR);_fromMenu=PRptGTFSeNBhCFUPbbfz(gui,CZVTlGvyFRsGWIPJjHSG);_toSV=PRptGTFSeNBhCFUPbbfz(gui,nPchGkQdqGYgyAJziARM);_toChars=PRptGTFSeNBhCFUPbbfz(gui,PlIMjcuvdxRJAMxrqDBm)
	if not(_fromMenu and _toChars and _toSV):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(75,hhtizdLRxJDclVvtcTSo));return
	if _fromMenu in[_Ax,_Ay]:dRBzRDsZDulhsFtoVKPh('Plugin [%s]: Không hỗ trợ phục hồi cho menu này'%hhtizdLRxJDclVvtcTSo);return
	res_data=gaPBfiQhIOsoyEVPQYbn();_toChars=_toChars.replace(' ','');_list_to_chars=_toChars.split(',')
	for c in _list_to_chars:
		if not c:continue
		_to=_toSV+_U+c
		if not res_data.get(_to):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(81,hhtizdLRxJDclVvtcTSo,c));return
		if _fromSV!=_toSV:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(81,hhtizdLRxJDclVvtcTSo,c));return
		lHpZIpUXYZdnLXTLTZrY(_to,_to,_fromMenu,_restore=res_data[_to])
		if SaXaqwFCDNbqgKzDmnSi():
			char=KRsJzeKTYFIlLTuRSRiR()
			if not char[_d]==_fromSV==_toSV:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(80,hhtizdLRxJDclVvtcTSo,c))
			else:_pm=_B7%(OlFpZxSIOWOxoYIYEJhM[_C][_L],OlFpZxSIOWOxoYIYEJhM[_C][_A][_A9],c);phBotChat.Private(c,_pm)
def uNkFVhJxPexBuPOgeFqp():WvZHbCVTxTJBCgjShmye(gui,EjtoNUtLxFtKIEOMvhtX,210,60);WvZHbCVTxTJBCgjShmye(gui,FrgxHvNIBJJxuBVeacXR,330,60);WvZHbCVTxTJBCgjShmye(gui,OHxVFPKGvDBxwsiYZKos,210,90);WvZHbCVTxTJBCgjShmye(gui,EZcFMGpakmltXclnQeny,330,90);WvZHbCVTxTJBCgjShmye(gui,LBahQqbQRxTXMhOqrwWM,530,90);WvZHbCVTxTJBCgjShmye(gui,tQNpQoHifgapETqLIHVR,210,120);WvZHbCVTxTJBCgjShmye(gui,CZVTlGvyFRsGWIPJjHSG,330,120);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,140);WvZHbCVTxTJBCgjShmye(gui,PkpaklmYJIXUFxenJOQb,210,160);WvZHbCVTxTJBCgjShmye(gui,nPchGkQdqGYgyAJziARM,330,160);WvZHbCVTxTJBCgjShmye(gui,mwtlrGSMDJkRHRosifTS,210,190);WvZHbCVTxTJBCgjShmye(gui,PlIMjcuvdxRJAMxrqDBm,330,190);WvZHbCVTxTJBCgjShmye(gui,OplRKNGutNdWoVejIvNK,530,193);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,210);WvZHbCVTxTJBCgjShmye(gui,ajgZOfHwMfnjLKiATTCf,330,240);WvZHbCVTxTJBCgjShmye(gui,XuWkAbuLLUAMbEkGJGsA,530,240);NpAZrpWShLtniUVHJLyQ()
def vLUXUaFHPAOQhPFIWfwK():
	for widget in[EjtoNUtLxFtKIEOMvhtX,OHxVFPKGvDBxwsiYZKos,FrgxHvNIBJJxuBVeacXR,LBahQqbQRxTXMhOqrwWM,EZcFMGpakmltXclnQeny,tQNpQoHifgapETqLIHVR,CZVTlGvyFRsGWIPJjHSG,PkpaklmYJIXUFxenJOQb,nPchGkQdqGYgyAJziARM,mwtlrGSMDJkRHRosifTS,PlIMjcuvdxRJAMxrqDBm,XuWkAbuLLUAMbEkGJGsA,YByJftUWNhdabggdxFlm,VdunfnMGuQDmiYrhJqnj,OplRKNGutNdWoVejIvNK,ajgZOfHwMfnjLKiATTCf]:WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
aghPFvsiQyvenWJlKLqt=BXxnPGdFgiHeQuztmsNz
GhpvGNZozdgfbOOjgAqC=sNOKqVOQPcbIohrgrUAk(gui,NweMXVypQZSXaVSCagqM('MainHelp'),210,35)
iyNAvqWknGZbiiVRhgpt=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
DmUriVHlhOVbLxudCrhs=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
nDAkkDPfBNFuGzdiWcai=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
KmlUzMHSmqUKApjGGBsg=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
xwdjKotrwyLdZotjZIpn=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
SXNomkEEBRGyegFziKWU=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
AQWiziayGtjAGQTCfqKf=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
cefrNAsmemTSLhANCfFV=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
UydMrdbSVTLdzWBZUIvE=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
OVMQeMhffYZpxwFURrQT=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
YfPvsvDubylIHzWNLOLM=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
KZODvyAlNzOLRrLspohF=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
DlwXKPfIPGWqORmZMuXC=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
uYIMexFKbWKIRcThbkro=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
xTutorialBuyF10Help=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
xTutorialChangePtHelp=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
YlpODxjCIWAFFeVzarcn=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
XMrQwVoLTYsjhnZsNAUW=sNOKqVOQPcbIohrgrUAk(gui,'',X,Y)
def wMCXeyyxgTVrqlEURSLd(widgetHelp,show=FudbnvReIPieRucoAuaD):
	if show:WvZHbCVTxTJBCgjShmye(gui,widgetHelp,210,35)
	else:WvZHbCVTxTJBCgjShmye(gui,widgetHelp,X,Y)
def JBOKRKKsekoiVntoirzm(widgetHelp,xTransKey):text=NweMXVypQZSXaVSCagqM(xTransKey);uTjWQRuHkfUwHqUKBXer(gui,widgetHelp,text)
def HjxVHSEMnsSDsTlUspwd():
	global aghPFvsiQyvenWJlKLqt
	if ClKpoayHpwwSviKZagfc:wMCXeyyxgTVrqlEURSLd(iyNAvqWknGZbiiVRhgpt,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,85)
	elif ChfcAMsGCyHQvoqTAIuZ:wMCXeyyxgTVrqlEURSLd(DmUriVHlhOVbLxudCrhs,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,115)
	elif lXFpjJHIhLCAKxStdIIN:wMCXeyyxgTVrqlEURSLd(nDAkkDPfBNFuGzdiWcai,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,145)
	elif WXOlKzccVdGkHUjRXXsZ:wMCXeyyxgTVrqlEURSLd(KmlUzMHSmqUKApjGGBsg,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,175)
	elif hxYJYDWvaFluRTTSJySH:wMCXeyyxgTVrqlEURSLd(xwdjKotrwyLdZotjZIpn,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,205)
	elif bmxUIMLqLFjHPZiSfsMG:wMCXeyyxgTVrqlEURSLd(SXNomkEEBRGyegFziKWU,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,235)
	elif RKmDAbtczjVYieHRRdAI:wMCXeyyxgTVrqlEURSLd(AQWiziayGtjAGQTCfqKf,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,265)
	elif nMhZqiHrxCrOPNEdHeDX:wMCXeyyxgTVrqlEURSLd(UydMrdbSVTLdzWBZUIvE,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,115)
	elif gtlsRcKNLeroyQSrGAWI:wMCXeyyxgTVrqlEURSLd(OVMQeMhffYZpxwFURrQT,HkbgUnqkPodJtewqRPnE)
	elif dltpVDzRJuNUOeKNWlZO:wMCXeyyxgTVrqlEURSLd(KZODvyAlNzOLRrLspohF,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,175)
	elif CyIvXRCscUQUzKzKgvtX:wMCXeyyxgTVrqlEURSLd(YfPvsvDubylIHzWNLOLM,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,205)
	elif XHutdYTebhNytzkxsqHB:wMCXeyyxgTVrqlEURSLd(DlwXKPfIPGWqORmZMuXC,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,235)
	elif nmoMZqJalmdpGvQlvcFN:wMCXeyyxgTVrqlEURSLd(cefrNAsmemTSLhANCfFV,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,85)
	elif AikJGYbVxICEhnCEmMtM:wMCXeyyxgTVrqlEURSLd(uYIMexFKbWKIRcThbkro,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,265)
	elif xBuyF10Var:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,85);wMCXeyyxgTVrqlEURSLd(xTutorialBuyF10Help,HkbgUnqkPodJtewqRPnE)
	elif xChangePtVar:wMCXeyyxgTVrqlEURSLd(xTutorialChangePtHelp,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,115)
	elif ASKmopOSSsyBceSyeaqq:wMCXeyyxgTVrqlEURSLd(YlpODxjCIWAFFeVzarcn,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,145)
	elif ATQXujoMxxZtrVjfMcKz:wMCXeyyxgTVrqlEURSLd(XMrQwVoLTYsjhnZsNAUW,HkbgUnqkPodJtewqRPnE);WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,175)
	if not aghPFvsiQyvenWJlKLqt:JqlwazDWdIKTLEtZbZHC();aghPFvsiQyvenWJlKLqt=FudbnvReIPieRucoAuaD
def JqlwazDWdIKTLEtZbZHC():JBOKRKKsekoiVntoirzm(iyNAvqWknGZbiiVRhgpt,'GuildHelp');JBOKRKKsekoiVntoirzm(DmUriVHlhOVbLxudCrhs,'MoveHelp');JBOKRKKsekoiVntoirzm(nDAkkDPfBNFuGzdiWcai,'SetHelp');JBOKRKKsekoiVntoirzm(KmlUzMHSmqUKApjGGBsg,'ExMapHelp');JBOKRKKsekoiVntoirzm(xwdjKotrwyLdZotjZIpn,'FixMapHelp');JBOKRKKsekoiVntoirzm(SXNomkEEBRGyegFziKWU,'ConvertItemHelp');JBOKRKKsekoiVntoirzm(AQWiziayGtjAGQTCfqKf,'PythonHelp');JBOKRKKsekoiVntoirzm(cefrNAsmemTSLhANCfFV,'StoreItemHelp');JBOKRKKsekoiVntoirzm(UydMrdbSVTLdzWBZUIvE,'TeleHelp');JBOKRKKsekoiVntoirzm(OVMQeMhffYZpxwFURrQT,'MNSHelp');JBOKRKKsekoiVntoirzm(YfPvsvDubylIHzWNLOLM,'CureHelp');JBOKRKKsekoiVntoirzm(KZODvyAlNzOLRrLspohF,'ScriptHelp');JBOKRKKsekoiVntoirzm(DlwXKPfIPGWqORmZMuXC,'GhostHelp');JBOKRKKsekoiVntoirzm(uYIMexFKbWKIRcThbkro,'GuardHelp');JBOKRKKsekoiVntoirzm(GhpvGNZozdgfbOOjgAqC,'MainHelp');JBOKRKKsekoiVntoirzm(xTutorialBuyF10Help,'BuyF10Help');JBOKRKKsekoiVntoirzm(xTutorialChangePtHelp,'ChangePtHelp');JBOKRKKsekoiVntoirzm(YlpODxjCIWAFFeVzarcn,'CopyConfigHelp');JBOKRKKsekoiVntoirzm(XMrQwVoLTYsjhnZsNAUW,'JobRadaHelp')
def WraIALrPVutsDneXMsCv():
	for widget in[GhpvGNZozdgfbOOjgAqC,iyNAvqWknGZbiiVRhgpt,DmUriVHlhOVbLxudCrhs,nDAkkDPfBNFuGzdiWcai,KmlUzMHSmqUKApjGGBsg,xwdjKotrwyLdZotjZIpn,SXNomkEEBRGyegFziKWU,AQWiziayGtjAGQTCfqKf,cefrNAsmemTSLhANCfFV,UydMrdbSVTLdzWBZUIvE,OVMQeMhffYZpxwFURrQT,YfPvsvDubylIHzWNLOLM,KZODvyAlNzOLRrLspohF,DlwXKPfIPGWqORmZMuXC,uYIMexFKbWKIRcThbkro,xTutorialChangePtHelp,xTutorialBuyF10Help,YlpODxjCIWAFFeVzarcn,XMrQwVoLTYsjhnZsNAUW]:WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
def aDaMVTycdVoWsppqGYHm():global ClKpoayHpwwSviKZagfc,ChfcAMsGCyHQvoqTAIuZ,lXFpjJHIhLCAKxStdIIN,WXOlKzccVdGkHUjRXXsZ,hxYJYDWvaFluRTTSJySH,bmxUIMLqLFjHPZiSfsMG,nmoMZqJalmdpGvQlvcFN;global RKmDAbtczjVYieHRRdAI,nMhZqiHrxCrOPNEdHeDX,dltpVDzRJuNUOeKNWlZO,gtlsRcKNLeroyQSrGAWI,XHutdYTebhNytzkxsqHB,CyIvXRCscUQUzKzKgvtX,AikJGYbVxICEhnCEmMtM;global xBuyF10Var,xChangePtVar,ASKmopOSSsyBceSyeaqq,ATQXujoMxxZtrVjfMcKz;ClKpoayHpwwSviKZagfc=BXxnPGdFgiHeQuztmsNz;ChfcAMsGCyHQvoqTAIuZ=BXxnPGdFgiHeQuztmsNz;lXFpjJHIhLCAKxStdIIN=BXxnPGdFgiHeQuztmsNz;WXOlKzccVdGkHUjRXXsZ=BXxnPGdFgiHeQuztmsNz;hxYJYDWvaFluRTTSJySH=BXxnPGdFgiHeQuztmsNz;bmxUIMLqLFjHPZiSfsMG=BXxnPGdFgiHeQuztmsNz;nmoMZqJalmdpGvQlvcFN=BXxnPGdFgiHeQuztmsNz;RKmDAbtczjVYieHRRdAI=BXxnPGdFgiHeQuztmsNz;nMhZqiHrxCrOPNEdHeDX=BXxnPGdFgiHeQuztmsNz;dltpVDzRJuNUOeKNWlZO=BXxnPGdFgiHeQuztmsNz;gtlsRcKNLeroyQSrGAWI=BXxnPGdFgiHeQuztmsNz;XHutdYTebhNytzkxsqHB=BXxnPGdFgiHeQuztmsNz;CyIvXRCscUQUzKzKgvtX=BXxnPGdFgiHeQuztmsNz;AikJGYbVxICEhnCEmMtM=BXxnPGdFgiHeQuztmsNz;xBuyF10Var=BXxnPGdFgiHeQuztmsNz;xChangePtVar=BXxnPGdFgiHeQuztmsNz;ASKmopOSSsyBceSyeaqq=BXxnPGdFgiHeQuztmsNz;ATQXujoMxxZtrVjfMcKz=BXxnPGdFgiHeQuztmsNz
def nxRgwBhngFBToEkTEWzY():
	if IcbAIPRcQbkYAYMlnRsN:tGbRwQhbAErYotZZkeSf(gui,hDzUpAaPErGtcuEyRuvq,BXxnPGdFgiHeQuztmsNz);tGbRwQhbAErYotZZkeSf(gui,NRuouxFMZxZsFiAQRxZP,FudbnvReIPieRucoAuaD)
	elif OwbJzZbyVhInwpLOEEVg:tGbRwQhbAErYotZZkeSf(gui,hDzUpAaPErGtcuEyRuvq,FudbnvReIPieRucoAuaD);tGbRwQhbAErYotZZkeSf(gui,NRuouxFMZxZsFiAQRxZP,FudbnvReIPieRucoAuaD)
	elif GCSBvlxtrqkACwpjcNiK:tGbRwQhbAErYotZZkeSf(gui,hDzUpAaPErGtcuEyRuvq,FudbnvReIPieRucoAuaD);tGbRwQhbAErYotZZkeSf(gui,NRuouxFMZxZsFiAQRxZP,BXxnPGdFgiHeQuztmsNz)
def UPuhKmXbkxZweOWKAiLT():
	global IcbAIPRcQbkYAYMlnRsN,OwbJzZbyVhInwpLOEEVg,GCSBvlxtrqkACwpjcNiK
	if IcbAIPRcQbkYAYMlnRsN:IcbAIPRcQbkYAYMlnRsN=BXxnPGdFgiHeQuztmsNz;GCSBvlxtrqkACwpjcNiK=FudbnvReIPieRucoAuaD
	elif OwbJzZbyVhInwpLOEEVg:OwbJzZbyVhInwpLOEEVg=BXxnPGdFgiHeQuztmsNz;IcbAIPRcQbkYAYMlnRsN=FudbnvReIPieRucoAuaD
	elif GCSBvlxtrqkACwpjcNiK:GCSBvlxtrqkACwpjcNiK=BXxnPGdFgiHeQuztmsNz;OwbJzZbyVhInwpLOEEVg=FudbnvReIPieRucoAuaD
	nxRgwBhngFBToEkTEWzY();ullRHveuKFSbybtyYPuq()
def cDehvDHiGeptSyoejRov():
	A='support';global IcbAIPRcQbkYAYMlnRsN,OwbJzZbyVhInwpLOEEVg,GCSBvlxtrqkACwpjcNiK
	if IcbAIPRcQbkYAYMlnRsN:IcbAIPRcQbkYAYMlnRsN=BXxnPGdFgiHeQuztmsNz;OwbJzZbyVhInwpLOEEVg=FudbnvReIPieRucoAuaD
	elif OwbJzZbyVhInwpLOEEVg:OwbJzZbyVhInwpLOEEVg=BXxnPGdFgiHeQuztmsNz;GCSBvlxtrqkACwpjcNiK=FudbnvReIPieRucoAuaD
	elif GCSBvlxtrqkACwpjcNiK:GCSBvlxtrqkACwpjcNiK=BXxnPGdFgiHeQuztmsNz;IcbAIPRcQbkYAYMlnRsN=FudbnvReIPieRucoAuaD
	nxRgwBhngFBToEkTEWzY();ullRHveuKFSbybtyYPuq();_ttt=OlFpZxSIOWOxoYIYEJhM.get(A,BXxnPGdFgiHeQuztmsNz)
	if _ttt and(_ttt.get(A)or _ttt.get('male')):WvZHbCVTxTJBCgjShmye(gui,gDFTFSiItMtJaMxVONcM,600,250)
def ullRHveuKFSbybtyYPuq():
	if IcbAIPRcQbkYAYMlnRsN:WvZHbCVTxTJBCgjShmye(gui,gWdKbUSpeAxLBsFpKEoh,10,80);WvZHbCVTxTJBCgjShmye(gui,uxEEKQBahJEZmcaIYvwz,10,110);WvZHbCVTxTJBCgjShmye(gui,TQIGWOCWIwQiiaAiZuoh,10,140);WvZHbCVTxTJBCgjShmye(gui,eOtvjPpLCvYJLAcmGmWE,10,170);WvZHbCVTxTJBCgjShmye(gui,RXLhvOUUgCoAWtoSabHd,10,200);WvZHbCVTxTJBCgjShmye(gui,LABGrwxIiQmJiCamnppg,10,230);WvZHbCVTxTJBCgjShmye(gui,UOeyomueyHdkSVmrxcuU,10,260);WvZHbCVTxTJBCgjShmye(gui,UadeXYTTjsnHZgbjglBF,X,Y);WvZHbCVTxTJBCgjShmye(gui,pOqhqjahTChffUmvYNpV,X,Y);WvZHbCVTxTJBCgjShmye(gui,LRpdqDEzxIiYuvRgmPQv,X,Y);WvZHbCVTxTJBCgjShmye(gui,ueRlwYOgYMOANNGltjlM,X,Y);WvZHbCVTxTJBCgjShmye(gui,ynMQpjqQNdICJcJRoSKz,X,Y);WvZHbCVTxTJBCgjShmye(gui,rLUdvylZXYXGFgnnQxpR,X,Y);WvZHbCVTxTJBCgjShmye(gui,JETeNgvirUhkMZGnFCCC,X,Y);WvZHbCVTxTJBCgjShmye(gui,xBtnShowBuyF10,X,Y);WvZHbCVTxTJBCgjShmye(gui,xBtnShowChangePt,X,Y);WvZHbCVTxTJBCgjShmye(gui,gchiMbbqpxaRcgMTnhMD,X,Y);WvZHbCVTxTJBCgjShmye(gui,ZDfyCJwrIyzereZbIFbZ,X,Y)
	elif OwbJzZbyVhInwpLOEEVg:WvZHbCVTxTJBCgjShmye(gui,gWdKbUSpeAxLBsFpKEoh,X,Y);WvZHbCVTxTJBCgjShmye(gui,uxEEKQBahJEZmcaIYvwz,X,Y);WvZHbCVTxTJBCgjShmye(gui,TQIGWOCWIwQiiaAiZuoh,X,Y);WvZHbCVTxTJBCgjShmye(gui,eOtvjPpLCvYJLAcmGmWE,X,Y);WvZHbCVTxTJBCgjShmye(gui,RXLhvOUUgCoAWtoSabHd,X,Y);WvZHbCVTxTJBCgjShmye(gui,LABGrwxIiQmJiCamnppg,X,Y);WvZHbCVTxTJBCgjShmye(gui,UOeyomueyHdkSVmrxcuU,X,Y);WvZHbCVTxTJBCgjShmye(gui,UadeXYTTjsnHZgbjglBF,10,80);WvZHbCVTxTJBCgjShmye(gui,pOqhqjahTChffUmvYNpV,10,110);WvZHbCVTxTJBCgjShmye(gui,LRpdqDEzxIiYuvRgmPQv,10,140);WvZHbCVTxTJBCgjShmye(gui,ueRlwYOgYMOANNGltjlM,10,170);WvZHbCVTxTJBCgjShmye(gui,ynMQpjqQNdICJcJRoSKz,10,200);WvZHbCVTxTJBCgjShmye(gui,rLUdvylZXYXGFgnnQxpR,10,230);WvZHbCVTxTJBCgjShmye(gui,JETeNgvirUhkMZGnFCCC,10,260);WvZHbCVTxTJBCgjShmye(gui,xBtnShowBuyF10,X,Y);WvZHbCVTxTJBCgjShmye(gui,xBtnShowChangePt,X,Y);WvZHbCVTxTJBCgjShmye(gui,gchiMbbqpxaRcgMTnhMD,X,Y);WvZHbCVTxTJBCgjShmye(gui,ZDfyCJwrIyzereZbIFbZ,X,Y)
	elif GCSBvlxtrqkACwpjcNiK:WvZHbCVTxTJBCgjShmye(gui,gWdKbUSpeAxLBsFpKEoh,X,Y);WvZHbCVTxTJBCgjShmye(gui,uxEEKQBahJEZmcaIYvwz,X,Y);WvZHbCVTxTJBCgjShmye(gui,TQIGWOCWIwQiiaAiZuoh,X,Y);WvZHbCVTxTJBCgjShmye(gui,eOtvjPpLCvYJLAcmGmWE,X,Y);WvZHbCVTxTJBCgjShmye(gui,RXLhvOUUgCoAWtoSabHd,X,Y);WvZHbCVTxTJBCgjShmye(gui,LABGrwxIiQmJiCamnppg,X,Y);WvZHbCVTxTJBCgjShmye(gui,UOeyomueyHdkSVmrxcuU,X,Y);WvZHbCVTxTJBCgjShmye(gui,UadeXYTTjsnHZgbjglBF,X,Y);WvZHbCVTxTJBCgjShmye(gui,pOqhqjahTChffUmvYNpV,X,Y);WvZHbCVTxTJBCgjShmye(gui,LRpdqDEzxIiYuvRgmPQv,X,Y);WvZHbCVTxTJBCgjShmye(gui,ueRlwYOgYMOANNGltjlM,X,Y);WvZHbCVTxTJBCgjShmye(gui,ynMQpjqQNdICJcJRoSKz,X,Y);WvZHbCVTxTJBCgjShmye(gui,rLUdvylZXYXGFgnnQxpR,X,Y);WvZHbCVTxTJBCgjShmye(gui,JETeNgvirUhkMZGnFCCC,X,Y);WvZHbCVTxTJBCgjShmye(gui,xBtnShowBuyF10,10,80);WvZHbCVTxTJBCgjShmye(gui,xBtnShowChangePt,10,110);WvZHbCVTxTJBCgjShmye(gui,gchiMbbqpxaRcgMTnhMD,10,140);WvZHbCVTxTJBCgjShmye(gui,ZDfyCJwrIyzereZbIFbZ,10,170)
def mRBmsnqpjiPVNnyLwhpj():global HkbgUnqkPodJtewqRPnE,aghPFvsiQyvenWJlKLqt;BoYsDyWfwdLtybunWpSO();HkbgUnqkPodJtewqRPnE=FudbnvReIPieRucoAuaD;CCkbvzvwPSCwRaORhIQW();AmwwjqfjTbRxpvURidaF()
def XPNIzFgKtFaEifUlqaWH():global HkbgUnqkPodJtewqRPnE;BoYsDyWfwdLtybunWpSO();HkbgUnqkPodJtewqRPnE=BXxnPGdFgiHeQuztmsNz;CCkbvzvwPSCwRaORhIQW();AmwwjqfjTbRxpvURidaF();YYTkoMLMHyGQFSzikkhJ();ftXQDpzExIfUzQQxOVbf();UkgVLmhyLzQBXpNJTQkV();lpsoShHeoGwKssQAiZWg()
def SIsHTGdXttjOvlTrTfog():global ClKpoayHpwwSviKZagfc;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();ClKpoayHpwwSviKZagfc=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();UlStahWlATZklIGCbJOn()
def wzWvBKZeDSPpaZvcfaiu():global ChfcAMsGCyHQvoqTAIuZ;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();ChfcAMsGCyHQvoqTAIuZ=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();nHqFxzaxMNtRDdQNTqVd()
def bjhQMrJquOuyWkpGpokv():global lXFpjJHIhLCAKxStdIIN;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();lXFpjJHIhLCAKxStdIIN=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();eBfulHLCnrYSDKRDJDPu()
def kKXizTuNCoVHBWqIRyCE():global WXOlKzccVdGkHUjRXXsZ;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();WXOlKzccVdGkHUjRXXsZ=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();kpdGqfGpCHeuEeChTRpI()
def vZbwPSaGMtYsLVpnILPA():global hxYJYDWvaFluRTTSJySH;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();hxYJYDWvaFluRTTSJySH=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();bxfpHzyWCjsFrRVCamUR()
def hAmVmaqpqAhwscgiTLGn():global bmxUIMLqLFjHPZiSfsMG;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();bmxUIMLqLFjHPZiSfsMG=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();QDprCggZAXODBvcpcaSR()
def OxJyKNebHeBNEugrSGgi():global nmoMZqJalmdpGvQlvcFN;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();nmoMZqJalmdpGvQlvcFN=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();fXdngHUMGfdmCsQtzyKg()
def HhqoOVrmkYHQnwEPINpV():global RKmDAbtczjVYieHRRdAI;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();RKmDAbtczjVYieHRRdAI=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();HBfXwtxyHbGtLThrMmXW()
def aelHUBqwmRxNsvHjPiOs():global nMhZqiHrxCrOPNEdHeDX;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();nMhZqiHrxCrOPNEdHeDX=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();FAAhdhCFGhAzusPJXQmO()
def mfhnPQximhOFoxaAfuXt():global gtlsRcKNLeroyQSrGAWI;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();gtlsRcKNLeroyQSrGAWI=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF()
def wiwpfXBKgKKiAsmfjvNk():global dltpVDzRJuNUOeKNWlZO;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();dltpVDzRJuNUOeKNWlZO=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();BOohUKYIaWBaSdtRReQg()
def GTlPvaTmraCYzGiacZPg():global XHutdYTebhNytzkxsqHB;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();XHutdYTebhNytzkxsqHB=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();VpTpwmfzgbsRRTMgfrPB()
def TQgSkKFXJXKazsPDBoSN():global CyIvXRCscUQUzKzKgvtX;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();CyIvXRCscUQUzKzKgvtX=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF()
def PSYSokMGVPKVzhMEBsIw():global AikJGYbVxICEhnCEmMtM;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();AikJGYbVxICEhnCEmMtM=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();anAwRCenqbmRVlRRDqnQ()
def wfexbJIauFrpZHPbyJLh():global xBuyF10Var;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();xBuyF10Var=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();FBDleWFBsQRLSQFIiGAE();qjbXQXJWLiCUIxWLiVfZ()
def ZyPtbDesIpIbcBszUSxO():global xChangePtVar;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();xChangePtVar=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF();KyMTfckCniYQMCrnFmAF()
def gcWRCYHLtJvgmSxOrTBz():global ASKmopOSSsyBceSyeaqq;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();ASKmopOSSsyBceSyeaqq=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF()
def YneTOWPtApnTBdckFgIU():global ATQXujoMxxZtrVjfMcKz;BoYsDyWfwdLtybunWpSO();aDaMVTycdVoWsppqGYHm();ATQXujoMxxZtrVjfMcKz=FudbnvReIPieRucoAuaD;AmwwjqfjTbRxpvURidaF()
def CCkbvzvwPSCwRaORhIQW():
	if not HJdVyyMWCyRWFELbqmXn():
		if HkbgUnqkPodJtewqRPnE:WvZHbCVTxTJBCgjShmye(gui,ooGleuELUDeaUvBNvXLk,300,10);WvZHbCVTxTJBCgjShmye(gui,evOwxJrsOZvaGUYoKqpb,X,Y)
		else:WvZHbCVTxTJBCgjShmye(gui,evOwxJrsOZvaGUYoKqpb,300,10);WvZHbCVTxTJBCgjShmye(gui,ooGleuELUDeaUvBNvXLk,X,Y)
	elif HkbgUnqkPodJtewqRPnE:WvZHbCVTxTJBCgjShmye(gui,ooGleuELUDeaUvBNvXLk,250,10);WvZHbCVTxTJBCgjShmye(gui,evOwxJrsOZvaGUYoKqpb,X,Y)
	else:WvZHbCVTxTJBCgjShmye(gui,evOwxJrsOZvaGUYoKqpb,250,10);WvZHbCVTxTJBCgjShmye(gui,ooGleuELUDeaUvBNvXLk,X,Y)
def AmwwjqfjTbRxpvURidaF():
	if HkbgUnqkPodJtewqRPnE:HjxVHSEMnsSDsTlUspwd()
	elif ClKpoayHpwwSviKZagfc:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,85);WvZHbCVTxTJBCgjShmye(gui,CYKrgfiKgkhVlCJxqzGw,210,55);WvZHbCVTxTJBCgjShmye(gui,eppXpjnTqxMPHpFKCfsK,230,50);WvZHbCVTxTJBCgjShmye(gui,fOWIyDNVHgiEGwrStpPX,340,50);WvZHbCVTxTJBCgjShmye(gui,ToPQCoIfNiwtIuiRtmZK,470,55);WvZHbCVTxTJBCgjShmye(gui,yJATnvnBuSJSkcIrbajr,490,50);WvZHbCVTxTJBCgjShmye(gui,EwrTknRthJdiVOdNRCJf,600,50);WvZHbCVTxTJBCgjShmye(gui,rnWkPCjfVbsZkvZDBZmJ,230,80);WvZHbCVTxTJBCgjShmye(gui,jdvWfgFqbdKqWrqBvcfR,490,80);WvZHbCVTxTJBCgjShmye(gui,JWmayNaPnbnduOjFLtlH,230,255);WvZHbCVTxTJBCgjShmye(gui,roIyFiuCYvLeXobAwWni,490,255)
	elif ChfcAMsGCyHQvoqTAIuZ:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,115);WvZHbCVTxTJBCgjShmye(gui,FGyktaHapXwfXhvZlbTf,390,50);WvZHbCVTxTJBCgjShmye(gui,lxQtTBRLIxPeeibjVimW,560,50);WvZHbCVTxTJBCgjShmye(gui,VOVogadnyYomUcqqUuTq,201,70);WvZHbCVTxTJBCgjShmye(gui,qFephjHXtxbXKXKokOgA,210,90);WvZHbCVTxTJBCgjShmye(gui,gtHoDVJzKSVwQNScpbWZ,290,90);WvZHbCVTxTJBCgjShmye(gui,vpvKqXMfbfITdKmfiXin,400,90);WvZHbCVTxTJBCgjShmye(gui,OTjBHMLqRODpyNxHLiXw,460,90);WvZHbCVTxTJBCgjShmye(gui,OOdqGfaMpHYqlnUQFaiX,550,90);WvZHbCVTxTJBCgjShmye(gui,kQMjbvwmYtwxebdEijwt,610,90);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,100);WvZHbCVTxTJBCgjShmye(gui,LACdoUaoitphWphaFlqU,210,125);WvZHbCVTxTJBCgjShmye(gui,CqythJGjfWTXuxMKcyoH,290,125);WvZHbCVTxTJBCgjShmye(gui,WkMmMflZOgRIFwrlMkFc,400,125);WvZHbCVTxTJBCgjShmye(gui,tGIHLOycDmpRhZOXCLIJ,460,125);WvZHbCVTxTJBCgjShmye(gui,smIzvHJtsPgVjJdEXUXc,550,125);WvZHbCVTxTJBCgjShmye(gui,ZbSlFPfNCDjTwbTmRZoc,610,125);WvZHbCVTxTJBCgjShmye(gui,mnpRsxxDXoNWCIcrhxUb,210,150);WvZHbCVTxTJBCgjShmye(gui,vaOEZlzwNtKLFlnuVATY,290,150);WvZHbCVTxTJBCgjShmye(gui,vvJygwgturAXxiJlvAVe,400,150);WvZHbCVTxTJBCgjShmye(gui,uCyzhgqqsDjxCbgBbZHD,460,150);WvZHbCVTxTJBCgjShmye(gui,OYveQLGpEmYOWEoTWiJS,550,150);WvZHbCVTxTJBCgjShmye(gui,UnjehnwwmwRKXxGOxhry,610,150);WvZHbCVTxTJBCgjShmye(gui,IbEdwamajTPcuygjSLxt,210,175);WvZHbCVTxTJBCgjShmye(gui,YUgyEkTwWeJKninmvaOv,290,175);WvZHbCVTxTJBCgjShmye(gui,XjSTEFrFGZcIwXpWHkaz,400,175);WvZHbCVTxTJBCgjShmye(gui,vRwfvWsWvsIwoHimeBri,460,175);WvZHbCVTxTJBCgjShmye(gui,iLwFRDzcisapgKAzjUwr,400,225);WvZHbCVTxTJBCgjShmye(gui,vejetvcRmXXwJxxMAAjh,460,225);WvZHbCVTxTJBCgjShmye(gui,PluHgJfTgYNCTcHRwcKP,210,200);WvZHbCVTxTJBCgjShmye(gui,UFIeOKAidjhZXKYvzMgX,290,200);WvZHbCVTxTJBCgjShmye(gui,RVDtlAkbmMlKCIJWHajp,400,200);WvZHbCVTxTJBCgjShmye(gui,PZswfQcHILPfuidyehUo,460,200);WvZHbCVTxTJBCgjShmye(gui,lnmGOcGnrtsyIAEzboJy,550,200);WvZHbCVTxTJBCgjShmye(gui,ITlfbgHDiifjFniuIuMU,610,200);WvZHbCVTxTJBCgjShmye(gui,MupsMnhlAKkpRpEtMhCO,210,225);WvZHbCVTxTJBCgjShmye(gui,thzEwAUoCljdFruEjWmN,290,225);WvZHbCVTxTJBCgjShmye(gui,FlwZKQoKMlvhPAMIfvwS,550,175);WvZHbCVTxTJBCgjShmye(gui,uscozwxJjhheGOXHuIRf,610,175);WvZHbCVTxTJBCgjShmye(gui,aXopVQWCAJszlgSFGvWn,550,225);WvZHbCVTxTJBCgjShmye(gui,wgwMPmKkbXisxqsqvMLx,610,225)
	elif lXFpjJHIhLCAKxStdIIN:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,145);WvZHbCVTxTJBCgjShmye(gui,FKxqfELWGyhlGnEeOhPo,390,50);WvZHbCVTxTJBCgjShmye(gui,DwJAmngnYKprYHTXZwIH,560,50);WvZHbCVTxTJBCgjShmye(gui,VOVogadnyYomUcqqUuTq,201,70);WvZHbCVTxTJBCgjShmye(gui,AareDXiMMvavpdjJCjEb,210,90);WvZHbCVTxTJBCgjShmye(gui,iHqLOvJrHUqbodjlTOKM,290,90);WvZHbCVTxTJBCgjShmye(gui,vpvKqXMfbfITdKmfiXin,400,90);WvZHbCVTxTJBCgjShmye(gui,OTjBHMLqRODpyNxHLiXw,460,90);WvZHbCVTxTJBCgjShmye(gui,OOdqGfaMpHYqlnUQFaiX,550,90);WvZHbCVTxTJBCgjShmye(gui,kQMjbvwmYtwxebdEijwt,610,90);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,100);WvZHbCVTxTJBCgjShmye(gui,rTUveHsFjTdNdOCapOgJ,210,125);WvZHbCVTxTJBCgjShmye(gui,kEyFZGwfHGFxilWEorHG,290,125);WvZHbCVTxTJBCgjShmye(gui,kOCmTwqGpUUeWgpmOffZ,400,125);WvZHbCVTxTJBCgjShmye(gui,lHielohtlBApnFHhjgbe,460,125);WvZHbCVTxTJBCgjShmye(gui,xjQgmArshGxHLADAtZDM,550,125);WvZHbCVTxTJBCgjShmye(gui,ZdpAASRyfxQVNKXTvDlb,610,125);WvZHbCVTxTJBCgjShmye(gui,FFVPfPYMjImEAgLQWilF,210,150);WvZHbCVTxTJBCgjShmye(gui,tCNMmYYzsCliwIIuqxMA,290,150);WvZHbCVTxTJBCgjShmye(gui,iVwQHksjIeBjqqQYPPNB,400,150);WvZHbCVTxTJBCgjShmye(gui,WOkwTlhWLluNPfNfwSpE,460,150);WvZHbCVTxTJBCgjShmye(gui,lIGFmAhfPwJKMVIZqdJF,550,150);WvZHbCVTxTJBCgjShmye(gui,EcXJOXCZeFQLIiljCGuG,610,150);WvZHbCVTxTJBCgjShmye(gui,cTXvIKjtxVVYEKCpamwX,400,225);WvZHbCVTxTJBCgjShmye(gui,BCoWqKkvUWRvTmvbQkTe,460,225);WvZHbCVTxTJBCgjShmye(gui,EVDNyGgQwbdTJQcvRIAg,400,175);WvZHbCVTxTJBCgjShmye(gui,ezmeCRPxtMSzhhlUldaV,460,175);WvZHbCVTxTJBCgjShmye(gui,ogZxZJWFpSAfBFbuxsQk,550,175);WvZHbCVTxTJBCgjShmye(gui,IFuPxNcrNBJZyytEOAnj,610,175);WvZHbCVTxTJBCgjShmye(gui,HJVLdCYpyPREIwbBAdRQ,210,200);WvZHbCVTxTJBCgjShmye(gui,VGIboPCATIoBNYGGgcVW,290,200);WvZHbCVTxTJBCgjShmye(gui,STninBTkmZJRTzMnWELG,210,175);WvZHbCVTxTJBCgjShmye(gui,mKxlNlGsUzVfBXmzFtQS,290,175);WvZHbCVTxTJBCgjShmye(gui,ilgTepDVGsLKEEIVHrnu,550,200);WvZHbCVTxTJBCgjShmye(gui,nJhVIBPuIenJJObDvvjZ,610,200);WvZHbCVTxTJBCgjShmye(gui,VcpVmwjQXxcMlrXYTszB,400,200);WvZHbCVTxTJBCgjShmye(gui,TfTDLyLjCfqTWfZHqfCI,460,200);WvZHbCVTxTJBCgjShmye(gui,STJWxPziEYTUCXKDJUXt,210,225);WvZHbCVTxTJBCgjShmye(gui,XYVQWIYoTDRwDEvFvLRl,290,225);WvZHbCVTxTJBCgjShmye(gui,xLabelAutoLogin,550,225);WvZHbCVTxTJBCgjShmye(gui,xLineAutoLogin,610,225);WvZHbCVTxTJBCgjShmye(gui,gozpOqzwkdOOYyJGLqvD,210,250);WvZHbCVTxTJBCgjShmye(gui,SUgmPoetsXniINKQOFwU,290,250);WvZHbCVTxTJBCgjShmye(gui,kIbzkKAAsoWGYcsauhnD,400,250);WvZHbCVTxTJBCgjShmye(gui,FCYMpBYVFqgQUFddJacy,460,250);WvZHbCVTxTJBCgjShmye(gui,SeOmTUjfMZLGTzvGKlTC,550,250);WvZHbCVTxTJBCgjShmye(gui,BsRXlRNuACCvLbvEBiOl,610,250)
	elif WXOlKzccVdGkHUjRXXsZ:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,175);WvZHbCVTxTJBCgjShmye(gui,zpDfPQpMqZobAypfHuoG,210,55);WvZHbCVTxTJBCgjShmye(gui,odSJOBwRiCpDqrqLQNEn,260,55);WvZHbCVTxTJBCgjShmye(gui,mmARntQLxJUgFHpKzyUb,350,55);WvZHbCVTxTJBCgjShmye(gui,iYmiIPndXGahrfGVXlqk,390,55);WvZHbCVTxTJBCgjShmye(gui,RETqPASxBRHGsQhcsHxu,600,52);WvZHbCVTxTJBCgjShmye(gui,VOVogadnyYomUcqqUuTq,201,75);WvZHbCVTxTJBCgjShmye(gui,JsfvmLYmBOKwhthzZVdS,203,85);WvZHbCVTxTJBCgjShmye(gui,byeeCwVMmGkQnWsezHsC,350,258)
	elif hxYJYDWvaFluRTTSJySH:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,205);WvZHbCVTxTJBCgjShmye(gui,MobawbrxDRLlGAwHwbBm,210,50);WvZHbCVTxTJBCgjShmye(gui,VOVogadnyYomUcqqUuTq,201,55);WvZHbCVTxTJBCgjShmye(gui,HKhYwBkIDVrnqeUltwfY,425,75);WvZHbCVTxTJBCgjShmye(gui,HvRSvcDSLbCRiOgaRaUM,395,90);WvZHbCVTxTJBCgjShmye(gui,plHnjHIANMeClSOOrqXV,220,75);WvZHbCVTxTJBCgjShmye(gui,tbJcVTSbxWdzpGZDIWDt,550,75);WvZHbCVTxTJBCgjShmye(gui,EnRasHJZGPFhEIUrktCg,202,90);WvZHbCVTxTJBCgjShmye(gui,nBgqVEqDCMMjiYhQoAKM,524,90);WvZHbCVTxTJBCgjShmye(gui,QUQdURaLIcsUtJkdnXup,405,140);WvZHbCVTxTJBCgjShmye(gui,dBVfgUPDejkiFzTnKJNw,405,180);WvZHbCVTxTJBCgjShmye(gui,xVQhBkSvnqyvefjxfXZc,405,220)
	elif bmxUIMLqLFjHPZiSfsMG:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,235);WvZHbCVTxTJBCgjShmye(gui,hrfRRqlCDgtKEzJCRaFI,210,55);WvZHbCVTxTJBCgjShmye(gui,BBjUOolVbwszJtAzJOTV,250,50);WvZHbCVTxTJBCgjShmye(gui,OeuGXwWrutRnWdXDphVC,400,50);WvZHbCVTxTJBCgjShmye(gui,AnDFaMnuwwNeSuSldYXS,550,50);WvZHbCVTxTJBCgjShmye(gui,VOVogadnyYomUcqqUuTq,201,65);WvZHbCVTxTJBCgjShmye(gui,GNACPvjcSHdRUdbxNaDP,210,85);WvZHbCVTxTJBCgjShmye(gui,telcEYudhoxjhlYfCUsl,400,85);WvZHbCVTxTJBCgjShmye(gui,ZzhUTDoUrppMAZhMHJwr,500,85);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,100)
	elif RKmDAbtczjVYieHRRdAI:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,265);WvZHbCVTxTJBCgjShmye(gui,odUMrFUWBNZPYZachzLw,210,60);WvZHbCVTxTJBCgjShmye(gui,JNPpSaBIOpHzWYkuBxiP,250,55);WvZHbCVTxTJBCgjShmye(gui,dfxrdENzgSgzCrqXZFpA,400,60);WvZHbCVTxTJBCgjShmye(gui,RYEABhDXNWqAJyqriCNF,440,55);WvZHbCVTxTJBCgjShmye(gui,kzVqGXInVrcHlodyQAUN,590,55);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,202,80);WvZHbCVTxTJBCgjShmye(gui,CXJhNKiaMrmvuLUdMHLj,250,100);WvZHbCVTxTJBCgjShmye(gui,puRQouCxsHsybkqTfbwZ,450,100);WvZHbCVTxTJBCgjShmye(gui,AWTVMRMRJHUYZCCBlLQy,250,130);WvZHbCVTxTJBCgjShmye(gui,OzTkCJKypeOsdJRXzkPK,450,130);WvZHbCVTxTJBCgjShmye(gui,ZGAdNwFfCWRTWAlpuWBs,201,150);WvZHbCVTxTJBCgjShmye(gui,XywKoKeVSHYqNrkBSDsl,250,170);WvZHbCVTxTJBCgjShmye(gui,vewjwwieCRTEKJAQncfm,250,200);WvZHbCVTxTJBCgjShmye(gui,ablvGKJpDdQyjOlLOzFM,450,170);WvZHbCVTxTJBCgjShmye(gui,mQYeOiiApEvVUAjTnbjv,450,200);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,220);WvZHbCVTxTJBCgjShmye(gui,uNEfTvmumqDmNoGKGcRP,210,240);WvZHbCVTxTJBCgjShmye(gui,aEuiYPZmxsJmcgXaywIn,210,260);WvZHbCVTxTJBCgjShmye(gui,CcIiURThQtAEMyocezTN,330,260);WvZHbCVTxTJBCgjShmye(gui,UJthKvHKGsvbfCydfPgC,580,260);wqxqzSYnxaWVUUkpHoAm()
	elif nMhZqiHrxCrOPNEdHeDX:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,115);WvZHbCVTxTJBCgjShmye(gui,PqZPYxmdZwpJzeCiTmeV,210,55);WvZHbCVTxTJBCgjShmye(gui,vTvJAPMuPyzCSAlLcQEL,270,55);WvZHbCVTxTJBCgjShmye(gui,AltklHJZyrkzUAkSVJbr,450,55);WvZHbCVTxTJBCgjShmye(gui,kHEAUrbHwTaadRzzUpfw,535,55);WvZHbCVTxTJBCgjShmye(gui,cykiSggZvutUxGUnlUwE,210,85);WvZHbCVTxTJBCgjShmye(gui,WGWBoKyuEMJZAXVodmer,270,85);WvZHbCVTxTJBCgjShmye(gui,SfFwyqWaDwIHEtjtsTve,535,85);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,100);WvZHbCVTxTJBCgjShmye(gui,OVoqSNhfCDplPAJijZZK,250,120);WvZHbCVTxTJBCgjShmye(gui,uwdOkMzrjBQcdQFqjuuS,400,260)
	elif gtlsRcKNLeroyQSrGAWI:LFtezZvuEYrzeZvbyQGe();wqxqzSYnxaWVUUkpHoAm()
	elif dltpVDzRJuNUOeKNWlZO:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,175);WvZHbCVTxTJBCgjShmye(gui,GnMRPkZkhFxOrZQTNPqd,210,100);WvZHbCVTxTJBCgjShmye(gui,BtbfyPCeNcOYsuCeuzSw,210,120);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,80);WvZHbCVTxTJBCgjShmye(gui,dqlCIEbSJqZzHGQoaSfc,400,100);WvZHbCVTxTJBCgjShmye(gui,qRdGTWYOHFcqrWNSnXsP,400,120);WvZHbCVTxTJBCgjShmye(gui,KOdeNnWVgFswgyUoYsAE,550,120);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,140);WvZHbCVTxTJBCgjShmye(gui,vWyvYNTYjZRuynFBGTCU,210,170);WvZHbCVTxTJBCgjShmye(gui,YfwxOORIdeShJnMauMvO,210,200);WvZHbCVTxTJBCgjShmye(gui,gwvwFLANPZdpctwEWZcS,330,200);WvZHbCVTxTJBCgjShmye(gui,EaFryNTbffMeUaBgeSTK,210,240);WvZHbCVTxTJBCgjShmye(gui,WmlLNGJVNwLLDyVNhAQy,330,240);WvZHbCVTxTJBCgjShmye(gui,caNTgPwifyXJjKMxRYFY,480,240)
	elif CyIvXRCscUQUzKzKgvtX:OLmUzKPhMAzZSdFwcLSe();wqxqzSYnxaWVUUkpHoAm()
	elif XHutdYTebhNytzkxsqHB:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,235);WvZHbCVTxTJBCgjShmye(gui,RglArglccJJVkKnSTgxr,210,55);WvZHbCVTxTJBCgjShmye(gui,zoMICLUzgkgOQyDHCPsf,210,75);WvZHbCVTxTJBCgjShmye(gui,KYycPyTxSSkxhNQevXtf,490,50);WvZHbCVTxTJBCgjShmye(gui,zKRnvtnfWvISrXUwaMsK,350,55);WvZHbCVTxTJBCgjShmye(gui,jGjYOVhJaXCWJgrRkXBs,350,75);WvZHbCVTxTJBCgjShmye(gui,aTqawvpLbjcFuJQLRUcN,600,50);WvZHbCVTxTJBCgjShmye(gui,bdJLXHCAtzCjRBBxKPwr,490,75);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,95);wqxqzSYnxaWVUUkpHoAm()
	elif AikJGYbVxICEhnCEmMtM:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,265);WvZHbCVTxTJBCgjShmye(gui,JRRIoawLWKiRPsglMIei,210,55);WvZHbCVTxTJBCgjShmye(gui,okrzVlfAykyiQMtGCliZ,210,75);WvZHbCVTxTJBCgjShmye(gui,ZUYvYrvNAKQWogrGLzJf,490,50);WvZHbCVTxTJBCgjShmye(gui,UkzJDWaHTXeTeLwCZiAP,350,75);WvZHbCVTxTJBCgjShmye(gui,LfMfuuUVsewlnmxhfOnw,350,55);WvZHbCVTxTJBCgjShmye(gui,LzcCmLbLidQhONENsKLr,600,50);WvZHbCVTxTJBCgjShmye(gui,YLcSVnCSTHZjCFlltrnD,490,75);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,95);wqxqzSYnxaWVUUkpHoAm()
	elif nmoMZqJalmdpGvQlvcFN:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,85);WvZHbCVTxTJBCgjShmye(gui,MQgXEHAiouCmhiegvKSP,210,55);WvZHbCVTxTJBCgjShmye(gui,qeXpNIYMibteftHLjPGv,210,75);WvZHbCVTxTJBCgjShmye(gui,YpVacNrGcyWllzeHEjfV,350,55);WvZHbCVTxTJBCgjShmye(gui,DloQAPkbAFvsWHtXKQnT,350,75);WvZHbCVTxTJBCgjShmye(gui,HslWWZxlSKsKUmFKXSJl,500,50);WvZHbCVTxTJBCgjShmye(gui,IBFCtvjRlDoprxNRvLqn,500,75);WvZHbCVTxTJBCgjShmye(gui,pwIcWppRrmipUWGWeMYK,600,50);WvZHbCVTxTJBCgjShmye(gui,UjsCERByfVIARjIoPvfp,600,75);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,90)
	elif xBuyF10Var:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,85);WvZHbCVTxTJBCgjShmye(gui,FnrHhZocsHkYJWteJqKt,210,55);WvZHbCVTxTJBCgjShmye(gui,viEDPlfMTniBwXCFMjKb,210,75);WvZHbCVTxTJBCgjShmye(gui,VbVSBQTqePXzoVwpUiQm,490,50);WvZHbCVTxTJBCgjShmye(gui,FHiihcDteaNbnvlnioXs,350,75);WvZHbCVTxTJBCgjShmye(gui,ADGxjZwXdDKjfsTVmsJY,350,55);WvZHbCVTxTJBCgjShmye(gui,dMcCNRIIctjHrEJiGOBG,600,50);WvZHbCVTxTJBCgjShmye(gui,kBINHWjHmIUqbinvQybt,490,75);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,95);WvZHbCVTxTJBCgjShmye(gui,RNlHJwzCfwHMHAssLcuM,210,120);WvZHbCVTxTJBCgjShmye(gui,UPruSejFNfznfEbNuGbk,395,115);WvZHbCVTxTJBCgjShmye(gui,BDvULMWHKEFTPBRfvzkd,500,120);WvZHbCVTxTJBCgjShmye(gui,jUBnWgbKtMHlmKrNQfQO,600,120);WvZHbCVTxTJBCgjShmye(gui,wcPxcWRXcigrQwkplDDo,210,145);WvZHbCVTxTJBCgjShmye(gui,IyNDuGraslfIZDgwBrkM,500,145);WvZHbCVTxTJBCgjShmye(gui,IMmIthmLIYmpcjvWkdEB,600,145);WvZHbCVTxTJBCgjShmye(gui,GppLLXrLmQhCuXhdxShl,210,175);WvZHbCVTxTJBCgjShmye(gui,ZnNmoYlQaYBViYyybPiM,500,175);WvZHbCVTxTJBCgjShmye(gui,BzcfrdidXLLPeaZKFEfY,600,175);WvZHbCVTxTJBCgjShmye(gui,VdunfnMGuQDmiYrhJqnj,201,200);WvZHbCVTxTJBCgjShmye(gui,EycwjCvtwipdkyIpBgHf,210,225);WvZHbCVTxTJBCgjShmye(gui,fMHConstndliwMODiJyw,400,225);WvZHbCVTxTJBCgjShmye(gui,xCheckboxNotifyBuyF10,600,225);WvZHbCVTxTJBCgjShmye(gui,ZGAdNwFfCWRTWAlpuWBs,201,240);WvZHbCVTxTJBCgjShmye(gui,yDskoFdWOJAXmnPHYebJ,210,265);WvZHbCVTxTJBCgjShmye(gui,rnzCACbSNTyQrlDumNjs,290,260);WvZHbCVTxTJBCgjShmye(gui,kwwOSWNYIgaiXsWEWpMb,440,265);WvZHbCVTxTJBCgjShmye(gui,urItYGeSPfpVoTNCDHaj,540,261);WvZHbCVTxTJBCgjShmye(gui,VlIjBmBwakfdrxElwVbg,600,260);taracIImTdaeahuJljox();FBDleWFBsQRLSQFIiGAE();qjbXQXJWLiCUIxWLiVfZ()
	elif xChangePtVar:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,110);WvZHbCVTxTJBCgjShmye(gui,SZyEmvdUsZOGUIwyIjyI,210,55);WvZHbCVTxTJBCgjShmye(gui,YuizTbgHycWBzpsQpCFS,210,75);WvZHbCVTxTJBCgjShmye(gui,KpsNtyltAwFgtWHQfVsJ,490,50);WvZHbCVTxTJBCgjShmye(gui,nxUovqYpcySMZrrvZyXD,350,55);WvZHbCVTxTJBCgjShmye(gui,ivsYhoRNplrmzwVrFtTz,350,75);WvZHbCVTxTJBCgjShmye(gui,RDVHwMaLLvSiXvKhfTXV,600,50);WvZHbCVTxTJBCgjShmye(gui,fLkYnmuWDtlmtiDmrToF,490,75);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,95);TdiaNtumFPYrSGLLINan();ZsakXHqqtnBRTBKTKzhq();KyMTfckCniYQMCrnFmAF()
	elif ASKmopOSSsyBceSyeaqq:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,140);uNkFVhJxPexBuPOgeFqp()
	elif ATQXujoMxxZtrVjfMcKz:WvZHbCVTxTJBCgjShmye(gui,icdWsWoPIKjNbjLqEZjz,165,170);WvZHbCVTxTJBCgjShmye(gui,mdsgHxsyJwTLdoCHjkWv,210,55);WvZHbCVTxTJBCgjShmye(gui,fNLHihvlAplBnwwOHmoz,210,75);WvZHbCVTxTJBCgjShmye(gui,fhHQRTwCbVXrrFAcCbZf,490,50);WvZHbCVTxTJBCgjShmye(gui,ZIYBPYIItTunbqtCYDnq,350,75);WvZHbCVTxTJBCgjShmye(gui,cMPwjyyceVvOeQWouWiB,350,55);WvZHbCVTxTJBCgjShmye(gui,vVOmlHBnHgIEEnnMSTpW,600,50);WvZHbCVTxTJBCgjShmye(gui,fZBJVJiqvCqbXuVZibUf,490,75);WvZHbCVTxTJBCgjShmye(gui,YByJftUWNhdabggdxFlm,201,93);XOujawntPsoIbuXqxpGK();HjDrZmbhwRcwJJYrroYE();NdHzqvtFmuJWCvLkOTDw()
def BoYsDyWfwdLtybunWpSO():
	WraIALrPVutsDneXMsCv()
	if ClKpoayHpwwSviKZagfc:
		for widget in(CYKrgfiKgkhVlCJxqzGw,eppXpjnTqxMPHpFKCfsK,fOWIyDNVHgiEGwrStpPX,ToPQCoIfNiwtIuiRtmZK,yJATnvnBuSJSkcIrbajr,EwrTknRthJdiVOdNRCJf,rnWkPCjfVbsZkvZDBZmJ,jdvWfgFqbdKqWrqBvcfR,JWmayNaPnbnduOjFLtlH,roIyFiuCYvLeXobAwWni):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif ChfcAMsGCyHQvoqTAIuZ:
		for widget in(FGyktaHapXwfXhvZlbTf,lxQtTBRLIxPeeibjVimW,VOVogadnyYomUcqqUuTq,qFephjHXtxbXKXKokOgA,gtHoDVJzKSVwQNScpbWZ,vpvKqXMfbfITdKmfiXin,OTjBHMLqRODpyNxHLiXw,OOdqGfaMpHYqlnUQFaiX,kQMjbvwmYtwxebdEijwt,YByJftUWNhdabggdxFlm,LACdoUaoitphWphaFlqU,CqythJGjfWTXuxMKcyoH,WkMmMflZOgRIFwrlMkFc,tGIHLOycDmpRhZOXCLIJ,smIzvHJtsPgVjJdEXUXc,ZbSlFPfNCDjTwbTmRZoc,mnpRsxxDXoNWCIcrhxUb,vaOEZlzwNtKLFlnuVATY,vvJygwgturAXxiJlvAVe,uCyzhgqqsDjxCbgBbZHD,OYveQLGpEmYOWEoTWiJS,UnjehnwwmwRKXxGOxhry,IbEdwamajTPcuygjSLxt,YUgyEkTwWeJKninmvaOv,XjSTEFrFGZcIwXpWHkaz,vRwfvWsWvsIwoHimeBri,iLwFRDzcisapgKAzjUwr,vejetvcRmXXwJxxMAAjh,PluHgJfTgYNCTcHRwcKP,UFIeOKAidjhZXKYvzMgX,RVDtlAkbmMlKCIJWHajp,PZswfQcHILPfuidyehUo,lnmGOcGnrtsyIAEzboJy,ITlfbgHDiifjFniuIuMU,MupsMnhlAKkpRpEtMhCO,thzEwAUoCljdFruEjWmN,FlwZKQoKMlvhPAMIfvwS,uscozwxJjhheGOXHuIRf,aXopVQWCAJszlgSFGvWn,wgwMPmKkbXisxqsqvMLx):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif lXFpjJHIhLCAKxStdIIN:
		for widget in(FKxqfELWGyhlGnEeOhPo,DwJAmngnYKprYHTXZwIH,VOVogadnyYomUcqqUuTq,AareDXiMMvavpdjJCjEb,iHqLOvJrHUqbodjlTOKM,vpvKqXMfbfITdKmfiXin,OTjBHMLqRODpyNxHLiXw,OOdqGfaMpHYqlnUQFaiX,kQMjbvwmYtwxebdEijwt,YByJftUWNhdabggdxFlm,rTUveHsFjTdNdOCapOgJ,kEyFZGwfHGFxilWEorHG,kOCmTwqGpUUeWgpmOffZ,lHielohtlBApnFHhjgbe,xjQgmArshGxHLADAtZDM,ZdpAASRyfxQVNKXTvDlb,FFVPfPYMjImEAgLQWilF,tCNMmYYzsCliwIIuqxMA,iVwQHksjIeBjqqQYPPNB,WOkwTlhWLluNPfNfwSpE,lIGFmAhfPwJKMVIZqdJF,EcXJOXCZeFQLIiljCGuG,cTXvIKjtxVVYEKCpamwX,BCoWqKkvUWRvTmvbQkTe,ilgTepDVGsLKEEIVHrnu,nJhVIBPuIenJJObDvvjZ,VcpVmwjQXxcMlrXYTszB,TfTDLyLjCfqTWfZHqfCI,EVDNyGgQwbdTJQcvRIAg,ezmeCRPxtMSzhhlUldaV,ogZxZJWFpSAfBFbuxsQk,IFuPxNcrNBJZyytEOAnj,HJVLdCYpyPREIwbBAdRQ,VGIboPCATIoBNYGGgcVW,STninBTkmZJRTzMnWELG,xLabelAutoLogin,STJWxPziEYTUCXKDJUXt,xLineAutoLogin,XYVQWIYoTDRwDEvFvLRl,SUgmPoetsXniINKQOFwU,FCYMpBYVFqgQUFddJacy,kIbzkKAAsoWGYcsauhnD,gozpOqzwkdOOYyJGLqvD,mKxlNlGsUzVfBXmzFtQS,BsRXlRNuACCvLbvEBiOl,SeOmTUjfMZLGTzvGKlTC):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif WXOlKzccVdGkHUjRXXsZ:
		for widget in(zpDfPQpMqZobAypfHuoG,odSJOBwRiCpDqrqLQNEn,mmARntQLxJUgFHpKzyUb,iYmiIPndXGahrfGVXlqk,RETqPASxBRHGsQhcsHxu,VOVogadnyYomUcqqUuTq,JsfvmLYmBOKwhthzZVdS,byeeCwVMmGkQnWsezHsC):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif hxYJYDWvaFluRTTSJySH:
		for widget in(MobawbrxDRLlGAwHwbBm,VOVogadnyYomUcqqUuTq,HKhYwBkIDVrnqeUltwfY,HvRSvcDSLbCRiOgaRaUM,plHnjHIANMeClSOOrqXV,tbJcVTSbxWdzpGZDIWDt,EnRasHJZGPFhEIUrktCg,nBgqVEqDCMMjiYhQoAKM,QUQdURaLIcsUtJkdnXup,dBVfgUPDejkiFzTnKJNw,xVQhBkSvnqyvefjxfXZc):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif bmxUIMLqLFjHPZiSfsMG:
		for widget in(icdWsWoPIKjNbjLqEZjz,hrfRRqlCDgtKEzJCRaFI,BBjUOolVbwszJtAzJOTV,OeuGXwWrutRnWdXDphVC,AnDFaMnuwwNeSuSldYXS,VOVogadnyYomUcqqUuTq,YByJftUWNhdabggdxFlm,ZzhUTDoUrppMAZhMHJwr,telcEYudhoxjhlYfCUsl,GNACPvjcSHdRUdbxNaDP,JOwmBODCRnwRhbngijue,LfzlKLInRNfozmyvrQwm):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
		dhkSeyhSvaoSeMaiVJLO();aPVJNjqZPdWNERGxkSvw()
	elif RKmDAbtczjVYieHRRdAI:
		for widget in(icdWsWoPIKjNbjLqEZjz,odUMrFUWBNZPYZachzLw,JNPpSaBIOpHzWYkuBxiP,dfxrdENzgSgzCrqXZFpA,RYEABhDXNWqAJyqriCNF,kzVqGXInVrcHlodyQAUN,YByJftUWNhdabggdxFlm,VdunfnMGuQDmiYrhJqnj,CXJhNKiaMrmvuLUdMHLj,puRQouCxsHsybkqTfbwZ,vewjwwieCRTEKJAQncfm,OzTkCJKypeOsdJRXzkPK,AWTVMRMRJHUYZCCBlLQy,XywKoKeVSHYqNrkBSDsl,uNEfTvmumqDmNoGKGcRP,aEuiYPZmxsJmcgXaywIn,ZGAdNwFfCWRTWAlpuWBs,ablvGKJpDdQyjOlLOzFM,mQYeOiiApEvVUAjTnbjv,CcIiURThQtAEMyocezTN,UJthKvHKGsvbfCydfPgC):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif nMhZqiHrxCrOPNEdHeDX:
		for widget in(icdWsWoPIKjNbjLqEZjz,PqZPYxmdZwpJzeCiTmeV,vTvJAPMuPyzCSAlLcQEL,AltklHJZyrkzUAkSVJbr,kHEAUrbHwTaadRzzUpfw,cykiSggZvutUxGUnlUwE,WGWBoKyuEMJZAXVodmer,SfFwyqWaDwIHEtjtsTve,YByJftUWNhdabggdxFlm,OVoqSNhfCDplPAJijZZK,uwdOkMzrjBQcdQFqjuuS):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif gtlsRcKNLeroyQSrGAWI:
		for widget in(icdWsWoPIKjNbjLqEZjz,mgowRmhINieSpmMmeWMO,BlRnlERUmLsluJLUECGJ,rUVEsIIVUfjekONEyVEP,ZNkEbuWFgYMbxXlMwrZj,cgaZXmkFmRBykQZeUZAa,GkWkMgGIIehMPXbNwYLA,ikydHWmMpBLUdSIOGlvK,duvPBMyXxHopmneSLHOL,CVHMQMQlPRMTCJRrBqKI,YByJftUWNhdabggdxFlm,VdunfnMGuQDmiYrhJqnj,BAUKrYkcpwFWrPcoiLmN):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif dltpVDzRJuNUOeKNWlZO:
		for widget in(icdWsWoPIKjNbjLqEZjz,GnMRPkZkhFxOrZQTNPqd,BtbfyPCeNcOYsuCeuzSw,KOdeNnWVgFswgyUoYsAE,YByJftUWNhdabggdxFlm,VdunfnMGuQDmiYrhJqnj,dqlCIEbSJqZzHGQoaSfc,qRdGTWYOHFcqrWNSnXsP,vWyvYNTYjZRuynFBGTCU,YfwxOORIdeShJnMauMvO,gwvwFLANPZdpctwEWZcS,EaFryNTbffMeUaBgeSTK,WmlLNGJVNwLLDyVNhAQy,caNTgPwifyXJjKMxRYFY,ZGAdNwFfCWRTWAlpuWBs):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif CyIvXRCscUQUzKzKgvtX:
		for widget in(icdWsWoPIKjNbjLqEZjz,paELWPlmycLljpeNQUZj,WuXhwEFIEohufmZUxgjj,DXLEakCOKoppFIVyWyvD,lhuFqKwfevOIMzWLQOeP,ABaMGGUGVgkMSOCtDUWe,xtuagfOeVqSYhTpcdZiW,lGBQRLBXffAIHdxXVSYJ,WUfTqRfilBcWmSCtYnAn,ErnivciwFJYymTCBbJBR,YByJftUWNhdabggdxFlm,VdunfnMGuQDmiYrhJqnj,kePvZTxfDGhuaYESZUsa,JtFAKYwfIUrhvIwgyRRq,hoNasCNqyGMtchYPJQEp,ScKiNoagbHNcgOLZTVdl,MiRHljGgsnxqjYQFfVTq,WfOcwmECUeINZeCNdtwB,zbhvdlVsAXfbOSqTABmU,qIwTCEJInMETihfCcCYj,JDKzUOgiBIFImtbIyFup,QBXulHlQUJUheqdMJtXM,ldNVjfcUprgCAoZASMvK,FrWAyKuxtqkghGMICYdV):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif XHutdYTebhNytzkxsqHB:
		for widget in(scRRktjODHghRvCupJJt,JVGHTSlctEFxZKAJWNBz,cUSTjmqyCAgMNOFvRqFy,uKzTznnvntFtBDNHaUoD,FaPpEVCioitqXHTOIiOs,icdWsWoPIKjNbjLqEZjz,RglArglccJJVkKnSTgxr,zoMICLUzgkgOQyDHCPsf,KYycPyTxSSkxhNQevXtf,zKRnvtnfWvISrXUwaMsK,jGjYOVhJaXCWJgrRkXBs,aTqawvpLbjcFuJQLRUcN,bdJLXHCAtzCjRBBxKPwr,YByJftUWNhdabggdxFlm,VdunfnMGuQDmiYrhJqnj,GFOtzraUCjUMayLwUAMo,qRZTSYysZEdrwynUnDWb,ncjFUlFpNXZXWOMsqDhz,clKOznvQpRcxBHpwSVVz,xCheckAudioGhost,zcEfuyrsPqlEHxLvkNHA,rqgLROQglXtqpburmEtj,uuBVEYiwPIGGyPmiReVm,gCoQauneWgYneDxakLdU,AjnQmXRAOlzKNzmliVED,pMiuAEqIjBvGVwSmOqbV,MlvCpjqmgVwZfjuloUSN,bVQNJaKfHHilGzXwzzSz,FNvfmSrgQZzkDaCteqCm,rXNJnPxOEphrAujPcOJz,kfDcvJsHrxudYljVdKKw,aJPscppptvaHgRrGBAvv):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif nmoMZqJalmdpGvQlvcFN:
		for widget in(icdWsWoPIKjNbjLqEZjz,MQgXEHAiouCmhiegvKSP,qeXpNIYMibteftHLjPGv,YpVacNrGcyWllzeHEjfV,DloQAPkbAFvsWHtXKQnT,HslWWZxlSKsKUmFKXSJl,IBFCtvjRlDoprxNRvLqn,pwIcWppRrmipUWGWeMYK,UjsCERByfVIARjIoPvfp,YByJftUWNhdabggdxFlm):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
		ivIuoZFbuOvrszZFgCtN();JPvYTWZxMZbMgRQpVbPe()
	elif AikJGYbVxICEhnCEmMtM:
		for widget in(icdWsWoPIKjNbjLqEZjz,JRRIoawLWKiRPsglMIei,okrzVlfAykyiQMtGCliZ,ZUYvYrvNAKQWogrGLzJf,UkzJDWaHTXeTeLwCZiAP,LfMfuuUVsewlnmxhfOnw,bSJTNaKWzgTAGtDdAuYJ,vpWmKBBTEflJNDZcdaCu,LzcCmLbLidQhONENsKLr,YLcSVnCSTHZjCFlltrnD,YByJftUWNhdabggdxFlm):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
		MUnPGGlhXdfHMyxkuhCL();NJRKYzxOXQpdoqPvnQcZ();TpREhcnoiUhuwfwwMuAr()
	elif xBuyF10Var:
		for widget in(icdWsWoPIKjNbjLqEZjz,FnrHhZocsHkYJWteJqKt,viEDPlfMTniBwXCFMjKb,VbVSBQTqePXzoVwpUiQm,FHiihcDteaNbnvlnioXs,ADGxjZwXdDKjfsTVmsJY,dMcCNRIIctjHrEJiGOBG,kBINHWjHmIUqbinvQybt,YByJftUWNhdabggdxFlm,RNlHJwzCfwHMHAssLcuM,BDvULMWHKEFTPBRfvzkd,jUBnWgbKtMHlmKrNQfQO,wcPxcWRXcigrQwkplDDo,IyNDuGraslfIZDgwBrkM,UPruSejFNfznfEbNuGbk,IMmIthmLIYmpcjvWkdEB,GppLLXrLmQhCuXhdxShl,ZnNmoYlQaYBViYyybPiM,BzcfrdidXLLPeaZKFEfY,VdunfnMGuQDmiYrhJqnj,yDskoFdWOJAXmnPHYebJ,EycwjCvtwipdkyIpBgHf,fMHConstndliwMODiJyw,ZGAdNwFfCWRTWAlpuWBs,gGQWDPsKtZMXFnbMusDg,ZchCyBnnGCkhwEDbMBWi,cYtPjLEsLVVEkREiYVCd,FYSUaVzvPDqlxfnMxZYf,kwwOSWNYIgaiXsWEWpMb,urItYGeSPfpVoTNCDHaj,VlIjBmBwakfdrxElwVbg,xCheckboxNotifyBuyF10,rnzCACbSNTyQrlDumNjs):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif xChangePtVar:
		for widget in(icdWsWoPIKjNbjLqEZjz,SZyEmvdUsZOGUIwyIjyI,YuizTbgHycWBzpsQpCFS,KpsNtyltAwFgtWHQfVsJ,nxUovqYpcySMZrrvZyXD,ivsYhoRNplrmzwVrFtTz,RDVHwMaLLvSiXvKhfTXV,fLkYnmuWDtlmtiDmrToF,YByJftUWNhdabggdxFlm,TDEEQgyJDYqiKGZCgXCs,ZtaMictDBePSndQArJXv,kryPPFDEdgDuetwsdHXp,VdunfnMGuQDmiYrhJqnj,jYtGuqcwlzDdYRFEoqDA,UKmDimKpTLtAKzwIxEFC,NnrBSwCOHwqebcyIgNPb,SzdAcfgNWPtwJHRkJCep,vaKkieOApRNShuIaTvtw,bbfPlczPUiCJVRXfIaBY,bEdDsnbBcqLbMuXRNSog,EAedRvLFWROljcynLYLw,ijnOrKqrycBMswPhjApk,pgGvGNIcaBYKFkCkHDKe,eZGjFIHCIXJDFITZSUvb,ZGAdNwFfCWRTWAlpuWBs,NshhSQubaXWrRicudFDI,NuXhsxQUugRrQxaDUrBh,RPPInSsbGxPhyOvtMgVW,ebeZukBdFvozSdyrqobm,UbleoaYmDtuPgHtVQONt,xemYmovAxWFBvjbStiUN,EbTGYSJSfuzHLzxGjhcK):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
	elif ASKmopOSSsyBceSyeaqq:
		for widget in(icdWsWoPIKjNbjLqEZjz,):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
		vLUXUaFHPAOQhPFIWfwK()
	elif ATQXujoMxxZtrVjfMcKz:
		for widget in(icdWsWoPIKjNbjLqEZjz,mdsgHxsyJwTLdoCHjkWv,fNLHihvlAplBnwwOHmoz,fhHQRTwCbVXrrFAcCbZf,ZIYBPYIItTunbqtCYDnq,cMPwjyyceVvOeQWouWiB,vVOmlHBnHgIEEnnMSTpW,fZBJVJiqvCqbXuVZibUf,YByJftUWNhdabggdxFlm,lPKWOaDounzzeCOoUSeT,WPLyUxShHPzjBnSjRCMy):WvZHbCVTxTJBCgjShmye(gui,widget,X,Y)
		LGOBobjyifkoieVgkczS();qAilHclPdWbfDRQWfSpd()
def avEFUdeooQUGYdkMPHZK():JWuzgwGSZByJBrEJMhmB();uTjWQRuHkfUwHqUKBXer(gui,jEHwoYvtOlbVjNhLKYti,NweMXVypQZSXaVSCagqM(1));uTjWQRuHkfUwHqUKBXer(gui,evOwxJrsOZvaGUYoKqpb,NweMXVypQZSXaVSCagqM(2));uTjWQRuHkfUwHqUKBXer(gui,ooGleuELUDeaUvBNvXLk,NweMXVypQZSXaVSCagqM(3));uTjWQRuHkfUwHqUKBXer(gui,gWdKbUSpeAxLBsFpKEoh,NweMXVypQZSXaVSCagqM(4));uTjWQRuHkfUwHqUKBXer(gui,uxEEKQBahJEZmcaIYvwz,NweMXVypQZSXaVSCagqM(5));uTjWQRuHkfUwHqUKBXer(gui,TQIGWOCWIwQiiaAiZuoh,NweMXVypQZSXaVSCagqM(6));uTjWQRuHkfUwHqUKBXer(gui,eOtvjPpLCvYJLAcmGmWE,NweMXVypQZSXaVSCagqM(7));uTjWQRuHkfUwHqUKBXer(gui,RXLhvOUUgCoAWtoSabHd,NweMXVypQZSXaVSCagqM(8));uTjWQRuHkfUwHqUKBXer(gui,LABGrwxIiQmJiCamnppg,NweMXVypQZSXaVSCagqM(9));uTjWQRuHkfUwHqUKBXer(gui,UadeXYTTjsnHZgbjglBF,NweMXVypQZSXaVSCagqM(10));uTjWQRuHkfUwHqUKBXer(gui,UOeyomueyHdkSVmrxcuU,NweMXVypQZSXaVSCagqM(11));uTjWQRuHkfUwHqUKBXer(gui,pOqhqjahTChffUmvYNpV,NweMXVypQZSXaVSCagqM(23));uTjWQRuHkfUwHqUKBXer(gui,LRpdqDEzxIiYuvRgmPQv,NweMXVypQZSXaVSCagqM(24));uTjWQRuHkfUwHqUKBXer(gui,ueRlwYOgYMOANNGltjlM,NweMXVypQZSXaVSCagqM(25));uTjWQRuHkfUwHqUKBXer(gui,rLUdvylZXYXGFgnnQxpR,NweMXVypQZSXaVSCagqM(26));uTjWQRuHkfUwHqUKBXer(gui,ynMQpjqQNdICJcJRoSKz,NweMXVypQZSXaVSCagqM(27));uTjWQRuHkfUwHqUKBXer(gui,JETeNgvirUhkMZGnFCCC,NweMXVypQZSXaVSCagqM(29));JqlwazDWdIKTLEtZbZHC()
EAplcpwiPpKEeeMjzzDD=sNOKqVOQPcbIohrgrUAk(gui,_A2,8,40)
umFFoiLMuFUDhyWXrvkv=sNOKqVOQPcbIohrgrUAk(gui,_A2,200,40)
vZOfCtSGYtFfTueAGbuL=sNOKqVOQPcbIohrgrUAk(gui,_A2,700,40)
IEarKXUWrEZIVZrNiQDk=sNOKqVOQPcbIohrgrUAk(gui,_A2,8,44)
nwjFTFTSBiBBHFMfAmfw=sNOKqVOQPcbIohrgrUAk(gui,_A2,200,44)
apDcNmGJlngksQdDPbjG=sNOKqVOQPcbIohrgrUAk(gui,_A2,700,44)
dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(22,hhtizdLRxJDclVvtcTSo,UIydKLjzCkrJuheHwDpg))