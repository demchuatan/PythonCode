_O='skills'
_N='dataweapon'
_M='script'
_L='Bolt'
_K='Arrow'
_J='region'
_I='items'
_H='shield'
_G='chars'
_F='f10'
_E='ghost'
_D='guard'
_C=None
_B='plus'
_A='name'
import os,sys,struct
from _lib.silkroad import*
hhtizdLRxJDclVvtcTSo='ChatControlExe'
OlFpZxSIOWOxoYIYEJhM=_C
HAQnRCeWwRuHgewVpRFe=_C
MWRfbVIvTugnvscXQAvD=_C
gFEhxLTdYeImBHOEYSOO=''
cLXZAwUYGNoOkGSFtRts=''
xMove=''
bEmgkhtGIusXZcCsEOHL=''
vbaYnrXctBUtzKeHUekn=''
EuEdCvBryetSakQDfJoN=''
TzGfRvgrVpiZseBbBgOT=''
zDEWVgxGJymItqKKonhT=''
aLpLZUAiztgiNlbBLCzH=''
FSCYAmNGBJnxwSALzBkf=''
lqXHDuOYgXYhetBgCYsz=''
ckJIWmQSnmQYUfalCxXp=''
IjYAzllkkygppwgdByaD=''
ElypdqSIokBODDbkkScM=''
yjBSkKWrTZmjTyrBctgP=''
KwsJDRkruEQWSjwNQkeT=''
lpFkDOCHWxiihBxJHkmz=''
ZWisUXTeWLjUCupXfSzP=''
iuknGWUHTtEqnnSStIXm=''
xSet=''
AbCRsrMuzGxreICrQGgI=''
WjBVKnXPdeFTVaHDVftO=''
kgWljzpKAMtyWUyNYEyk=''
SlHxcnvFvRyrfsfotwQX=''
BBDGSqFTNcBMWBZPaDdb=''
smidgIeqAzkDjJRUzNyj=''
CNxmwNCwrqErSfzMvDVY=''
FasrOhIrfhkYEpusGVEa=''
fSWVsmRGkFLtgVXUYZqC=''
ARXFaXmGEtGWzkHnGXuH=''
VdwlNYpiyXLOoaMLtcSB=''
aMRSrqVNGeyGaEIMZNPx=''
oTFBetyFBvHupyfAGClV=''
gowFonKJmlgklDDIRFtD=''
FITlKWsCUeQSZIZohXrt=''
wudDpovLQHsjqfrcjGOM=''
URjGqjCDmYoJHDHaXTew=''
BdlumdijWsfizfBgABDI=''
LrcdbgmrKtvhinzLigCG=''
FUtXcwxZVoNABGdDRGxr=''
fMxpbUFLfvgzdvCEvtBf=''
VMxpbULFfvgzdveCvtBf=''
def reload():F='code';E='members';D='control';C='movecommand';B='setcommand';A='types';global OlFpZxSIOWOxoYIYEJhM,xEnglish,HAQnRCeWwRuHgewVpRFe,MWRfbVIvTugnvscXQAvD,gFEhxLTdYeImBHOEYSOO,cLXZAwUYGNoOkGSFtRts,xMove,bEmgkhtGIusXZcCsEOHL,vbaYnrXctBUtzKeHUekn,EuEdCvBryetSakQDfJoN;global TzGfRvgrVpiZseBbBgOT,zDEWVgxGJymItqKKonhT,aLpLZUAiztgiNlbBLCzH,aLpLZUAiztgiNlbBLCzH,FSCYAmNGBJnxwSALzBkf,lqXHDuOYgXYhetBgCYsz,ckJIWmQSnmQYUfalCxXp,IjYAzllkkygppwgdByaD;global ElypdqSIokBODDbkkScM,KwsJDRkruEQWSjwNQkeT,lpFkDOCHWxiihBxJHkmz,ZWisUXTeWLjUCupXfSzP,iuknGWUHTtEqnnSStIXm,yjBSkKWrTZmjTyrBctgP;global xSet,AbCRsrMuzGxreICrQGgI,WjBVKnXPdeFTVaHDVftO,kgWljzpKAMtyWUyNYEyk,SlHxcnvFvRyrfsfotwQX,BBDGSqFTNcBMWBZPaDdb,smidgIeqAzkDjJRUzNyj,FasrOhIrfhkYEpusGVEa,fSWVsmRGkFLtgVXUYZqC,URjGqjCDmYoJHDHaXTew;global ARXFaXmGEtGWzkHnGXuH,aMRSrqVNGeyGaEIMZNPx,oTFBetyFBvHupyfAGClV,FITlKWsCUeQSZIZohXrt,gowFonKJmlgklDDIRFtD,wudDpovLQHsjqfrcjGOM,CNxmwNCwrqErSfzMvDVY,VdwlNYpiyXLOoaMLtcSB,BdlumdijWsfizfBgABDI;global LrcdbgmrKtvhinzLigCG,FUtXcwxZVoNABGdDRGxr,fMxpbUFLfvgzdvCEvtBf,VMxpbULFfvgzdveCvtBf;OlFpZxSIOWOxoYIYEJhM=TR098hhadfveaaaaNm2Jwywg();xEnglish=MmzIXEdZSRjOAAIYlWJF();HAQnRCeWwRuHgewVpRFe=OlFpZxSIOWOxoYIYEJhM[D]['guilds'];MWRfbVIvTugnvscXQAvD=OlFpZxSIOWOxoYIYEJhM[D]['players'];gFEhxLTdYeImBHOEYSOO=OlFpZxSIOWOxoYIYEJhM[E]['justme'];cLXZAwUYGNoOkGSFtRts=OlFpZxSIOWOxoYIYEJhM[E]['notme'];xMove=OlFpZxSIOWOxoYIYEJhM[C][F];bEmgkhtGIusXZcCsEOHL=OlFpZxSIOWOxoYIYEJhM[C][A]['home'];vbaYnrXctBUtzKeHUekn=OlFpZxSIOWOxoYIYEJhM[C][A]['last'];EuEdCvBryetSakQDfJoN=OlFpZxSIOWOxoYIYEJhM[C][A]['dead'];TzGfRvgrVpiZseBbBgOT=OlFpZxSIOWOxoYIYEJhM[C][A]['party'];zDEWVgxGJymItqKKonhT=OlFpZxSIOWOxoYIYEJhM[C][A]['fixmap'];aLpLZUAiztgiNlbBLCzH=OlFpZxSIOWOxoYIYEJhM[C][A]['exmap'];FSCYAmNGBJnxwSALzBkf=OlFpZxSIOWOxoYIYEJhM[C][A]['tele'];lqXHDuOYgXYhetBgCYsz=OlFpZxSIOWOxoYIYEJhM[C][A]['follow'];ckJIWmQSnmQYUfalCxXp=2*lqXHDuOYgXYhetBgCYsz;IjYAzllkkygppwgdByaD=OlFpZxSIOWOxoYIYEJhM[C][A]['xy'];ElypdqSIokBODDbkkScM=OlFpZxSIOWOxoYIYEJhM[C][A]['me'];yjBSkKWrTZmjTyrBctgP=2*ElypdqSIokBODDbkkScM;KwsJDRkruEQWSjwNQkeT=OlFpZxSIOWOxoYIYEJhM[C][A][_M];lpFkDOCHWxiihBxJHkmz=2*KwsJDRkruEQWSjwNQkeT;ZWisUXTeWLjUCupXfSzP=OlFpZxSIOWOxoYIYEJhM[C][A]['item'];iuknGWUHTtEqnnSStIXm=2*ZWisUXTeWLjUCupXfSzP;xSet=OlFpZxSIOWOxoYIYEJhM[B][F];AbCRsrMuzGxreICrQGgI=OlFpZxSIOWOxoYIYEJhM[B][A]['start'];WjBVKnXPdeFTVaHDVftO=2*AbCRsrMuzGxreICrQGgI;kgWljzpKAMtyWUyNYEyk=OlFpZxSIOWOxoYIYEJhM[B][A]['area'];SlHxcnvFvRyrfsfotwQX=OlFpZxSIOWOxoYIYEJhM[B][A]['radius'];BBDGSqFTNcBMWBZPaDdb=OlFpZxSIOWOxoYIYEJhM[B][A]['recall'];smidgIeqAzkDjJRUzNyj=OlFpZxSIOWOxoYIYEJhM[B][A]['weapon'];CNxmwNCwrqErSfzMvDVY=2*smidgIeqAzkDjJRUzNyj;FasrOhIrfhkYEpusGVEa=OlFpZxSIOWOxoYIYEJhM[B][A]['leavept'];fSWVsmRGkFLtgVXUYZqC=OlFpZxSIOWOxoYIYEJhM[B][A]['python'];ARXFaXmGEtGWzkHnGXuH=OlFpZxSIOWOxoYIYEJhM[B][A]['mns'];VdwlNYpiyXLOoaMLtcSB=2*ARXFaXmGEtGWzkHnGXuH;aMRSrqVNGeyGaEIMZNPx=OlFpZxSIOWOxoYIYEJhM[B][A]['profile'];oTFBetyFBvHupyfAGClV=OlFpZxSIOWOxoYIYEJhM[B][A]['cure'];gowFonKJmlgklDDIRFtD=2*oTFBetyFBvHupyfAGClV;FITlKWsCUeQSZIZohXrt=OlFpZxSIOWOxoYIYEJhM[B][A][_E];wudDpovLQHsjqfrcjGOM=2*FITlKWsCUeQSZIZohXrt;URjGqjCDmYoJHDHaXTew=OlFpZxSIOWOxoYIYEJhM[B][A][_D];BdlumdijWsfizfBgABDI=2*URjGqjCDmYoJHDHaXTew;LrcdbgmrKtvhinzLigCG=OlFpZxSIOWOxoYIYEJhM[B][A].get('buyf10','b');FUtXcwxZVoNABGdDRGxr=2*LrcdbgmrKtvhinzLigCG;fMxpbUFLfvgzdvCEvtBf=OlFpZxSIOWOxoYIYEJhM[B][A].get('autologin','a');VMxpbULFfvgzdveCvtBf=2*fMxpbUFLfvgzdvCEvtBf;return NweMXVypQZSXaVSCagqM(120,hhtizdLRxJDclVvtcTSo)
reload()
def event_loop():
	if UcWfUFCYKlXNbyprOAYx():dRBzRDsZDulhsFtoVKPh(reload());PPEcQjlrTqiJEFkRluEk(BXxnPGdFgiHeQuztmsNz)
	if QskYjJmXrUlRpfpbgTHK():
		value=BejlECPvCTQABqGrRRvQ()
		if fHKuIgMGGBYsBwpBfdBt()<value:OmBLuxbdkPvMkMdHvdde()
		else:BIXCvguMVCDEsbXuFglN();_thread=Thread(target=uaNihShctJoXObzkuVYs,daemon=FudbnvReIPieRucoAuaD);_thread.start()
def joined_game():
	if not OlFpZxSIOWOxoYIYEJhM:reload()
def handle_chat(t,p,msg):
	G='fixmapdata';F='guild';E='u';D='e';C=',';B=' ';A='job_name'
	if t!=11:dpPdferxflwICD8kgfghsdZG=msg.startswith(xMove);RMDasdfehJvZasdfykkOIRtC=msg.startswith(xSet)
	else:
		msg=msg.split(':')
		if len(msg)>=2:msg=msg[-1].strip()
		else:msg=msg[0]
		dpPdferxflwICD8kgfghsdZG=msg.startswith(xMove);RMDasdfehJvZasdfykkOIRtC=msg.startswith(xSet)
	if dpPdferxflwICD8kgfghsdZG or RMDasdfehJvZasdfykkOIRtC:
		char=KRsJzeKTYFIlLTuRSRiR()
		if not(char[F]in HAQnRCeWwRuHgewVpRFe or char[_A]in MWRfbVIvTugnvscXQAvD):return
		if char[F]not in HAQnRCeWwRuHgewVpRFe and p not in MWRfbVIvTugnvscXQAvD:return
		if char[F]in HAQnRCeWwRuHgewVpRFe and p not in MWRfbVIvTugnvscXQAvD:
			members=saYtEfxAxrcNamamIRJj().values();members=[player[_A]for player in members if player['online']]
			if p not in members:dRBzRDsZDulhsFtoVKPh('3');return
		ZkbWsUosENmoPinNOWhT(t);RYRTIcYOAQudANbxvwKG();UIAbqUTstolajZIchgtY=lRIsBSlUySBYpuHrkYnT();msg=B.join(msg.split());spl=C if C in msg else B;gBcgWasd667NzsadfegZJp=msg.split(spl);l=len(gBcgWasd667NzsadfegZJp);_data=[]
		if l>1:
			IGYzZOkWWeXhKDjhMxWs=gBcgWasd667NzsadfegZJp[1]
			if l==2:
				if dpPdferxflwICD8kgfghsdZG:
					if IGYzZOkWWeXhKDjhMxWs==lqXHDuOYgXYhetBgCYsz:
						if char[_A]!=p:CdAAGfQHmJMxcsQWrGGK(p)
					elif IGYzZOkWWeXhKDjhMxWs==ckJIWmQSnmQYUfalCxXp:PMdVcgtXrpBJIADTxumN()
					elif IGYzZOkWWeXhKDjhMxWs==KwsJDRkruEQWSjwNQkeT:
						if t==4 or t==5:lZQgKLWyGjAzXRzRFwiO(suffix=0,chat_player=p);nPPBBiXwUsyiRVjRRAfL()
					elif IGYzZOkWWeXhKDjhMxWs==lpFkDOCHWxiihBxJHkmz:FBPMvgstkXxDhzvetEIP()
					elif IGYzZOkWWeXhKDjhMxWs==TzGfRvgrVpiZseBbBgOT:
						if not UIAbqUTstolajZIchgtY:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(102,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]));return
						if char[_A]==p:
							_data.append(str(round(JXTzMNfuXNwApUpCcpfl()['z'])));members=UIAbqUTstolajZIchgtY.values();members=[player[_A]for player in members];members.insert(0,p)
							for i in members:_data.append(i)
							res=C.join(_data);Mkqtytui66aCrMojmbnbTrXYk(res)
						else:_thread=Thread(target=hhlhQISSJFCwRNctgPLk,daemon=FudbnvReIPieRucoAuaD);Timer(1.5,_thread.start).start()
					elif IGYzZOkWWeXhKDjhMxWs==ElypdqSIokBODDbkkScM:
						if not UIAbqUTstolajZIchgtY:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(102,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]));return
						if p in[char[_A],char[A]]:nsZLyHCBkXmhmKvEvurE();dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(160))
					elif IGYzZOkWWeXhKDjhMxWs==yjBSkKWrTZmjTyrBctgP:
						if p in[char[_A],char[A]]:JqJqUUglXsHyPCxkXimL(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==vbaYnrXctBUtzKeHUekn:yLjBjMEghjnCkYVqCeNd()
					elif IGYzZOkWWeXhKDjhMxWs==bEmgkhtGIusXZcCsEOHL:CgadlVRGXGXzyNaoChZa()
					elif IGYzZOkWWeXhKDjhMxWs==EuEdCvBryetSakQDfJoN:qgFndKkwthIMIWQUPxJo()
					elif IGYzZOkWWeXhKDjhMxWs==iuknGWUHTtEqnnSStIXm:lnOxnRquNfjVdGRVjmsV(FudbnvReIPieRucoAuaD)
					else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(101,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]))
				elif RMDasdfehJvZasdfykkOIRtC:
					if IGYzZOkWWeXhKDjhMxWs==AbCRsrMuzGxreICrQGgI:RnyZYPLRCJXvwGliXClI()
					elif IGYzZOkWWeXhKDjhMxWs==WjBVKnXPdeFTVaHDVftO:lUSdTvHgoqRajvWWlVGg()
					elif IGYzZOkWWeXhKDjhMxWs==smidgIeqAzkDjJRUzNyj:
						if p in[char[A],char[_A]]:
							for key in OlFpZxSIOWOxoYIYEJhM[_N].keys():
								if key==char[_A]:WErkgqBrBCDAblsNmlSb(time());fhqdyUBqzkFSuScixXCa(FudbnvReIPieRucoAuaD);fVDpswbUWpNsmGipXCEf(FudbnvReIPieRucoAuaD);break
					elif IGYzZOkWWeXhKDjhMxWs==CNxmwNCwrqErSfzMvDVY:
						if p in[char[_A],char[A]]:fhqdyUBqzkFSuScixXCa(BXxnPGdFgiHeQuztmsNz);WErkgqBrBCDAblsNmlSb(_C);dOrXDexRZzUmdtnPElWS(0);fVDpswbUWpNsmGipXCEf(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==ARXFaXmGEtGWzkHnGXuH:
						if p in[char[A],char[_A]]and char[_A]in list(OlFpZxSIOWOxoYIYEJhM['mns'].keys()):XnSToOzUhGWWBwgyBPPY()
					elif IGYzZOkWWeXhKDjhMxWs==VdwlNYpiyXLOoaMLtcSB:
						if p in[char[_A],char[A]]:SjlOsrJpZVlmkWGEhqwq(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==FasrOhIrfhkYEpusGVEa:kqmJnkroTMARKnlIanad()
					elif IGYzZOkWWeXhKDjhMxWs==oTFBetyFBvHupyfAGClV:
						if not dXHBvgAlKNXoAQQAvRnn():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(135,hhtizdLRxJDclVvtcTSo));return
						if p in[char[_A],char[A]]:VijlQEqMyGonacEtDTCv(FudbnvReIPieRucoAuaD);mqsobrZHAYkPaVTAFKAL(FudbnvReIPieRucoAuaD)
					elif IGYzZOkWWeXhKDjhMxWs==gowFonKJmlgklDDIRFtD:
						if p in[char[_A],char[A]]:VijlQEqMyGonacEtDTCv(BXxnPGdFgiHeQuztmsNz);mqsobrZHAYkPaVTAFKAL(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==FITlKWsCUeQSZIZohXrt:
						if not dXHBvgAlKNXoAQQAvRnn():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(135,hhtizdLRxJDclVvtcTSo));return
						if p in[char[_A],char[A]]:
							if char[_A]in list(OlFpZxSIOWOxoYIYEJhM[_E].keys()):
								_data=OlFpZxSIOWOxoYIYEJhM[_E][char[_A]];_data_skills=_data[_O].keys();fCode=SkxaQNxKDdSJFnsfsdzB(_data['fCode']);skills=ECxMEYCbpCwFIMDSlqlZ().items();_IdsSkillGhost=[];imbue=dZXoHFUyHwMNBqKIohzA()
								if imbue:jcldtoYGcRdJGWVJpQHF()
								for(key,skill)in skills:
									for i in _data_skills:
										if i==skill[_A]:_IdsSkillGhost.append(key)
								if _IdsSkillGhost:
									if fCode:hCawZAIqjIvSiejHrEdl(fCode)
									wVjtrcwwriMQDKQmXPvT(_IdsSkillGhost);AIcpfFSeCGHDMlJdLlsx(time());xBtvkWltTepDermyPxih(FudbnvReIPieRucoAuaD);tIeHXVSztjqZvJvjjwCO(FudbnvReIPieRucoAuaD)
								else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(130,hhtizdLRxJDclVvtcTSo))
					elif IGYzZOkWWeXhKDjhMxWs==wudDpovLQHsjqfrcjGOM:
						if p in[char[_A],char[A]]:
							xBtvkWltTepDermyPxih(BXxnPGdFgiHeQuztmsNz);AIcpfFSeCGHDMlJdLlsx(_C);dobtCotahjTrPyDhbYdc(0);tIeHXVSztjqZvJvjjwCO(BXxnPGdFgiHeQuztmsNz);fCode=DkgNbbZrpZkhHsQTJPvI()
							if fCode:sXUBkDpHLLraiJRjIJTc(fCode)
					elif IGYzZOkWWeXhKDjhMxWs==URjGqjCDmYoJHDHaXTew:
						if not dXHBvgAlKNXoAQQAvRnn():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(135,hhtizdLRxJDclVvtcTSo));return
						if p in[char[_A],char[A]]:
							if char[_A]in list(OlFpZxSIOWOxoYIYEJhM[_D].keys()):
								_data_skills=OlFpZxSIOWOxoYIYEJhM[_D][char[_A]]['enemyskills'];_dirgame=OlFpZxSIOWOxoYIYEJhM[_D][char[_A]]['dirgame']
								if not _dirgame:return
								_db_name=_dirgame[1];_IdsSkillGuard=[];_error_skill=[]
								for _skill in _data_skills:
									ids=NRShXDDOwSIcLhcoNQtv(_db_name,_skill)
									if not ids:_error_skill.append(_skill);continue
									_IdsSkillGuard+=ids
								if _error_skill:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(133,hhtizdLRxJDclVvtcTSo,_error_skill))
								if not _IdsSkillGuard:return
								JFxYyFAgjatrXZqxRrfV(_IdsSkillGuard);XCuFQPSRNGozpeCWSRHk(time());EGYPwxYxafykiRQHFYhH(FudbnvReIPieRucoAuaD);CkUMFCjcVhViUftMDrhc(FudbnvReIPieRucoAuaD);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(159,hhtizdLRxJDclVvtcTSo))
					elif IGYzZOkWWeXhKDjhMxWs==BdlumdijWsfizfBgABDI:
						if p in[char[_A],char[A]]:EGYPwxYxafykiRQHFYhH(BXxnPGdFgiHeQuztmsNz);XCuFQPSRNGozpeCWSRHk(_C);EfZrprCtAxjxqZlSjAMf(0);CkUMFCjcVhViUftMDrhc(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==fSWVsmRGkFLtgVXUYZqC:VtNaihreyEBlTuLssDgv(FudbnvReIPieRucoAuaD);PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD)
					elif IGYzZOkWWeXhKDjhMxWs==BBDGSqFTNcBMWBZPaDdb:dOeHisGInsnUSIDYcCuY()
					elif IGYzZOkWWeXhKDjhMxWs==LrcdbgmrKtvhinzLigCG:LcJZzvAJTFNQHlKbIntY();PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD);Timer(3.2,ChSlozxVuBDjPTUsewsE,(FudbnvReIPieRucoAuaD,)).start()
					elif IGYzZOkWWeXhKDjhMxWs==FUtXcwxZVoNABGdDRGxr:LcJZzvAJTFNQHlKbIntY(_state=BXxnPGdFgiHeQuztmsNz);ChSlozxVuBDjPTUsewsE(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==fMxpbUFLfvgzdvCEvtBf:
						if p in[char[_A],char[A]]:UCjqYAMSgPZMRklZRcWd()
					elif IGYzZOkWWeXhKDjhMxWs==VMxpbULFfvgzdveCvtBf:
						if p in[char[_A],char[A]]:ACjqYAMSgptMRklZjjWd()
					else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(101,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]))
			elif l>=3:
				OBdasdeuZkjQVgIktysaqqEHA=gBcgWasd667NzsadfegZJp[-1]
				if dpPdferxflwICD8kgfghsdZG:
					if IGYzZOkWWeXhKDjhMxWs==bEmgkhtGIusXZcCsEOHL:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:CgadlVRGXGXzyNaoChZa()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:CgadlVRGXGXzyNaoChZa()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:CgadlVRGXGXzyNaoChZa()
					elif IGYzZOkWWeXhKDjhMxWs==vbaYnrXctBUtzKeHUekn:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:yLjBjMEghjnCkYVqCeNd()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:yLjBjMEghjnCkYVqCeNd()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:yLjBjMEghjnCkYVqCeNd()
					elif IGYzZOkWWeXhKDjhMxWs==EuEdCvBryetSakQDfJoN:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:qgFndKkwthIMIWQUPxJo()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:qgFndKkwthIMIWQUPxJo()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:qgFndKkwthIMIWQUPxJo()
					elif IGYzZOkWWeXhKDjhMxWs==lqXHDuOYgXYhetBgCYsz:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:0
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:CdAAGfQHmJMxcsQWrGGK(p)
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:CdAAGfQHmJMxcsQWrGGK(p)
					elif IGYzZOkWWeXhKDjhMxWs==ckJIWmQSnmQYUfalCxXp:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:0
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:PMdVcgtXrpBJIADTxumN()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:PMdVcgtXrpBJIADTxumN()
					elif IGYzZOkWWeXhKDjhMxWs==KwsJDRkruEQWSjwNQkeT:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:lZQgKLWyGjAzXRzRFwiO(1,p);nPPBBiXwUsyiRVjRRAfL()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:lZQgKLWyGjAzXRzRFwiO(-1,p);nPPBBiXwUsyiRVjRRAfL()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:lZQgKLWyGjAzXRzRFwiO(members,p);nPPBBiXwUsyiRVjRRAfL()
					elif IGYzZOkWWeXhKDjhMxWs==lpFkDOCHWxiihBxJHkmz:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:0
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:FBPMvgstkXxDhzvetEIP()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:FBPMvgstkXxDhzvetEIP()
					elif IGYzZOkWWeXhKDjhMxWs==ElypdqSIokBODDbkkScM:
						if gBcgWasd667NzsadfegZJp[2]not in('icon','on'):dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(136,hhtizdLRxJDclVvtcTSo,xMove,ElypdqSIokBODDbkkScM,gBcgWasd667NzsadfegZJp[2]));return
						if not UIAbqUTstolajZIchgtY:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(102,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]));return
						if p in[char[_A],char[A]]:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(128,hhtizdLRxJDclVvtcTSo,' Enabled '+gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]+' on'));JqJqUUglXsHyPCxkXimL(FudbnvReIPieRucoAuaD)
					elif IGYzZOkWWeXhKDjhMxWs==IjYAzllkkygppwgdByaD:
						if l==3 or not gBcgWasd667NzsadfegZJp[2][1:].isdigit()or not gBcgWasd667NzsadfegZJp[3][1:].isdigit():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(115,hhtizdLRxJDclVvtcTSo,'x,y'));return
						x=gBcgWasd667NzsadfegZJp[2];y=gBcgWasd667NzsadfegZJp[3]
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:YJBrOUWOrwLHoyjVwuCP(x,y)
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:YJBrOUWOrwLHoyjVwuCP(x,y)
						elif l==4:YJBrOUWOrwLHoyjVwuCP(x,y)
						else:
							members=gBcgWasd667NzsadfegZJp[4:]
							if char[_A]in members:YJBrOUWOrwLHoyjVwuCP(x,y)
					elif IGYzZOkWWeXhKDjhMxWs==TzGfRvgrVpiZseBbBgOT:
						if not UIAbqUTstolajZIchgtY:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(102,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]));return
						members=UIAbqUTstolajZIchgtY.values();members=[player[_A]for player in members]
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:return
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:0
						else:members=gBcgWasd667NzsadfegZJp[2:]
						if char[_A]==p:
							_data.append(str(round(JXTzMNfuXNwApUpCcpfl()['z'])))
							if p not in members:members.append(p)
							members.insert(0,p)
							for i in members:_data.append(i)
							res=C.join(_data);Mkqtytui66aCrMojmbnbTrXYk(res)
						else:
							if p in members:members.remove(p)
							members.sort();_time=.15
							if char[_A]in members:_idx=members.index(char[_A]);_thread=Thread(target=hhlhQISSJFCwRNctgPLk,daemon=FudbnvReIPieRucoAuaD);Timer(1.5+_idx*_time,_thread.start).start()
					elif IGYzZOkWWeXhKDjhMxWs==zDEWVgxGJymItqKKonhT:
						_map_name=gBcgWasd667NzsadfegZJp[2:]
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:_map_name=_map_name[:-1];_map_name=B.join(_map_name);ldOnSWyiPoeAEvWMxPlE(_map_name)
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:_map_name=_map_name[:-1];_map_name=B.join(_map_name);ldOnSWyiPoeAEvWMxPlE(_map_name)
						elif l==3:ldOnSWyiPoeAEvWMxPlE(gBcgWasd667NzsadfegZJp[2])
						else:
							_map_name=B.join(gBcgWasd667NzsadfegZJp[2:])
							if _map_name.find(C)>0:
								_map_name=_map_name.split(C)
								if char[_A]in _map_name[1:]:ldOnSWyiPoeAEvWMxPlE(_map_name[0]);return
							l_shortcut=list(OlFpZxSIOWOxoYIYEJhM[G]['shortcuts'].keys());l_source=OlFpZxSIOWOxoYIYEJhM[G]['original'];_name_fixmap=''
							for n in l_shortcut:
								if _map_name.find(n)>=0:_name_fixmap=n;break
							if not _name_fixmap:
								for n in l_source:
									if _map_name.find(n)>=0:_name_fixmap=n;break
							if _name_fixmap:
								l_map_name=_map_name.split(_name_fixmap)
								if l_map_name[1]:
									_players=l_map_name[1].strip();_players=_players.split(B)
									if char[_A]in _players:ldOnSWyiPoeAEvWMxPlE(_name_fixmap);return
								else:ldOnSWyiPoeAEvWMxPlE(_name_fixmap);return
							else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(38,hhtizdLRxJDclVvtcTSo,B.join(gBcgWasd667NzsadfegZJp[2:])));return
					elif IGYzZOkWWeXhKDjhMxWs==aLpLZUAiztgiNlbBLCzH:dRBzRDsZDulhsFtoVKPh('Chức năng Move ExMap đang tạm khoá do phbot đã ngừng hỗ trợ')
					elif IGYzZOkWWeXhKDjhMxWs==FSCYAmNGBJnxwSALzBkf:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:WsOqPwUTNnjWFZeBvjcX(gBcgWasd667NzsadfegZJp[2:-1])
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:WsOqPwUTNnjWFZeBvjcX(gBcgWasd667NzsadfegZJp[2:-1])
						elif l==3:WsOqPwUTNnjWFZeBvjcX(gBcgWasd667NzsadfegZJp[2])
						else:
							shortcuts=list(OlFpZxSIOWOxoYIYEJhM['tele'].keys())
							if gBcgWasd667NzsadfegZJp[2]in shortcuts:
								if char[_A]in gBcgWasd667NzsadfegZJp[3:]:WsOqPwUTNnjWFZeBvjcX(gBcgWasd667NzsadfegZJp[2])
							elif l==4:WsOqPwUTNnjWFZeBvjcX(gBcgWasd667NzsadfegZJp[2:])
							elif char[_A]in gBcgWasd667NzsadfegZJp[4:]:WsOqPwUTNnjWFZeBvjcX(gBcgWasd667NzsadfegZJp[2:4])
					elif IGYzZOkWWeXhKDjhMxWs==ZWisUXTeWLjUCupXfSzP:
						lnOxnRquNfjVdGRVjmsV(BXxnPGdFgiHeQuztmsNz)
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:
								lZQgKLWyGjAzXRzRFwiO(1,p)
								if gBcgWasd667NzsadfegZJp[2]==D:_thread=Thread(target=nLlwmvlgJTAXMBPgdIZU,daemon=FudbnvReIPieRucoAuaD);_thread.start()
								elif gBcgWasd667NzsadfegZJp[2]==E:_thread=Thread(target=BIYnlKkyPOyTpOcNNkxq,daemon=FudbnvReIPieRucoAuaD);_thread.start()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:
								lZQgKLWyGjAzXRzRFwiO(-1,p)
								if gBcgWasd667NzsadfegZJp[2]==D:_thread=Thread(target=nLlwmvlgJTAXMBPgdIZU,daemon=FudbnvReIPieRucoAuaD);_thread.start()
								elif gBcgWasd667NzsadfegZJp[2]==E:_thread=Thread(target=BIYnlKkyPOyTpOcNNkxq,daemon=FudbnvReIPieRucoAuaD);_thread.start()
						elif l==3:
							lZQgKLWyGjAzXRzRFwiO(0,p)
							if gBcgWasd667NzsadfegZJp[2]==D:_thread=Thread(target=nLlwmvlgJTAXMBPgdIZU,daemon=FudbnvReIPieRucoAuaD);_thread.start()
							elif gBcgWasd667NzsadfegZJp[2]==E:_thread=Thread(target=BIYnlKkyPOyTpOcNNkxq,daemon=FudbnvReIPieRucoAuaD);_thread.start()
						else:
							members=gBcgWasd667NzsadfegZJp[3:]
							if char[_A]in members:
								lZQgKLWyGjAzXRzRFwiO(members,p)
								if gBcgWasd667NzsadfegZJp[2]==D:_thread=Thread(target=nLlwmvlgJTAXMBPgdIZU,daemon=FudbnvReIPieRucoAuaD);_thread.start()
								elif gBcgWasd667NzsadfegZJp[2]==E:_thread=Thread(target=BIYnlKkyPOyTpOcNNkxq,daemon=FudbnvReIPieRucoAuaD);_thread.start()
					elif IGYzZOkWWeXhKDjhMxWs==iuknGWUHTtEqnnSStIXm:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:lnOxnRquNfjVdGRVjmsV(FudbnvReIPieRucoAuaD)
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:lnOxnRquNfjVdGRVjmsV(FudbnvReIPieRucoAuaD)
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:lnOxnRquNfjVdGRVjmsV(FudbnvReIPieRucoAuaD)
					else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(101,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]))
				elif RMDasdfehJvZasdfykkOIRtC:
					if IGYzZOkWWeXhKDjhMxWs==AbCRsrMuzGxreICrQGgI:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:RnyZYPLRCJXvwGliXClI()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:RnyZYPLRCJXvwGliXClI()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:RnyZYPLRCJXvwGliXClI()
					elif IGYzZOkWWeXhKDjhMxWs==WjBVKnXPdeFTVaHDVftO:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:lUSdTvHgoqRajvWWlVGg()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:lUSdTvHgoqRajvWWlVGg()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:lUSdTvHgoqRajvWWlVGg()
					elif IGYzZOkWWeXhKDjhMxWs==fSWVsmRGkFLtgVXUYZqC:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:WnxgXCdsZTEiLQZmVmmv(gBcgWasd667NzsadfegZJp[2])
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:WnxgXCdsZTEiLQZmVmmv(gBcgWasd667NzsadfegZJp[2])
						elif l==3:WnxgXCdsZTEiLQZmVmmv(gBcgWasd667NzsadfegZJp[2])
						else:
							members=gBcgWasd667NzsadfegZJp[3:]
							if char[_A]in members:WnxgXCdsZTEiLQZmVmmv(gBcgWasd667NzsadfegZJp[2])
					elif IGYzZOkWWeXhKDjhMxWs==SlHxcnvFvRyrfsfotwQX:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:JxWWFLNALTvfnJzIWajs(gBcgWasd667NzsadfegZJp[2])
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:JxWWFLNALTvfnJzIWajs(gBcgWasd667NzsadfegZJp[2])
						elif l==3:JxWWFLNALTvfnJzIWajs(gBcgWasd667NzsadfegZJp[2])
						else:
							members=gBcgWasd667NzsadfegZJp[3:]
							if char[_A]in members:JxWWFLNALTvfnJzIWajs(gBcgWasd667NzsadfegZJp[2])
					elif IGYzZOkWWeXhKDjhMxWs==kgWljzpKAMtyWUyNYEyk:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:KcCbiCwANXbIAeKiuDys(gBcgWasd667NzsadfegZJp[2])
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:KcCbiCwANXbIAeKiuDys(gBcgWasd667NzsadfegZJp[2])
						elif l==3:KcCbiCwANXbIAeKiuDys(gBcgWasd667NzsadfegZJp[2])
						else:
							members=gBcgWasd667NzsadfegZJp[3:]
							if char[_A]in members:KcCbiCwANXbIAeKiuDys(gBcgWasd667NzsadfegZJp[2])
					elif IGYzZOkWWeXhKDjhMxWs==aMRSrqVNGeyGaEIMZNPx:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:EeynrnMgzhiTUAyYmCSY(gBcgWasd667NzsadfegZJp[2])
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:EeynrnMgzhiTUAyYmCSY(gBcgWasd667NzsadfegZJp[2])
						elif l==3:EeynrnMgzhiTUAyYmCSY(gBcgWasd667NzsadfegZJp[2])
						else:
							members=gBcgWasd667NzsadfegZJp[3:]
							if char[_A]in members:EeynrnMgzhiTUAyYmCSY(gBcgWasd667NzsadfegZJp[2])
					elif IGYzZOkWWeXhKDjhMxWs==BBDGSqFTNcBMWBZPaDdb:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:dOeHisGInsnUSIDYcCuY()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:dOeHisGInsnUSIDYcCuY()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:dOeHisGInsnUSIDYcCuY()
					elif IGYzZOkWWeXhKDjhMxWs==LrcdbgmrKtvhinzLigCG:
						if p in[char[_A],char[A]]:
							if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:LcJZzvAJTFNQHlKbIntY(_listName=[p],_state=FudbnvReIPieRucoAuaD)
							elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
								_list_name=list(OlFpZxSIOWOxoYIYEJhM[_F][_G].keys())
								if p in _list_name:_list_name.remove(p)
								LcJZzvAJTFNQHlKbIntY(_listName=_list_name,_state=FudbnvReIPieRucoAuaD)
							else:members=gBcgWasd667NzsadfegZJp[2:];LcJZzvAJTFNQHlKbIntY(_listName=members,_state=FudbnvReIPieRucoAuaD)
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD);Timer(3.2,ChSlozxVuBDjPTUsewsE,(FudbnvReIPieRucoAuaD,)).start()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD);Timer(3.2,ChSlozxVuBDjPTUsewsE,(FudbnvReIPieRucoAuaD,)).start()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:PPEcQjlrTqiJEFkRluEk(FudbnvReIPieRucoAuaD);Timer(3.2,ChSlozxVuBDjPTUsewsE,(FudbnvReIPieRucoAuaD,)).start()
					elif IGYzZOkWWeXhKDjhMxWs==FUtXcwxZVoNABGdDRGxr:
						if p in[char[_A],char[A]]:
							if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:LcJZzvAJTFNQHlKbIntY(_listName=[p],_state=BXxnPGdFgiHeQuztmsNz)
							elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
								_list_name=list(OlFpZxSIOWOxoYIYEJhM[_F][_G].keys())
								if p in _list_name:_list_name.remove(p)
								LcJZzvAJTFNQHlKbIntY(_listName=_list_name,_state=BXxnPGdFgiHeQuztmsNz)
							else:members=gBcgWasd667NzsadfegZJp[2:];LcJZzvAJTFNQHlKbIntY(_listName=members,_state=BXxnPGdFgiHeQuztmsNz)
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:ChSlozxVuBDjPTUsewsE(BXxnPGdFgiHeQuztmsNz)
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:ChSlozxVuBDjPTUsewsE(BXxnPGdFgiHeQuztmsNz)
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:ChSlozxVuBDjPTUsewsE(BXxnPGdFgiHeQuztmsNz)
					elif IGYzZOkWWeXhKDjhMxWs==ARXFaXmGEtGWzkHnGXuH:
						if gBcgWasd667NzsadfegZJp[2]in('n','on'):
							if p in[char[_A],char[A]]:SjlOsrJpZVlmkWGEhqwq(FudbnvReIPieRucoAuaD);XnSToOzUhGWWBwgyBPPY()
						else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(115,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[2]))
					elif IGYzZOkWWeXhKDjhMxWs==FasrOhIrfhkYEpusGVEa:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:kqmJnkroTMARKnlIanad()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:kqmJnkroTMARKnlIanad()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:kqmJnkroTMARKnlIanad()
					elif IGYzZOkWWeXhKDjhMxWs==fMxpbUFLfvgzdvCEvtBf:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:UCjqYAMSgPZMRklZRcWd()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:UCjqYAMSgPZMRklZRcWd()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:UCjqYAMSgPZMRklZRcWd()
					elif IGYzZOkWWeXhKDjhMxWs==VMxpbULFfvgzdveCvtBf:
						if OBdasdeuZkjQVgIktysaqqEHA==gFEhxLTdYeImBHOEYSOO:
							if p in[char[_A],char[A]]:ACjqYAMSgptMRklZjjWd()
						elif OBdasdeuZkjQVgIktysaqqEHA==cLXZAwUYGNoOkGSFtRts:
							if p not in[char[_A],char[A]]:ACjqYAMSgptMRklZjjWd()
						else:
							members=gBcgWasd667NzsadfegZJp[2:]
							if char[_A]in members:ACjqYAMSgptMRklZjjWd()
					else:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(101,hhtizdLRxJDclVvtcTSo,gBcgWasd667NzsadfegZJp[0],gBcgWasd667NzsadfegZJp[1]))
	elif xiUkafLFtMKWxbjlEHzK()and t in[5,11]and len(msg)>60:
		char=KRsJzeKTYFIlLTuRSRiR()
		if p not in[char[_A],char[A]]:_thread=Thread(target=lBMjAkQnTBBSXUIIyRqe,args=(msg,),daemon=FudbnvReIPieRucoAuaD);_thread.start()
	if t==5 and msg=='success'and ngnvmTHWkSqeobdOUWlQ():rUCSvqHPQnOaGBuSADZV(p)
def WaitForGuildStorage(args):
	char=jTVSKpPSjErLzGvdLpkZ();xxStIaPwVHvRDmkIpqnB=sFUnAJUvKzmhmmDUnyWo();GGWShEfZLzwEfilwWThS=SWCRxHoczBlZifzZpAkD();delay=0
	if xxStIaPwVHvRDmkIpqnB and char[_A]in xxStIaPwVHvRDmkIpqnB:idx=xxStIaPwVHvRDmkIpqnB.index(char[_A]);delay=idx*int(OlFpZxSIOWOxoYIYEJhM[_M][1])
	if GGWShEfZLzwEfilwWThS==4:phBotChat.Party(NweMXVypQZSXaVSCagqM(111,delay))
	elif GGWShEfZLzwEfilwWThS==5:phBotChat.Guild(NweMXVypQZSXaVSCagqM(111,delay))
	return delay*1000
def NotifyFinishScript(args):
	oPvKbgpBjoOuTpJkGjkq();GGWShEfZLzwEfilwWThS=SWCRxHoczBlZifzZpAkD()
	if GGWShEfZLzwEfilwWThS==4:phBotChat.Party(NweMXVypQZSXaVSCagqM(127))
	elif GGWShEfZLzwEfilwWThS==5:phBotChat.Guild(NweMXVypQZSXaVSCagqM(127))
	return 0
def ChatParty(args):
	if len(args)==2:phBotChat.Party(args[1])
	else:dRBzRDsZDulhsFtoVKPh('Đã nhập sai cú pháp của lệnh ChatParty')
	return 0
def ChatGuild(args):
	if len(args)==2:phBotChat.Guild(args[1])
	else:dRBzRDsZDulhsFtoVKPh('Đã nhập sai cú pháp của lệnh ChatGuild')
	return 0
def StartBot(args):
	if not THrFZggxXTtiPNayrVBf():lPdKihxfDtHFLdWWDqtL()
	return 0
def StopBot(args):
	if THrFZggxXTtiPNayrVBf():kcsnOyTtUcjyOgADjQon()
	return 0
mxxXjuBhVryNxgMWuULn=BXxnPGdFgiHeQuztmsNz
def GetEnableCondition():return mxxXjuBhVryNxgMWuULn
def SetDisableCondition():global mxxXjuBhVryNxgMWuULn;mxxXjuBhVryNxgMWuULn=BXxnPGdFgiHeQuztmsNz
def handle_silkroad(opcode,data):
	if gbrtpxaiFtIaoLuecZYU()and opcode in[28788,28705]:
		char=KRsJzeKTYFIlLTuRSRiR();_name=char[_A];_data=OlFpZxSIOWOxoYIYEJhM[_N][_name];_data_shield_skills=_data['skills_for_shield'];_data_wp1_skills=_data['skills_for_weapon_1'];_data_wp2_skills=_data['skills_for_weapon_2'];_data_wp3_skills=_data['skills_for_weapon_3'];_data_wp4_skills=_data.get('skills_for_weapon_4',[]);_data_shield=_data[_H];_data_wp1=_data['weapon_1'];_data_wp2=_data['weapon_2'];_data_wp3=_data['weapon_3'];_data_wp4=_data.get('weapon_4',['',0]);_data_walk=_data['walk'];items=LDlkmjOOgaGCsuHjpvOt()[_I];_region_id=char[_J]
		if _region_id in hUHSuqxFjSVWRPqpYxid():dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(177,hhtizdLRxJDclVvtcTSo));return FudbnvReIPieRucoAuaD
		if opcode==28788 and len(data)>=7:
			_id=struct.unpack_from('I',data,2)[0];name_skill=LqsbaqoXPhAkvppTONMi(_id)[_A]
			if _data_shield[0]and name_skill in _data_shield_skills:
				check_shield_slot=BXxnPGdFgiHeQuztmsNz;check_shield_name=BXxnPGdFgiHeQuztmsNz;s=_C
				for(slot,item)in enumerate(items):
					if slot==7:
						_c1=item and item[_A].startswith(_K);_c2=item and item[_A].startswith(_L);check=not item or _c1 or _c2
						if check:check_shield_slot=FudbnvReIPieRucoAuaD
					elif slot>12:
						check=item and item[_A]==_data_shield[0]and item[_B]==_data_shield[1]
						if check:check_shield_name=FudbnvReIPieRucoAuaD;s=slot;break
				if check_shield_slot and check_shield_name:ZXvpCmJlxNhWFlSHYLdt(0,s,7,_data_shield[0],0,BXxnPGdFgiHeQuztmsNz)
			if _data_wp1[0]and name_skill in _data_wp1_skills:
				for(slot,item)in enumerate(items):
					if slot==6 and item and item[_A]==_data_wp1[0]and item[_B]==_data_wp1[1]:break
					elif slot>12 and item and item[_A]==_data_wp1[0]and item[_B]==_data_wp1[1]:ZXvpCmJlxNhWFlSHYLdt(0,slot,6,item[_A],0,BXxnPGdFgiHeQuztmsNz);break
			elif _data_wp2[0]and name_skill in _data_wp2_skills:
				for(slot,item)in enumerate(items):
					if slot==6 and item and item[_A]==_data_wp2[0]and item[_B]==_data_wp2[1]:break
					elif slot>12 and item and item[_A]==_data_wp2[0]and item[_B]==_data_wp2[1]:ZXvpCmJlxNhWFlSHYLdt(0,slot,6,item[_A],0,BXxnPGdFgiHeQuztmsNz);break
			elif _data_wp3[0]and name_skill in _data_wp3_skills:
				for(slot,item)in enumerate(items):
					if slot==6 and item and item[_A]==_data_wp3[0]and item[_B]==_data_wp3[1]:break
					elif slot>12 and item and item[_A]==_data_wp3[0]and item[_B]==_data_wp3[1]:ZXvpCmJlxNhWFlSHYLdt(0,slot,6,item[_A],0,BXxnPGdFgiHeQuztmsNz);break
			elif _data_wp4[0]and name_skill in _data_wp4_skills:
				for(slot,item)in enumerate(items):
					if slot==6 and item and item[_A]==_data_wp4[0]and item[_B]==_data_wp4[1]:break
					elif slot>12 and item and item[_A]==_data_wp4[0]and item[_B]==_data_wp4[1]:ZXvpCmJlxNhWFlSHYLdt(0,slot,6,item[_A],0,BXxnPGdFgiHeQuztmsNz);break
			return FudbnvReIPieRucoAuaD
		elif opcode==28705 and _data_walk and _data_shield[0]:
			_PlusCountWP=tPeBaHWNFMPsZUNVbNEB();check_shield_slot=BXxnPGdFgiHeQuztmsNz;check_shield_name=BXxnPGdFgiHeQuztmsNz;s=_C;_blade_slot=_C;_blade=OlFpZxSIOWOxoYIYEJhM[_D][_name]['blade'];check_blade=_blade[0]and(KaokGrhIXYPffSogkLUC()or WVLTCWynDmoKoTaAJJcv());equip_blade=BXxnPGdFgiHeQuztmsNz
			for(slot,item)in enumerate(items):
				if(slot==6 and check_blade)and(not item or item and item[_A]!=_blade[0]):equip_blade=FudbnvReIPieRucoAuaD
				elif slot==7:
					_c1=item and item[_A].startswith(_K);_c2=item and item[_A].startswith(_L);check=not item or _c1 or _c2
					if check:check_shield_slot=FudbnvReIPieRucoAuaD
				elif slot>12:
					check=item and item[_A]==_data_shield[0]and item[_B]==_data_shield[1]
					if check:check_shield_name=FudbnvReIPieRucoAuaD;s=slot
					if equip_blade:
						if _blade_slot and s:break
						if _blade_slot:continue
						if item and item[_A]==_blade[0]and item[_B]==_blade[1]:_blade_slot=slot;ZXvpCmJlxNhWFlSHYLdt(0,_blade_slot,6,_blade[0],0,BXxnPGdFgiHeQuztmsNz)
			if check_shield_slot and check_shield_name:ZXvpCmJlxNhWFlSHYLdt(0,s,7,_data_shield[0],0,BXxnPGdFgiHeQuztmsNz);_PlusCountWP+=1;dOrXDexRZzUmdtnPElWS(_PlusCountWP);_total_time=round((time()-nNvOZtWkgoQWMBOUGmAl())/60);_text=NweMXVypQZSXaVSCagqM(131,hhtizdLRxJDclVvtcTSo,'Auto Change Weapon',_PlusCountWP,_total_time);Timer(.1,log,(_text,)).start()
			return FudbnvReIPieRucoAuaD
	if OUqTSdfJGPcUyEYpxaEx()and opcode==12433 and data==b'\x06'and not THrFZggxXTtiPNayrVBf():_thread=Thread(target=sblrCIfUwplapFVVePRa,daemon=FudbnvReIPieRucoAuaD);_thread.start();return BXxnPGdFgiHeQuztmsNz
	if vZytcdRaGsLtMJlAjcxP()and opcode==12433 and data==b'\x00':nsZLyHCBkXmhmKvEvurE();return BXxnPGdFgiHeQuztmsNz
	if aehcJhshMnfDvGMfmteP()and opcode==28724 and data.find(b'PACKAGE_ITEM_')!=-1:zonZstYubKOgSQxovBHl(data)
	if nVxwkmKtlfblagNmyvCs()and dZXoHFUyHwMNBqKIohzA()and opcode==28788 and data and data[0]==1:xSetEnableConGhost(enable=FudbnvReIPieRucoAuaD)
	return FudbnvReIPieRucoAuaD
def handle_joymax(opcode,data):
	C='delay';B='player_id';A='i'
	if nVxwkmKtlfblagNmyvCs()and opcode==45168 and len(data)>=19:
		if not innwUIWozXuiFGhlJEyg():return FudbnvReIPieRucoAuaD
		boss=HceohIdfJCXaWsFgnpCL()
		if not boss and THrFZggxXTtiPNayrVBf():return FudbnvReIPieRucoAuaD
		sv_skill_id=struct.unpack_from(A,data,3)[0];sv_char_id=struct.unpack_from(A,data,7)[0];_enemy_id=struct.unpack_from(A,data,15)[0];char=lsAYyFavuPVrHATRDktQ();_PlusGhostCount=wntMGpqkrroMJZmmkLrr()
		if sv_char_id==char[B]and sv_skill_id in innwUIWozXuiFGhlJEyg():
			_data=OlFpZxSIOWOxoYIYEJhM[_E][char[_A]];_monster_ids=list(bahiJHAVvcAlykCCaFsG().keys());_name_skill=LqsbaqoXPhAkvppTONMi(sv_skill_id)[_A];_skill=_data[_O][_name_skill]
			if isinstance(_skill,int):_skill=[_skill,'']
			delay=_skill[0];autoKey=_skill[1];delay=delay/1000;key=_data['slot']
			if boss:
				if _enemy_id not in _monster_ids:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(179,hhtizdLRxJDclVvtcTSo))
				else:unUthtubYxTzOhVhrTVA(_enemy_id);t=.05 if delay<.25 else delay-.25;Timer(t,kMGbRRWiNafGNoHLPoOM,(str(key),autoKey,boss,_enemy_id)).start()
			elif _enemy_id in _monster_ids:dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(180,hhtizdLRxJDclVvtcTSo))
			else:Timer(delay,kMGbRRWiNafGNoHLPoOM,(str(key),autoKey,boss,_enemy_id)).start()
			if iiMqfZTglmTicGcDbRTi():Timer(delay,xAudio,(500,250)).start()
			_PlusGhostCount+=1;dobtCotahjTrPyDhbYdc(_PlusGhostCount);_total_time=round((time()-yWiHThnXzqeBnbwYiQTF())/60);_text=NweMXVypQZSXaVSCagqM(131,hhtizdLRxJDclVvtcTSo,'Auto Ghost',_PlusGhostCount,_total_time);Timer(delay,log,(_text,)).start()
		return FudbnvReIPieRucoAuaD
	if nVxwkmKtlfblagNmyvCs()and HceohIdfJCXaWsFgnpCL():
		if opcode==12374 and struct.unpack_from('I',data,0)[0]==WyAuwmEICYRfhLAWwOEo():
			if THrFZggxXTtiPNayrVBf():pos=YyEqhjxvWquwLzeXsujR();dcKCaUZByfinWRkvlXGD(pos[_J],pos['x'],pos['y'],pos['z'])
			Timer(1,bYLiGOhuBMECCCXvppoD).start()
		elif opcode==45125 and len(data)>=10 and data[0]==1:id_targeted=struct.unpack_from('I',data,1)[0];kNZGDXOBaPKBqWzFRYGh(id_targeted)
		elif opcode==45172 and data==b'\x02\x00':VnHnygEMsrtcvuSSgrkt(FudbnvReIPieRucoAuaD)
		elif ChquIbNINaDDKnvhgMgC()and opcode==12498:
			VnHnygEMsrtcvuSSgrkt(BXxnPGdFgiHeQuztmsNz);Timer(6,bYLiGOhuBMECCCXvppoD).start()
			if THrFZggxXTtiPNayrVBf():pos=YyEqhjxvWquwLzeXsujR();Timer(3,move_to_region,(pos[_J],pos['x'],pos['y'],pos['z'])).start()
	if EWHeJXPvlNluoCondyqQ():
		if opcode==45168 and len(data)>=19 and not THrFZggxXTtiPNayrVBf():
			if not jdwqNlMwvKkzkglWJzHD():return FudbnvReIPieRucoAuaD
			_PlusGuardCount=SeddGghiFoNJTHlkxlNU();sv_skill_id=struct.unpack_from(A,data,3)[0];sv_char_id=struct.unpack_from(A,data,15)[0];char=lsAYyFavuPVrHATRDktQ();_data=OlFpZxSIOWOxoYIYEJhM[_D][char[_A]];_hp_percent=round(char['hp']/char['hp_max']*100)
			if _hp_percent>_data['hpper']:return FudbnvReIPieRucoAuaD
			if sv_char_id==char[B]and sv_skill_id in jdwqNlMwvKkzkglWJzHD():
				_data_shield=_data[_H];_data_blade=_data['blade']
				if not _data_shield:return FudbnvReIPieRucoAuaD
				items=LDlkmjOOgaGCsuHjpvOt()[_I];check_shield_slot=BXxnPGdFgiHeQuztmsNz;check_shield_name=BXxnPGdFgiHeQuztmsNz;_shield_slot=_C;_blade_slot=_C
				for(slot,item)in enumerate(items):
					if slot==7:
						_c1=item and item[_A].startswith(_K);_c2=item and item[_A].startswith(_L);check1=not item or _c1 or _c2
						if check1:check_shield_slot=FudbnvReIPieRucoAuaD
					elif slot>12:
						check2=item and item[_A]==_data_shield[0]and item[_B]==_data_shield[1];check3=item and item[_A]==_data_blade[0]and item[_B]==_data_blade[1]
						if check2:check_shield_name=FudbnvReIPieRucoAuaD;_shield_slot=slot
						if check3:_blade_slot=slot
						if _shield_slot and _blade_slot:break
				if check_shield_slot and check_shield_name:
					if DzNIgOYuhEsMtXgzSpjn():xAudio(700,1000)
					if not _data[C]:_threadShield=Thread(target=ZAogRkswdhOtpGeONRqy,args=(0,_shield_slot,7,_data_shield[0]),daemon=FudbnvReIPieRucoAuaD);_threadShield.start()
					else:_threadShield=Thread(target=ZAogRkswdhOtpGeONRqy,args=(0,_shield_slot,7,_data_shield[0]),daemon=FudbnvReIPieRucoAuaD);Timer(_data[C]/1000,_threadShield.start).start()
					if _blade_slot:
						if not _data[C]:_threadBlade=Thread(target=ZAogRkswdhOtpGeONRqy,args=(0,_blade_slot,6,_data_blade[0]),daemon=FudbnvReIPieRucoAuaD);_threadBlade.start()
						else:_threadBlade=Thread(target=ZAogRkswdhOtpGeONRqy,args=(0,_blade_slot,6,_data_blade[0]),daemon=FudbnvReIPieRucoAuaD);Timer(_data[C]/1000,_threadBlade.start).start()
					global mxxXjuBhVryNxgMWuULn;mxxXjuBhVryNxgMWuULn=FudbnvReIPieRucoAuaD;_PlusGuardCount+=1;EfZrprCtAxjxqZlSjAMf(_PlusGuardCount);_total_time=round((time()-PdccqwEbcsuxNGTQRFpm())/60);_text=NweMXVypQZSXaVSCagqM(131,hhtizdLRxJDclVvtcTSo,'Auto Guard',_PlusGuardCount,_total_time);Timer(.5,log,(_text,)).start()
		elif opcode==12328 and len(data)==20:
			char=KRsJzeKTYFIlLTuRSRiR();_data=OlFpZxSIOWOxoYIYEJhM[_D][char[_A]];shield=_data[_H];my_id=char[B];check_id=struct.unpack_from(A,data,16)
			if my_id==check_id[0]:
				if nVxwkmKtlfblagNmyvCs()and DkgNbbZrpZkhHsQTJPvI():
					for(k,v)in DkgNbbZrpZkhHsQTJPvI().items():
						if len(v)>=2:Thread(target=JsbHIiTiniWONRMJdYHu,args=(k,),daemon=FudbnvReIPieRucoAuaD).start();return FudbnvReIPieRucoAuaD
				if not shield:return FudbnvReIPieRucoAuaD
				try:
					item_inv=LDlkmjOOgaGCsuHjpvOt()[_I]
					for(slot,item)in enumerate(item_inv):
						if slot==7 and item and item[_A]==shield[0]and item[_B]==shield[1]:break
						if slot>=13 and item and item[_A]==shield[0]and item[_B]==shield[1]:_threadShield=Thread(target=ZAogRkswdhOtpGeONRqy,args=(0,slot,7,shield[0]),daemon=FudbnvReIPieRucoAuaD);_threadShield.start();break
				except:pass
	if RQHCCFGZdJqUumUfOKeh()and opcode==45648 and data==b'\x01':pskmkeFlFxkempQFSbFG(FudbnvReIPieRucoAuaD);return FudbnvReIPieRucoAuaD
	if gRjsaRMNmOZslEKAkvTf()and opcode==45108 and len(data)>=4:aSrvaSyaBTLTAlKaIcLM(data);eFWeDhgNDFQMGofODexF(BXxnPGdFgiHeQuztmsNz)
	if OUqTSdfJGPcUyEYpxaEx():
		if jtqqlrcdJdycWCJclYFK()or qeSHgTeenzrgLpkqqbiF():
			if opcode==12375 and len(data)>=12:
				check=LUGQDosFMXaYHGWvUpMJ(data)
				if check:
					player_id=lsAYyFavuPVrHATRDktQ()[B]
					if player_id==struct.unpack_from(A,data,0)[0]:
						if jtqqlrcdJdycWCJclYFK():ydbFAMOMZltBqCXdHHOb()
						if qeSHgTeenzrgLpkqqbiF():_thread=Thread(target=sblrCIfUwplapFVVePRa,daemon=FudbnvReIPieRucoAuaD);_thread.start()
			elif(opcode==45245 and len(data)==16)and struct.unpack_from(A,data,4)[0]in range(10777,10790)and struct.unpack_from(A,data,0)[0]==KRsJzeKTYFIlLTuRSRiR()[B]:
				if jtqqlrcdJdycWCJclYFK():ydbFAMOMZltBqCXdHHOb()
				if qeSHgTeenzrgLpkqqbiF():_thread=Thread(target=sblrCIfUwplapFVVePRa,daemon=FudbnvReIPieRucoAuaD);_thread.start()
	if GBjXCSbveDqsgJCXGdfU()and opcode==45108:
		if data[0]==2:SDMdCiTeUCnmPoeRpRYX(FudbnvReIPieRucoAuaD);fPzjmbAICYugwsNIGyRI(BXxnPGdFgiHeQuztmsNz);name=KRsJzeKTYFIlLTuRSRiR()[_A];OlFpZxSIOWOxoYIYEJhM[_F][_G][name]=BXxnPGdFgiHeQuztmsNz;YM77SLasdfvMCixkinmfyhLU(OlFpZxSIOWOxoYIYEJhM);ChSlozxVuBDjPTUsewsE(BXxnPGdFgiHeQuztmsNz);dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(166,hhtizdLRxJDclVvtcTSo))
	if uiaVPJytuyuhpwQnLUUr()and opcode==12636:
		if len(data)>=8:_thread=Thread(target=xlCLLdoDHeJDZNJexbfh,args=(data,),daemon=FudbnvReIPieRucoAuaD);_thread.start();dqzkwztjTPhEwczvDoVS(BXxnPGdFgiHeQuztmsNz);zZHNTQcjGOHRxwFGQrZx(BXxnPGdFgiHeQuztmsNz)
	if BguXXYDllIdJapkwwDun()and opcode==12305 and data==b'\x04':QaMgOxSZFUNWodUrEqwd(FudbnvReIPieRucoAuaD)
	if sdrpEbjhyKVPUHixJHSV()and opcode==45091:BEZUyPvNbWesBktQOZTf()
	return FudbnvReIPieRucoAuaD
dRBzRDsZDulhsFtoVKPh(NweMXVypQZSXaVSCagqM(155,hhtizdLRxJDclVvtcTSo,UIydKLjzCkrJuheHwDpg))